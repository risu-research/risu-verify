  server.tool(
    WIKI_TOOLS.wiki_upsert_page,
    "Create or update a wiki page with content.",
    {
      wikiIdentifier: z.string().describe("The unique identifier or name of the wiki."),
      path: z.string().describe("The path of the wiki page (e.g., '/Home' or '/Documentation/Setup')."),
      content: z.string().describe("The content of the wiki page in markdown format."),
      project: z.string().optional().describe("The project name or ID where the wiki is located. If not provided, the default project will be used."),
      etag: z.string().optional().describe("ETag for editing existing pages (optional, will be fetched if not provided)."),
      branch: z.string().default("wikiMaster").describe("The branch name for the wiki repository. Defaults to 'wikiMaster' which is the default branch for Azure DevOps wikis."),
    },
    async ({ wikiIdentifier, path, content, project, etag, branch = "wikiMaster" }) => {
      try {
        const connection = await connectionProvider();
        const accessToken = await tokenProvider();

        const normalizedPath = path.startsWith("/") ? path : `/${path}`;
        const encodedPath = encodeURIComponent(normalizedPath);
        const baseUrl = connection.serverUrl;
        const projectParam = project || "";
        const url = `${baseUrl}/${encodeURIComponent(projectParam)}/_apis/wiki/wikis/${encodeURIComponent(wikiIdentifier)}/pages?path=${encodedPath}&versionDescriptor.versionType=branch&versionDescriptor.version=${encodeURIComponent(branch)}&api-version=7.1`;

        const createResponse = await fetch(url, {
          method: "PUT",
          headers: {
            "Authorization": `Bearer ${accessToken}`,
            "Content-Type": "application/json",
            "User-Agent": userAgentProvider(),
          },
          body: JSON.stringify({ content: content }),
        });

        if (createResponse.status === 409 || createResponse.status === 500) {
          let currentEtag = etag;

          if (!currentEtag) {
            const getResponse = await fetch(url, {
              method: "GET",
              headers: {
                "Authorization": `Bearer ${accessToken}`,
                "User-Agent": userAgentProvider(),
              },
            });

            if (getResponse.ok) {
              currentEtag = getResponse.headers.get("etag") || getResponse.headers.get("ETag") || undefined;
              if (!currentEtag) {
                const pageData = await getResponse.json();
                currentEtag = pageData.eTag;
              }
            }

            if (!currentEtag) {
              throw new Error("Could not retrieve ETag for existing page");
            }
          }

          const updateResponse = await fetch(url, {
            method: "PUT",
            headers: {
              "Authorization": `Bearer ${accessToken}`,
              "Content-Type": "application/json",
              "User-Agent": userAgentProvider(),
              "If-Match": currentEtag,
            },
            body: JSON.stringify({ content: content }),
          });

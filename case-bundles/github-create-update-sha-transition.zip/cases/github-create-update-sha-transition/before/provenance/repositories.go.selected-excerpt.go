"sha": {
    Type:        "string",
    Description: "The blob SHA of the file being replaced.",
},

sha, err := OptionalParam[string](args, "sha")
if err != nil {
    return utils.NewToolResultError(err.Error()), nil, nil
}
if sha != "" {
    opts.SHA = github.Ptr(sha)
}

// SHA validation using conditional HEAD request (efficient - no body transfer)
var previousSHA string
contentURL := fmt.Sprintf("repos/%s/%s/contents/%s", owner, repo, url.PathEscape(path))
if branch != "" {
    contentURL += "?ref=" + url.QueryEscape(branch)
}

if sha != "" {
    // User provided SHA - validate it's still current
    req, err := client.NewRequest("HEAD", contentURL, nil)
    if err == nil {
        req.Header.Set("If-None-Match", fmt.Sprintf(`"%s"`, sha))
        resp, _ := client.Do(ctx, req, nil)
        if resp != nil {
            defer resp.Body.Close()

            switch resp.StatusCode {
            case http.StatusNotModified:
                // SHA matches current - proceed
                opts.SHA = github.Ptr(sha)
            case http.StatusOK:
                // SHA is stale - reject with current SHA so user can check diff
                currentSHA := strings.Trim(resp.Header.Get("ETag"), `"`)
                return utils.NewToolResultError(fmt.Sprintf(
                    "SHA mismatch: provided SHA %s is stale. Current file SHA is %s. "+
                        "Use get_file_contents or compare commits to review changes before updating.",
                    sha, currentSHA)), nil, nil
            case http.StatusNotFound:
                // File doesn't exist - this is a create, ignore provided SHA
            }
        }
    }
}

fileContent, resp, err := client.Repositories.CreateFile(ctx, owner, repo, path, opts)

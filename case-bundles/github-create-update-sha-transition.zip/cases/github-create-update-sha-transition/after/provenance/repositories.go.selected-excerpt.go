"sha": {
    Type:        "string",
    Description: "The blob SHA of the file being replaced. Required if the file already exists.",
},

sha, err := OptionalParam[string](args, "sha")
if err != nil {
    return utils.NewToolResultError(err.Error()), nil, nil
}
if sha != "" {
    opts.SHA = github.Ptr(sha)
}

// SHA validation using Contents API to fetch current file metadata (blob SHA)
getOpts := &github.RepositoryContentGetOptions{Ref: branch}

if sha != "" {
    // User provided SHA - validate it's still current
    existingFile, dirContent, respCheck, getErr := client.Repositories.GetContents(ctx, owner, repo, path, getOpts)
    if respCheck != nil {
        _ = respCheck.Body.Close()
    }
    switch {
    case getErr != nil:
        // 404 means file doesn't exist - proceed (new file creation)
        // Any other error (403, 500, network) should be surfaced
        if respCheck == nil || respCheck.StatusCode != http.StatusNotFound {
            return ghErrors.NewGitHubAPIErrorResponse(ctx,
                "failed to verify file SHA",
                respCheck,
                getErr,
            ), nil, nil
        }
    case dirContent != nil:
        return utils.NewToolResultError(fmt.Sprintf(
            "Path %s is a directory, not a file. This tool only works with files.",
            path)), nil, nil
    case existingFile != nil:
        currentSHA := existingFile.GetSHA()
        if currentSHA != sha {
            return utils.NewToolResultError(fmt.Sprintf(
                "SHA mismatch: provided SHA %s is stale. Current file SHA is %s. "+
                    "Pull the latest changes and use git rev-parse %s:%s to get the current SHA.",
                sha, currentSHA, branch, path)), nil, nil
        }
    }
}

fileContent, resp, err := client.Repositories.CreateFile(ctx, owner, repo, path, opts)

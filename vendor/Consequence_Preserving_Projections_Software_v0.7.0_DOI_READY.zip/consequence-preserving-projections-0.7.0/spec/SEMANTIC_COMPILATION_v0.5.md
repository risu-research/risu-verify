# Consequence-Blind Semantic Compilation v0.5

Projection Assurance v0.5 moves the discriminator and Exact Realization tables out of the authored verifier input. A v0.5 bundle supplies a declared consequence lens separately from world records, profile constants, established fact identifiers, and a small deterministic derivation program. The compiler receives only the latter material.

The purpose is narrower than author blinding. It enforces **runtime input independence from the per-world source consequence table** and from analyst target-outcome tables. An author can still choose an inadequate world model, consequence lens, derivation rule, or evidence interpretation. Those remain explicit external premises.

## Dataflow

The verifier first validates the bundle and provenance graph. It then constructs a sanitized compiler payload containing only:

- world identifiers plus declared world coordinates;
- profile constants;
- the identifiers of facts whose status is `ESTABLISHED`;
- the derivation program; and
- whether Exact Realization is requested.

The payload does **not** contain `consequence.source_by_world`, `declared_target_model_by_world`, a predeclared discriminator table, a predeclared operative-signature table, or a predeclared mechanism-consequence table.

The same canonical payload is sent by standard input to separately implemented Python and Node compilers. The compilers receive no bundle-path argument. The working directory is a temporary directory. This is an input-isolation discipline, not an OS sandbox; v0.5 does not claim that a malicious compiler executable is filesystem-confined.

The two compiler outputs must agree byte-for-byte after canonical JSON serialization. A disagreement fails closed.

## Four stages

A compilation program contains four deterministic stages. Each stage declares the evidence facts that must already be established before the stage can run.

1. `discriminator`: may read only `world` coordinates and `const` profile constants. It produces the target-side discriminator value used by D.
2. `operative_signature`: may read only `world` coordinates and `const`. It produces the modeled operative signature `z_G`.
3. `mechanism`: may read only `z` and `const`. It produces a carrier-native modeled effect outcome. The compiler evaluates this stage once per distinct operative-signature fiber, so the native outcome is a function of `z_G` by construction.
4. `interpreter`: may read only `native` and `const`. It maps the native outcome either into a declared consequence class `{space:"C", label:...}` or preserves it explicitly as `{space:"OUTSIDE_C", native:...}`. The `OUTSIDE_C.native` value must equal the native outcome being interpreted.

The mechanism and interpreter stages cannot read a world record directly. This prevents the compiled mechanism table from becoming a disguised per-world answer table.

## Expression language

The v0.5 derivation language is intentionally small. Supported operators are:

- `literal`
- `get`
- `object`
- `array`
- `if`
- `eq`, `neq`
- `and`, `or`, `not`
- `is_null`

`get` is stage-restricted as described above. World identifiers are available only for indexing compiler output; they are not an expression source, and `id` is reserved from world-coordinate objects.

The language is finite and deterministic. It is not intended to encode arbitrary programs, nondeterministic services, probabilistic behavior, or rich temporal logic.

## Fact grounding

A rule may name `required_fact_ids`, but fact status is not used as an expression input. Facts gate whether derivation is licensed; they do not select favorable branches.

For `EVIDENCE_LINKED` bundles, every required compiler fact must:

- have status `ESTABLISHED`;
- name a unique provenance node of kind `FACT`;
- trace upstream to required content-addressed `EVIDENCE`, `SOURCE`, or `QUALIFICATION` bytes; and
- lie on the corresponding D and/or Exact claim path.

This makes the blind compiler dependent on established semantic premises without letting evidence booleans become hidden consequence selectors.

## Result construction

After compilation, the verifier constructs the ordinary semantic profiles internally:

- the compiled discriminator table is inserted into the structural profile;
- the compiled operative signature and mechanism interpretation form the Exact profile;
- the source consequence table is copied into the Exact profile **only after compilation**; and
- the existing structural and Exact kernels recompute D and Exact Realization.

Consequently, changing the per-world source consequence table can change the verdict while leaving the compiled discriminator, operative signature, native outcome, and mechanism interpretation unchanged.

## Assurance class

A successful v0.5 compilation reports `BLIND_COMPILED_*`. For an evidence-linked bundle with successful byte rechecks, the class is `BLIND_COMPILED_EVIDENCE_VERIFIED`.

This class means that the derived semantic tables were produced under the v0.5 input firewall and dual-runtime compiler, and that the required claim-linked evidence bytes matched their declared digests. It does not establish author independence, semantic adequacy of the world model, truth of the evidence interpretation, live-runtime conformance, general source equivalence, or independent reproduction.

## Auditable input footprint

Each compiler output records `stage_input_footprint`, the exact `get` source/path pairs present in each stage expression after validation. The Python and Node implementations must emit the same footprint. It is part of the compilation digest and certificate recompilation state. The footprint makes the stage namespace discipline directly inspectable; it does not establish that an authored world coordinate or constant is semantically adequate.

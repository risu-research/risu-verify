# Assurance Bundle v0.4 — hardened trust semantics in software v0.4.1

An Assurance Bundle is the carrier-neutral input to `risu-projection`. It contains one declared structural profile, an optional Exact Realization profile over the same declared world/consequence domain, content-addressed bindings, a provenance DAG, and explicit author claim boundaries.

The v0.4.1 verifier keeps the v0.4 bundle syntax but tightens what `EVIDENCE_LINKED` means. Every claim root must be a `CLAIM` node. Every individual claim root must reach at least one required `EVIDENCE`, `QUALIFICATION`, or `SOURCE` binding through a well-typed acyclic provenance path. Evidence nodes cannot dangle outside all claim paths, non-evidence nodes cannot carry file bindings, and required epistemic bindings cannot float outside the provenance DAG. `AUXILIARY` bytes never count as epistemic support.

Bindings are relative to the bundle directory and may not escape it. Required bytes are rehashed before an evidence-linked bundle receives a complete PASS or a certificate. Optional missing bindings are recorded explicitly and cannot substitute for required evidence.

The verifier does not infer whether declared worlds, Boundary assumptions, source correspondence, discriminator meanings, or mechanism semantics are adequate. Claim-to-byte integrity is deliberately separate from semantic adequacy.

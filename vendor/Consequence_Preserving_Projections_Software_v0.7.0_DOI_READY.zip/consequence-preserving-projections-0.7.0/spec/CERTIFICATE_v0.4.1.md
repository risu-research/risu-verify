# Projection Assurance Certificate v0.4.1

A v0.4.1 certificate is a self-recomputable, model-relative assurance object with an explicit evidence state. It embeds the complete Assurance Bundle snapshot, hashes that snapshot, records structural and Exact Realization input digests, and carries the full result objects required for recomputation.

For an `EVIDENCE_LINKED` bundle, issuance is permitted only after the verifier rehashes every required claim-linked evidence, qualification, or source binding and every exported claim has an actual provenance path to required epistemic evidence. Merely declaring bindings is not sufficient. The certificate records claim-by-claim provenance and the evidence state at issuance.

Certificate verification has three outcomes:

- `PASS`: the model recomputes exactly and, when evidence was claimed, the required evidence bytes were rechecked successfully.
- `PARTIAL`: the model recomputes exactly, but an evidence-linked certificate was checked without an evidence root. This is not an evidence-verified PASS.
- `FAIL`: a semantic result, snapshot digest, provenance statement, fixed verifier boundary, or required evidence byte fails verification.

`DECLARED_ONLY` certificates do not claim external evidence and may verify fully without an evidence root.

The verifier also emits a fixed boundary statement. Neither a bundle author's prose nor a content hash can upgrade the verifier into a claim of model adequacy, live-runtime conformance, general source equivalence, or independent reproduction.

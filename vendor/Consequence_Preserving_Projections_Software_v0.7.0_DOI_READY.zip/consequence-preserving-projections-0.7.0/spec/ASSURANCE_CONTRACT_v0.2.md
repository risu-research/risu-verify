# Assurance Contract v0.2

The contract is the normative half of a projection derivation.

It declares Boundary, consequence lens, admissible worlds, scope, coverage and the discriminator partition to be tested. These are not relabeled as source observations.

`declared_target_model_by_world` is optional. When present, it is explicitly a declared analytical model used for a secondary consistency check. It never determines C, D, O, or the structural classification.

This separation prevents a circular pattern in which an analyst writes the expected target behavior into the contract and then calls the resulting equality test an empirical preservation result.

# Structured JSON Equality v0.3

Discriminator and consequence values may be JSON null, Boolean, string, array, object, or finite number. Objects compare recursively by key/value content independent of key order; arrays are ordered; Boolean is distinct from number; numerically equal safe JSON numbers such as `1` and `1.0` compare equal. Integer-valued numbers outside the IEEE-754 safe integer range are rejected so Python and Node cannot silently disagree after parsing.

This executable equality regime closes the v0.2 Python/Node object-identity gap without changing the mathematical D definition.

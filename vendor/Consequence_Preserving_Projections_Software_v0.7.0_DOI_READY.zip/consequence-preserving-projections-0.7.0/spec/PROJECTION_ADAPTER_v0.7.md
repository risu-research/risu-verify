# Projection Adapter v0.7

A Projection Adapter is a target-side assurance object bound to one immutable Source Consequence Contract by path and SHA-256. The adapter supplies target correspondence/placement facts, evidence bindings and provenance, target coverage, and a consequence-blind derivation program. It does not define the source world set or source consequence table.

The verifier first compiles the Source Consequence Contract. It then injects the generated worlds and generated source consequence map into an internal v0.5-normalized Assurance Bundle and runs the existing consequence-blind target compiler, structural verifier, Exact Realization verifier, provenance checks, and proof-carrying certificate path.

Changing the source contract changes its digest. A target adapter pinned to the previous contract therefore fails closed rather than silently changing the preservation claim.

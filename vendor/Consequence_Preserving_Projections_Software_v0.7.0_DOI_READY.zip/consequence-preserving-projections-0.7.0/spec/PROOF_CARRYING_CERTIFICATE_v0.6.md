# Proof-Carrying Projection Assurance Certificate v0.6

v0.6 changes what a certificate consumer must trust. A v0.5 certificate could be recomputed by the main Projection Assurance verifier, but that placed the semantic compiler, bundle validator, structural kernel, Exact Realization kernel, provenance code, and certificate verifier in the active checking path. v0.6 carries an explicit finite proof object and ships a separate reference checker that does not import or execute any of those components.

The reference checker is `checker/risu_pcc_check.py`. It uses only the Python standard library. A certificate can therefore be checked after the rest of the RISU package has been removed. This is code-path independence, not independent authorship and not a proof about the Python runtime itself.

## Proof object

The certificate embeds the original v0.5 Assurance Bundle and a proof with five parts.

1. **Blind compilation proof.** The checker independently validates the restricted derivation language, stage source restrictions, required established facts, input firewall, stage input footprint, z-fiber construction, native mechanism outcomes, and consequence interpretation. It reconstructs `d`, `z_G`, native outcomes, and the totalized mechanism consequence without reading the source consequence table during compilation.
2. **Structural proof.** C is tied to the declared correspondence state. D is carried either by a consequence decoder for every discriminator fiber or by a concrete consequence-divergent pair collapsed by `d`. O carries the normalized placement premises and the rule selected by the v0.2 placement semantics. Coverage carries the exact set difference.
3. **Exact Realization proof.** Operative sufficiency is carried either by a decoder for every `z_G` fiber or by a concrete divergent pair collapsed by `z_G`. Alignment carries the per-fiber required and actual consequence mapping or a concrete mismatch. Unsupported carrier-native outcomes remain `OUTSIDE_C`.
4. **Provenance proof.** Each exported claim carries its claim roots and upstream support. For `EVIDENCE_LINKED` bundles the checker independently validates graph typing, acyclicity, required claim-to-evidence paths, compiler-fact grounding, and, when a root is supplied, the required file hashes.
5. **Verdict commitment.** The proof commits to the complete structural, Exact Realization, and cross-layer result objects. The checker reconstructs those results and requires exact equality.

The proof itself is content-addressed by `proof_digest`; the complete source bundle is content-addressed separately by `bundle_digest`.

## Reference checker boundary

The checker does **not** import the main verifier, semantic compiler, structural kernel, Exact kernel, or certificate builder. It does not require Node.js. The release qualification runs it from an isolated temporary directory containing only the checker and certificate, with an evidence root supplied separately when evidence verification is requested.

The reference checker still relies on the Python interpreter and the relevant standard-library JSON, SHA-256, numeric, and filesystem semantics. Its small source file is a reduction in project-specific trusted code, not a claim that the total machine TCB is only the checker line count.

A `PASS` is model-relative. It does not establish that the authored worlds, consequence lens, evidence interpretation, correspondence, or mechanism model are adequate descriptions of a live system. Evidence hash agreement establishes byte identity, not semantic truth. Author independence, live-runtime conformance, general source equivalence, and independent reproduction remain outside the checker claim.

## Evidence states

For an `EVIDENCE_LINKED` certificate:

- `PASS` requires successful model-proof checking and rehashing of every required claim-linked evidence binding.
- `PARTIAL` means the finite proof checks but no evidence root was supplied. This is not an evidence-verified PASS.
- `FAIL` means a proof, bundle commitment, provenance relation, result commitment, fixed boundary statement, or required evidence byte failed.

For `DECLARED_ONLY` certificates, evidence checking is not applicable.

## Why proof carrying is different from self-recomputation

The certificate producer may still use the full dual-runtime research implementation to qualify and issue the artifact. Certificate acceptance, however, no longer requires that producer implementation. A consumer can check the finite claim through a separate, deliberately small executable semantics whose input is the certificate itself. The result is closer to a proof-carrying interface: the producer performs the expensive derivation and qualification work, while the consumer receives the claim, its local witnesses, and a compact checker path.

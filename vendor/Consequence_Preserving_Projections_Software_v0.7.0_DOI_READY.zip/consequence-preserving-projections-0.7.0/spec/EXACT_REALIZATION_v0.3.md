# Exact Realization Protocol v0.3

Input is a finite nonempty world list, a declared source consequence map `K`, an operative-signature map `z_G`, and a **totalized** grounded mechanism-consequence map. Mechanism values are either `{space:"C", label:...}` or `{space:"OUTSIDE_C", native:...}`.

`z_G` is sufficient exactly when equal operative signatures never merge worlds with different `K`. When sufficient, each realized z-fiber has a unique required consequence decoder. Exact realization holds exactly when the mechanism consequence is a function of z and equals that required decoder on every realized fiber.

If z is insufficient, `alpha_aligned` is not a meaningful favorable Boolean because a unique required decoder does not exist on the divergent fiber. v0.3 therefore reports `null / NOT_APPLICABLE_Z_INSUFFICIENT`.

Repair output is intentionally obligation-class level. It does not invent or claim a unique concrete patch.

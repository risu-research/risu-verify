# Projection IR v0.2 — synthesis candidate

Projection IR v0.2 separates **structural projection assurance** from any declared end-to-end target outcome model.

## Semantic core

A profile declares an in-scope source→target operation correspondence, a Boundary, a consequence lens, a consequence-sufficient discriminator candidate, and an operative discharge.

The analyzer derives:

- **C** — correspondence established, not established, or unresolved;
- **D** — whether equal discriminator signatures imply equal declared source consequence over the bounded worlds;
- **O** — whether that distinction gates the consequential effect at the declared action cut, directly or through a declared environmental replacement.

The **structural classification** depends only on C/D/O and scope. It MUST NOT depend on a target outcome table supplied by the analyst.

## Declared target model

`declared_target_model_by_world` is optional and explicitly epistemically weaker. It is a declared analytical model used only for a secondary cross-check.

It yields one of:
- `DECLARED_MODEL_MATCH`;
- `DECLARED_MODEL_MISMATCH`;
- `DECLARED_MODEL_NOT_PROVIDED`.

A match does **not** upgrade the evidence to runtime validation. A mismatch does not create C/D/O; it only reports inconsistency between the declared source consequence map and the declared target model.

## Structural classifications

- `OUTSIDE_DECLARED_SCOPE`
- `CORRESPONDENCE_NOT_ESTABLISHED`
- `DISCRIMINATION_INADEQUATE`
- `OPERATIVE_DISCHARGE_MISSING`
- `UNRESOLVED`
- `STRUCTURAL_ASSURANCE_ESTABLISHED`

`STRUCTURAL_ASSURANCE_ESTABLISHED` means C1, D1, and an operative discharge (O1 or O1_REPLACED) on the declared bounded profile. It does not mean complete source capability preservation, runtime equivalence, permission, authorization, or correctness of the consequence itself.

## Coverage

Capability coverage is orthogonal. C1-D1-O1 on a narrow projection slice does not imply full source-family coverage.

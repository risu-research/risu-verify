# Source Consequence Contract v0.7

v0.7 separates the source consequence claim from any target projection. The contract declares a finite coordinate domain, an admissibility predicate, one total consequence function, a Boundary premise, and the declared source family. It does **not** enumerate worlds or provide a per-world consequence table.

The source compiler canonicalizes coordinate names and domain values, enumerates the complete declared Cartesian domain, applies the admissibility predicate, generates canonical world identifiers from coordinate values, and evaluates the consequence function on every admitted realization. The resulting world set and K table are generated objects, not authored answer tables.

This is still model-relative. The compiler does not establish that the declared coordinates, domains, admissibility predicate, consequence function, or Boundary are adequate abstractions of a real system.

The contract language is intentionally finite and restricted. `admissibility.expr` and `consequence.expr` may read only `coord` and `const` through the same small deterministic expression algebra used by the release. No target, evidence, discriminator, operative signature, mechanism result, or expected verdict is visible to source compilation.

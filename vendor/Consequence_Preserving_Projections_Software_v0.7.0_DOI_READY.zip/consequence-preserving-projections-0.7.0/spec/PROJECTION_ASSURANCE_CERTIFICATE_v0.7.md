# Projection Assurance Certificate v0.7

A v0.7 certificate binds a **Source Consequence Contract** to a **Projection Adapter** while retaining the v0.6 finite proof as its inner independently checkable semantic proof.

The certificate carries:

1. the parsed source-contract snapshot and its semantic digest;
2. the exact UTF-8 source-contract file bytes, base64 encoded, plus the SHA-256 pinned by the adapter;
3. the adapter snapshot and digest;
4. the dual-runtime source-compilation record and generated domain proof;
5. the normalized v0.5 consequence-blind Assurance Bundle commitment;
6. the complete v0.6 proof-carrying inner certificate and digest; and
7. the committed structural, Exact Realization, and Coverage results.

The exact source-contract bytes are included so a consumer can independently verify the adapter's file pin without trusting the producer or requiring the original source-contract file. When a verification root is supplied, the checker additionally requires the root file bytes to match the embedded bytes exactly.

## Layered consumer check

`checker/risu_contract_pcc_check.py` independently regenerates the declared finite source domain and K from the embedded Source Consequence Contract, verifies the embedded raw-file pin, reconstructs the normalized target bundle, and delegates only the inner finite proof to `checker/risu_pcc_check.py`.

Neither checker imports or executes the producer source compiler, target semantic compiler, structural kernel, Exact Realization kernel, verifier, or certificate builder. The trusted project-specific checking surface is therefore the two small checker files, together with the Python interpreter and required standard-library semantics.

## Evidence state

The embedded source-contract pin is self-contained and is checked even without a filesystem root. Claim-linked external evidence remains separate:

- `PASS` for an `EVIDENCE_LINKED` certificate requires a supplied root and successful rehashing of required claim-linked evidence bytes.
- `PARTIAL` means the source/model proof and embedded source-contract pin check, but external evidence bytes were not rechecked.
- `DECLARED_ONLY` certificates can be fully checked without a root because no external epistemic evidence is claimed.

## Claim boundary

A PASS is exact only relative to the declared finite domains, admissibility predicate, source consequence function, Boundary, source family, target derivation premises, and evidence interpretation. It does not establish that those declarations are the uniquely correct abstraction of a live system, nor does it establish live-runtime conformance, independent authorship, or independent reproduction.

# Changelog

## v0.7.0 — 2026-08-28

### Source Consequence Contract / Projection Adapter separation

- Replaces authored source world tables on the v0.7 path with a finite Source Consequence Contract containing coordinate domains, an admissibility predicate, one total consequence function, Boundary premises, and a declared source family.
- Adds independent Python and Node source-contract compilers. Both enumerate the complete declared Cartesian domain, generate canonical world identifiers, evaluate K on every admitted realization, and must produce byte-equivalent canonical results.
- Rejects authored `worlds`, `source_by_world`, target outcome tables, and related per-world answer surfaces from v0.7 target adapters.
- Separates the source contract from the Projection Adapter and pins the adapter to the exact source-contract file by SHA-256.
- Preserves v0.5 consequence-blind target compilation after source-domain generation. Target derivation still cannot read K.
- Adds a domain proof with Cartesian/admitted/excluded cardinalities, admitted/excluded world digests, K-map digest, K totality, and source-stage input footprints.
- Adds a layered v0.7 proof-carrying certificate. The consumer checker independently regenerates the source domain/K, reconstructs the normalized target bundle, and then invokes only the already qualified compact v0.6 proof checker.
- Carries the exact source-contract file bytes in the v0.7 certificate so the standalone checker can verify the adapter pin without producer code or the original file; when a root is supplied, the root bytes must match the embedded bytes exactly.
- Adds a shared-contract qualification in which two different target adapters reference one identical source contract but obtain opposite Exact Realization outcomes.
- Adds a 15-vector dual-runtime source-compiler conformance corpus, a deterministic Python/Node/standalone-checker source-semantics stress differential, and a v0.7 source-contract/adversarial gate.
- Retains the canonical GitHub and Azure bounded outcomes without semantic retuning.
- Records the v0.6.0 predecessor by SHA-256 and records byte identities for inherited lower-layer components and historical qualification results. Earlier release archives are not nested into the public v0.7 package.

### Claim and prior-art boundary

v0.7 does not claim novelty for contract-based design, refinement, finite-domain enumeration/model checking, service precondition/effect descriptions, translation validation, consumer-driven contract testing, or proof-carrying artifacts. The specialized contribution is the source-consequence/projected-interface assurance boundary formed by a reusable claim-indexed source contract, generated complete declared domain and functional K, immutable source-to-adapter binding, consequence-blind target compilation, and proof-carrying checking. Source-model adequacy and evidence interpretation remain external premises.

## v0.6.0 — 2026-08-28

Introduced proof-carrying Projection Assurance certificates and a separate standard-library-only consumer checker that does not import or execute the producer semantic compiler, structural kernel, Exact Realization kernel, verifier, or certificate builder.

## v0.5.0 — 2026-08-28

Introduced consequence-blind semantic compilation, removing authored per-world discriminator, operative-signature, and mechanism-consequence answer tables from the v0.5 target compilation path.

## v0.4.1 — 2026-08-28

Hardened claim-specific evidence reachability, typed provenance, evidence-state separation, and certificate evidence-recheck semantics.

## v0.4.0 — 2026-08-28

Introduced the generic carrier-neutral Assurance Bundle, self-recomputable certificate, unified verifier CLI, provenance DAG, deterministic explanations, and cross-axis adversarial validation.

## v0.3.0 — 2026-08-28

Promoted Exact Realization, structured cross-runtime equality, publication qualification bindings, and certificate/replay integration into the software release.

#!/usr/bin/env python3
import json,sys
sys.dont_write_bytecode=True
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'kernel/implementations'))
from reference_analyzer import json_equal,_validate_json_value
PROTOCOL='risu-projection-exact/0.4'
def _embed(k):return {'space':'C','label':k}
def _norm_alpha(a):
    if not isinstance(a,dict) or a.get('space') not in ('C','OUTSIDE_C'):raise ValueError('mechanism consequence must be totalized {space:C,label:...} or {space:OUTSIDE_C,native:...}')
    if a['space']=='C' and 'label' not in a:raise ValueError('C mechanism consequence missing label')
    if a['space']=='OUTSIDE_C' and 'native' not in a:raise ValueError('OUTSIDE_C mechanism consequence missing native')
    _validate_json_value(a)
    return a
def _same_group(groups,z):
    for g in groups:
        if json_equal(g['signature'],z):return g
    return None
def evaluate(p):
    ws=p['worlds'];K=p['consequence_by_world'];Z=p['operative_signature_by_world'];A=p['mechanism_consequence_by_world']
    if not ws:raise ValueError('worlds must be nonempty')
    if any(not isinstance(w,str) for w in ws):raise ValueError('world identifiers must be strings')
    if len(set(ws))!=len(ws):raise ValueError('worlds contains duplicates')
    groups=[]
    for w in ws:
        if w not in K or w not in Z or w not in A:raise ValueError(f'world {w!r} missing K, z, or mechanism consequence')
        _validate_json_value(K[w],f'K[{w}]');_validate_json_value(Z[w],f'z[{w}]');_norm_alpha(A[w]);g=_same_group(groups,Z[w])
        if g is None:g={'signature':Z[w],'worlds':[]};groups.append(g)
        g['worlds'].append(w)
    sufficient=True;z_witness=None;decoder=[]
    for g in groups:
        vals=[]
        for w in g['worlds']:
            if not any(json_equal(K[w],x) for x in vals):vals.append(K[w])
        if len(vals)>1 and z_witness is None:
            sufficient=False
            pair=None
            for i,a in enumerate(g['worlds']):
                for b in g['worlds'][i+1:]:
                    if not json_equal(K[a],K[b]):pair=[a,b];break
                if pair:break
            z_witness={'worlds':pair,'signature':g['signature'],'consequences':[K[pair[0]],K[pair[1]]]}
        if len(vals)==1:decoder.append({'signature':g['signature'],'consequence':vals[0],'worlds':g['worlds']})
    mismatches=[];outside=[]
    for w in ws:
        got=A[w];want=_embed(K[w])
        if got.get('space')=='OUTSIDE_C':outside.append({'world':w,'value':got})
        if not json_equal(got,want):mismatches.append({'world':w,'required':want,'actual':got})
    if not sufficient:
        aligned=None;align_status='NOT_APPLICABLE_Z_INSUFFICIENT';align_witness=None
    else:
        aligned=True;align_status='ALIGNED';align_witness=None
        for d in decoder:
            vals=[]
            for w in d['worlds']:
                if not any(json_equal(A[w],x) for x in vals):vals.append(A[w])
            if len(vals)>1:
                aligned=False;align_status='MISALIGNED';align_witness={'signature':d['signature'],'worlds':d['worlds'],'reason':'ALPHA_NOT_FUNCTION_OF_Z','actual_values':vals};break
            want=_embed(d['consequence'])
            if not json_equal(vals[0],want):
                aligned=False;align_status='MISALIGNED';align_witness={'signature':d['signature'],'worlds':d['worlds'],'reason':'WRONG_DECODER','required':want,'actual':vals[0]};break
    exact=bool(sufficient and aligned is True and not mismatches)
    if exact:failure='NONE';minimal=None;repair=[]
    elif not sufficient:
        failure='OPERATIVE_INSUFFICIENCY';minimal={'kind':'CONSEQUENCE_DIVERGENT_PAIR_COLLAPSED_BY_Z',**z_witness};repair=[{'class':'ADD_CONSEQUENCE_RELEVANT_INPUT','necessary_condition':'The operative signature must distinguish every admissible pair with different declared consequences.'},{'class':'NO_POSTPROCESSING_ONLY_REPAIR','necessary_condition':'Deterministic post-processing of the unchanged insufficient operative signature cannot restore the lost distinction.'}]
    else:
        failure='MECHANISM_MISALIGNMENT';m=mismatches[0] if mismatches else align_witness;minimal={'kind':'EFFECT_MAPPING_MISMATCH','detail':m};repair=[{'class':'ALIGN_EFFECT_MECHANISM','necessary_condition':'On each operative-signature fiber, the grounded mechanism consequence must equal the unique decoder required by the declared source consequence.'}]
    return {'z_sufficient':sufficient,'z_witness':z_witness,'required_decoder':decoder if sufficient else None,'alpha_aligned':aligned,'alpha_alignment_status':align_status,'alignment_witness':align_witness,'outside_c':outside,'world_mismatches':mismatches,'exact':exact,'status':'REALIZATION_ESTABLISHED' if exact else 'REALIZATION_CONTRADICTED','failure_mode':failure,'minimal_counterexample':minimal,'repair_obligations':repair}
def main():
    for line in sys.stdin:
      if not line.strip():continue
      q=None
      try:q=json.loads(line);out={'protocol':PROTOCOL,'request_id':q.get('request_id'),'ok':True,'result':evaluate(q['profile'])}
      except Exception as e:out={'protocol':PROTOCOL,'request_id':q.get('request_id') if isinstance(q,dict) else None,'ok':False,'error':str(e)}
      print(json.dumps(out,sort_keys=True,separators=(',',':')),flush=True)
if __name__=='__main__':main()

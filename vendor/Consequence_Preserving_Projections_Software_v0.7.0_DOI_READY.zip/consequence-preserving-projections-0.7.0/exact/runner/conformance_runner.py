#!/usr/bin/env python3
from pathlib import Path
import argparse,json,subprocess,shlex,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1];P='risu-projection-exact/0.4'
def main():
 a=argparse.ArgumentParser();a.add_argument('--testee-cmd',required=True);a.add_argument('--json-out',required=True);a.add_argument('--junit-out',required=True);x=a.parse_args();exp=json.loads((ROOT/'VECTOR_EXPECTATIONS_v0.4.json').read_text());pr=subprocess.Popen(shlex.split(x.testee_cmd),stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True,bufsize=1);rows=[]
 try:
  for vid in sorted(exp):
   prof=json.loads((ROOT/'vectors'/f'{vid}.json').read_text());pr.stdin.write(json.dumps({'protocol':P,'request_id':vid,'op':'evaluate_exact','profile':prof},separators=(',',':'))+'\n');pr.stdin.flush();resp=json.loads(pr.stdout.readline());ok=resp.get('ok',False);got=resp.get('result',{});detail='';match=ok
   if ok:
    for k,v in exp[vid].items():
     if got.get(k)!=v:match=False;detail=f'{k}: expected {v!r}, got {got.get(k)!r}';break
   else:detail=resp.get('error','testee error')
   rows.append({'id':vid,'pass':bool(match),'detail':detail,'result':got if ok else None,'expected':exp[vid]})
 finally:
  if pr.stdin and not pr.stdin.closed:pr.stdin.close()
  pr.terminate();pr.wait(timeout=5)
 rep={'protocol':P,'total':len(rows),'passed':sum(r['pass'] for r in rows),'verdict':'PASS' if all(r['pass'] for r in rows) else 'FAIL','results':rows};Path(x.json_out).write_text(json.dumps(rep,indent=2,sort_keys=True)+'\n');suite=ET.Element('testsuite',name='projection-exact-conformance-v0.4',tests=str(len(rows)),failures=str(sum(not r['pass'] for r in rows)))
 for r in rows:
  tc=ET.SubElement(suite,'testcase',name=r['id']);
  if not r['pass']:f=ET.SubElement(tc,'failure',message=r['detail']);f.text=json.dumps(r,sort_keys=True)
 ET.ElementTree(suite).write(x.junit_out,encoding='utf-8',xml_declaration=True);print(json.dumps({'verdict':rep['verdict'],'passed':rep['passed'],'total':rep['total']}));return 0 if rep['verdict']=='PASS' else 2
if __name__=='__main__':raise SystemExit(main())

package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"go/ast"
	"go/parser"
	"go/token"
	"os"
	"sort"
	"strconv"
	"strings"
)

type QueryPack struct {
	QueryProtocol string            `json:"query_protocol"`
	Artifacts     map[string]string `json:"artifacts"`
	Queries       []Query           `json:"queries"`
	Derivations   []Derivation      `json:"derivations"`
}
type Query struct {
	ID           string   `json:"id"`
	Artifact     string   `json:"artifact"`
	Op           string   `json:"op"`
	Function     string   `json:"function"`
	Values       []string `json:"values"`
	CalleeSuffix string   `json:"callee_suffix"`
	TypeSuffix   string   `json:"type_suffix"`
	Key          string   `json:"key"`
	Struct       string   `json:"struct"`
	Field        string   `json:"field"`
	JSONTag      string   `json:"json_tag"`
	LHSSuffix    string   `json:"lhs_suffix"`
	RHSSuffix    string   `json:"rhs_suffix"`
	Substring    string   `json:"substring"`
}
type Derivation struct {
	ID    string   `json:"id"`
	AllOf []string `json:"all_of"`
}
type Region struct {
	StartLine   int `json:"startLine"`
	StartColumn int `json:"startColumn"`
	EndLine     int `json:"endLine"`
	EndColumn   int `json:"endColumn"`
}
type Result struct {
	ID       string  `json:"id"`
	Value    bool    `json:"value"`
	Artifact string  `json:"artifact,omitempty"`
	Op       string  `json:"op"`
	Region   *Region `json:"region,omitempty"`
	Detail   any     `json:"detail,omitempty"`
}

func exprString(e ast.Expr) string {
	switch x := e.(type) {
	case *ast.Ident:
		return x.Name
	case *ast.SelectorExpr:
		return exprString(x.X) + "." + x.Sel.Name
	case *ast.StarExpr:
		return "*" + exprString(x.X)
	case *ast.IndexExpr:
		return exprString(x.X)
	case *ast.IndexListExpr:
		return exprString(x.X)
	default:
		return fmt.Sprintf("%T", e)
	}
}
func region(fs *token.FileSet, n ast.Node) *Region {
	a, b := fs.Position(n.Pos()), fs.Position(n.End())
	return &Region{a.Line, a.Column, b.Line, b.Column}
}
func fn(file *ast.File, name string) *ast.FuncDecl {
	for _, d := range file.Decls {
		if f, ok := d.(*ast.FuncDecl); ok && f.Name.Name == name {
			return f
		}
	}
	return nil
}
func st(file *ast.File, name string) *ast.StructType {
	for _, d := range file.Decls {
		g, ok := d.(*ast.GenDecl)
		if !ok {
			continue
		}
		for _, sp := range g.Specs {
			ts, ok := sp.(*ast.TypeSpec)
			if !ok || ts.Name.Name != name {
				continue
			}
			if s, ok := ts.Type.(*ast.StructType); ok {
				return s
			}
		}
	}
	return nil
}
func literals(n ast.Node) []string {
	out := []string{}
	ast.Inspect(n, func(x ast.Node) bool {
		if b, ok := x.(*ast.BasicLit); ok && b.Kind == token.STRING {
			if v, e := strconv.Unquote(b.Value); e == nil {
				out = append(out, v)
			}
		}
		return true
	})
	return out
}

func eval(q Query, file *ast.File, fs *token.FileSet) Result {
	r := Result{ID: q.ID, Artifact: q.Artifact, Op: q.Op}
	switch q.Op {
	case "function_exists":
		f := fn(file, q.Function)
		r.Value = f != nil
		if f != nil {
			r.Region = region(fs, f)
		}
	case "string_literals_absent_in_function":
		f := fn(file, q.Function)
		if f == nil {
			return r
		}
		set := map[string]bool{}
		for _, s := range literals(f) {
			set[s] = true
		}
		r.Value = true
		for _, v := range q.Values {
			if set[v] {
				r.Value = false
			}
		}
		r.Region = region(fs, f)
		r.Detail = map[string]any{"forbidden": q.Values}
	case "call_exists_in_function":
		f := fn(file, q.Function)
		if f == nil {
			return r
		}
		ast.Inspect(f, func(n ast.Node) bool {
			if c, ok := n.(*ast.CallExpr); ok && strings.HasSuffix(exprString(c.Fun), q.CalleeSuffix) {
				r.Value = true
				r.Region = region(fs, c)
				return false
			}
			return true
		})
	case "composite_key_absent_in_function":
		f := fn(file, q.Function)
		if f == nil {
			return r
		}
		foundType, foundKey := false, false
		ast.Inspect(f, func(n ast.Node) bool {
			cl, ok := n.(*ast.CompositeLit)
			if !ok {
				return true
			}
			if !strings.HasSuffix(exprString(cl.Type), q.TypeSuffix) {
				return true
			}
			foundType = true
			if r.Region == nil {
				r.Region = region(fs, cl)
			}
			for _, el := range cl.Elts {
				if kv, ok := el.(*ast.KeyValueExpr); ok {
					if id, ok := kv.Key.(*ast.Ident); ok && id.Name == q.Key {
						foundKey = true
					}
				}
			}
			return true
		})
		r.Value = foundType && !foundKey
		r.Detail = map[string]any{"compositeFound": foundType, "keyFound": foundKey}
	case "struct_field_exists":
		s := st(file, q.Struct)
		if s == nil {
			return r
		}
		for _, field := range s.Fields.List {
			for _, name := range field.Names {
				if name.Name != q.Field {
					continue
				}
				if q.JSONTag != "" {
					if field.Tag == nil {
						continue
					}
					tag, _ := strconv.Unquote(field.Tag.Value)
					ok := false
					for _, part := range strings.Fields(tag) {
						if strings.HasPrefix(part, "json:") {
							v := strings.Trim(strings.TrimPrefix(part, "json:"), "\"")
							if strings.Split(v, ",")[0] == q.JSONTag {
								ok = true
							}
						}
					}
					if !ok {
						continue
					}
				}
				r.Value = true
				r.Region = region(fs, field)
				r.Detail = exprString(field.Type)
				return r
			}
		}
	case "assignment_exists_in_function":
		f := fn(file, q.Function)
		if f == nil {
			return r
		}
		ast.Inspect(f, func(n ast.Node) bool {
			a, ok := n.(*ast.AssignStmt)
			if !ok {
				return true
			}
			for i, l := range a.Lhs {
				if i >= len(a.Rhs) {
					continue
				}
				if strings.HasSuffix(exprString(l), q.LHSSuffix) && strings.HasSuffix(exprString(a.Rhs[i]), q.RHSSuffix) {
					r.Value = true
					r.Region = region(fs, a)
					return false
				}
			}
			return true
		})
	case "string_literal_contains_in_function":
		f := fn(file, q.Function)
		if f == nil {
			return r
		}
		for _, s := range literals(f) {
			if strings.Contains(s, q.Substring) {
				r.Value = true
				r.Region = region(fs, f)
				break
			}
		}
	default:
		panic("unknown op: " + q.Op)
	}
	return r
}

func main() {
	qp := flag.String("queries", "", "query pack JSON")
	root := flag.String("root", ".", "capsule root")
	flag.Parse()
	if *qp == "" {
		panic("--queries required")
	}
	b, err := os.ReadFile(*qp)
	if err != nil {
		panic(err)
	}
	var pack QueryPack
	if err = json.Unmarshal(b, &pack); err != nil {
		panic(err)
	}
	files := map[string]*ast.File{}
	sets := map[string]*token.FileSet{}
	for id, rel := range pack.Artifacts {
		src, err := os.ReadFile(*root + "/" + rel)
		if err != nil {
			panic(err)
		}
		wrapped := append([]byte("package evidence\n"), src...)
		fs := token.NewFileSet()
		f, err := parser.ParseFile(fs, rel, wrapped, parser.ParseComments|parser.AllErrors)
		if err != nil {
			panic(fmt.Sprintf("%s parse: %v", id, err))
		}
		files[id] = f
		sets[id] = fs
	}
	results := map[string]Result{}
	for _, q := range pack.Queries {
		results[q.ID] = eval(q, files[q.Artifact], sets[q.Artifact])
	}
	for _, d := range pack.Derivations {
		v := true
		for _, id := range d.AllOf {
			x, ok := results[id]
			if !ok || !x.Value {
				v = false
			}
		}
		results[d.ID] = Result{ID: d.ID, Value: v, Op: "all_of", Detail: d.AllOf}
	}
	keys := make([]string, 0, len(results))
	for k := range results {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	out := struct {
		Protocol string   `json:"protocol"`
		Results  []Result `json:"results"`
	}{Protocol: pack.QueryProtocol}
	for _, k := range keys {
		out.Results = append(out.Results, results[k])
	}
	enc := json.NewEncoder(os.Stdout)
	enc.SetIndent("", "  ")
	if err := enc.Encode(out); err != nil {
		panic(err)
	}
}

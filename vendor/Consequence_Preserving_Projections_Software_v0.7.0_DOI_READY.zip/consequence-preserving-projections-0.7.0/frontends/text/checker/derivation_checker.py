#!/usr/bin/env python3
from pathlib import Path
import argparse,json,hashlib,re,copy,sys

ROOT=Path(__file__).resolve().parents[3]
def J(p): return json.loads(Path(p).read_text(encoding="utf-8"))
def C(o): return json.dumps(o,sort_keys=True,separators=(",",":"),ensure_ascii=False)
def H(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def setpath(o,p,v):
    a=p.split("."); c=o
    for x in a[:-1]: c=c.setdefault(x,{})
    c[a[-1]]=v

def expected_primitive(rule,manifest):
    a=manifest[rule["artifact"]]; p=ROOT/a["path"]
    if H(p)!=a["sha256"]: return ("ERROR",None)
    t=p.read_text(encoding="utf-8")
    op=rule["op"]
    if op=="contains": return ("RESOLVED",rule["needle"] in t)
    if op=="all_contains": return ("RESOLVED",all(n in t for n in rule["needles"]))
    if op=="absent_all":
        if rule.get("requires_complete_scope") and not a["scope"].get("scope_attested_complete"): return ("UNRESOLVED",None)
        return ("RESOLVED",all(n not in t for n in rule["needles"]))
    if op=="regex_absent":
        if rule.get("requires_complete_scope") and not a["scope"].get("scope_attested_complete"): return ("UNRESOLVED",None)
        flags=re.MULTILINE if "MULTILINE" in rule.get("flags",[]) else 0
        return ("RESOLVED",re.search(rule["pattern"],t,flags) is None)
    raise ValueError(op)

def main():
    a=argparse.ArgumentParser()
    a.add_argument("--derivation",required=True); a.add_argument("--compiled-dir",required=True)
    z=a.parse_args()
    d=J(z.derivation); man=J(ROOT/d["artifact_manifest"]); rp=J(ROOT/d["rulepack"]); con=J(ROOT/d["assurance_contract"])
    cd=Path(z.compiled_dir)
    fg=J(cd/"facts.canonical.json"); ir=J(cd/"projection-ir.canonical.json")
    fm={f["id"]:f for f in fg["facts"]}; checks=[]
    def ck(n,c): checks.append({"name":n,"pass":bool(c)})

    # Inputs
    for aid in d["artifact_ids"]:
        ck("ARTIFACT_DIGEST_"+aid,H(ROOT/man[aid]["path"])==man[aid]["sha256"])

    # Primitive facts
    for r in rp["primitive_rules"]:
        st,val=expected_primitive(r,man); got=fm.get(r["id"])
        ck("PRIMITIVE_"+r["id"],got is not None and got.get("status")==st and got.get("value")==val)

    # Derived facts
    for r in rp["derived_rules"]:
        vals=[]
        resolvable=True
        for x in r.get("facts",[]):
            f=fm.get(x)
            if not f or f["status"]!="RESOLVED": resolvable=False; break
            vals.append(bool(f["value"]))
        if not resolvable: st,val="UNRESOLVED",None
        elif r["op"]=="all_of": st,val="RESOLVED",all(vals)
        elif r["op"]=="any_of": st,val="RESOLVED",any(vals)
        elif r["op"]=="not": st,val="RESOLVED",not vals[0]
        else: raise ValueError(r["op"])
        got=fm.get(r["id"])
        ck("DERIVED_"+r["id"],got is not None and got.get("status")==st and got.get("value")==val)

    unresolved=sorted(fid for fid in con["required_facts"] if fid not in fm or fm[fid]["status"]!="RESOLVED" or fm[fid]["value"] is not True)
    ck("REQUIRED_FACT_SET",sorted(fg.get("unresolved_required_facts",[]))==unresolved)

    # Reconstruct semantic IR independently from compiler output.
    exp={
      "ir_version":"0.2","case_id":con["case_id"],"scope":copy.deepcopy(con["scope"]),
      "correspondence":{"status":"UNRESOLVED"},"boundary":copy.deepcopy(con["boundary"]),
      "consequence":copy.deepcopy(con["consequence"]),
      "discriminator":{"signature_by_world":copy.deepcopy(con["discriminator"]["signature_by_world"]),"visibility":"NONE"},
      "discharge":{"gates_effect":"UNKNOWN","evaluation_cut":"UNKNOWN","mode":"UNRESOLVED"},
      "declared_target_model_by_world":copy.deepcopy(con.get("declared_target_model_by_world",{})),
      "target_model_status":copy.deepcopy(con.get("target_model_status",{"kind":"NOT_PROVIDED"})),"coverage":copy.deepcopy(con["coverage"]),
      "evidence":{"strength":con["evidence_strength"],
                  "items":[{"id":aid,"digest":"sha256:"+man[aid]["sha256"]} for aid in d["artifact_ids"]]},
      "field_provenance":{}
    }
    csha=H(ROOT/d["assurance_contract"])
    for p in con["contract_provenance_paths"]: exp["field_provenance"][p]={"kind":"DECLARED_CONTRACT","contract_sha256":csha}
    for b in con["bindings"]:
        f=fm.get(b["fact"]); value=b["false"]; kind="UNRESOLVED"
        if f and f["status"]=="RESOLVED": value=b["true"] if f["value"] else b["false"]; kind="OBSERVED_DERIVED"
        setpath(exp,b["path"],value); exp["field_provenance"][b["path"]]={"kind":kind,"fact_ids":[b["fact"]]}
    for p in ["declared_target_model_by_world","target_model_status","consequence.source_by_world","boundary.worlds","boundary.post_check_material_transition_possible","discriminator.signature_by_world","coverage.source_family","coverage.in_scope"]:
        exp["field_provenance"].setdefault(p,{"kind":"DECLARED_CONTRACT","contract_sha256":csha})

    ck("IR_RECONSTRUCTION_BYTE_EQUAL",C(exp)==C(ir))
    ck("FULL_HAS_NO_UNRESOLVED_REQUIRED",not unresolved)

    out={"checker":"projection-derivation-checker/0.1","checks":checks,
         "passed":sum(x["pass"] for x in checks),"total":len(checks),
         "verdict":"PASS" if all(x["pass"] for x in checks) else "FAIL",
         "ir_sha256":hashlib.sha256(C(ir).encode()).hexdigest(),
         "fact_graph_sha256":hashlib.sha256(C(fg).encode()).hexdigest()}
    print(json.dumps(out,indent=2,sort_keys=True))
    return 0 if out["verdict"]=="PASS" else 2
if __name__=="__main__": raise SystemExit(main())

#!/usr/bin/env python3
from pathlib import Path
import argparse,json,hashlib,sys,re,copy

ROOT=Path(__file__).resolve().parents[3]

def J(p): return json.loads(Path(p).read_text(encoding="utf-8"))
def C(o): return json.dumps(o,sort_keys=True,separators=(",",":"),ensure_ascii=False)
def H_bytes(b): return hashlib.sha256(b).hexdigest()
def H_file(p): return H_bytes(Path(p).read_bytes())

def setpath(obj,path,value):
    parts=path.split("."); cur=obj
    for x in parts[:-1]:
        cur=cur.setdefault(x,{})
    cur[parts[-1]]=value

def region(text,needle):
    i=text.find(needle)
    if i<0: return None
    before=text[:i]
    line=before.count("\n")+1
    col=i-(before.rfind("\n")+1)+1
    endline=line+needle.count("\n")
    return {"startLine":line,"startColumn":col,"endLine":endline}

def primitive(rule, manifest):
    a=manifest[rule["artifact"]]
    p=ROOT/a["path"]; text=p.read_text(encoding="utf-8")
    if H_file(p)!=a["sha256"]:
        return {"id":rule["id"],"status":"ERROR","value":None,
                "error":"ARTIFACT_DIGEST_MISMATCH","rule_id":rule["id"],"artifact":rule["artifact"]}
    op=rule["op"]
    if op=="contains":
        ok=rule["needle"] in text
        ev={"region":region(text,rule["needle"])} if ok else {}
    elif op=="all_contains":
        ok=all(n in text for n in rule["needles"])
        ev={"regions":[region(text,n) for n in rule["needles"] if n in text]}
    elif op=="absent_all":
        if rule.get("requires_complete_scope") and not a["scope"].get("scope_attested_complete"):
            return {"id":rule["id"],"status":"UNRESOLVED","value":None,
                    "error":"NEGATIVE_EVIDENCE_SCOPE_NOT_ATTESTED_COMPLETE",
                    "rule_id":rule["id"],"artifact":rule["artifact"]}
        ok=all(n not in text for n in rule["needles"])
        ev={"negative_scope":a["scope"]}
    elif op=="regex_absent":
        if rule.get("requires_complete_scope") and not a["scope"].get("scope_attested_complete"):
            return {"id":rule["id"],"status":"UNRESOLVED","value":None,
                    "error":"NEGATIVE_EVIDENCE_SCOPE_NOT_ATTESTED_COMPLETE",
                    "rule_id":rule["id"],"artifact":rule["artifact"]}
        flags=0
        if "MULTILINE" in rule.get("flags",[]): flags |= re.MULTILINE
        ok=re.search(rule["pattern"],text,flags) is None
        ev={"negative_scope":a["scope"],"pattern":rule["pattern"]}
    else:
        raise ValueError("unknown primitive op "+op)
    return {
        "id":rule["id"],"status":"RESOLVED","value":bool(ok),
        "rule_id":rule["id"],"artifact":rule["artifact"],
        "artifact_sha256":a["sha256"],"origin":a["origin"],"evidence":ev
    }

def derive(rule,facts):
    vals=[]
    for fid in rule.get("facts",[]):
        f=facts.get(fid)
        if not f or f["status"]!="RESOLVED":
            return {"id":rule["id"],"status":"UNRESOLVED","value":None,
                    "rule_id":rule["id"],"depends_on":rule.get("facts",[])}
        vals.append(bool(f["value"]))
    if rule["op"]=="all_of": v=all(vals)
    elif rule["op"]=="any_of": v=any(vals)
    elif rule["op"]=="not":
        if len(vals)!=1: raise ValueError("not requires one fact")
        v=not vals[0]
    else: raise ValueError("unknown derived op "+rule["op"])
    return {"id":rule["id"],"status":"RESOLVED","value":v,
            "rule_id":rule["id"],"depends_on":rule.get("facts",[])}

def compile_one(derivation_path, outdir, mode_override=None):
    d=J(derivation_path)
    manifest=J(ROOT/d["artifact_manifest"])
    rulepack=J(ROOT/d["rulepack"])
    contract=J(ROOT/d["assurance_contract"])
    mode=mode_override or d.get("mode","full")

    # Verify all derivation inputs by digest.
    materials=[]
    for aid in d["artifact_ids"]:
        a=manifest[aid]; p=ROOT/a["path"]
        actual=H_file(p)
        if actual!=a["sha256"]:
            raise RuntimeError(f"artifact digest mismatch: {aid}")
        materials.append({"id":aid,"path":a["path"],"sha256":actual,"origin":a["origin"]})

    facts={}
    for r in rulepack["primitive_rules"]:
        f=primitive(r,manifest); facts[f["id"]]=f
    for r in rulepack["derived_rules"]:
        f=derive(r,facts); facts[f["id"]]=f

    unresolved=[fid for fid in contract["required_facts"]
                if fid not in facts or facts[fid]["status"]!="RESOLVED" or facts[fid]["value"] is not True]

    ir={
      "ir_version":"0.2",
      "case_id":contract["case_id"],
      "scope":copy.deepcopy(contract["scope"]),
      "correspondence":{"status":"UNRESOLVED"},
      "boundary":copy.deepcopy(contract["boundary"]),
      "consequence":copy.deepcopy(contract["consequence"]),
      "discriminator":{"signature_by_world":copy.deepcopy(contract["discriminator"]["signature_by_world"]),
                       "visibility":"NONE"},
      "discharge":{"gates_effect":"UNKNOWN","evaluation_cut":"UNKNOWN","mode":"UNRESOLVED"},
      "declared_target_model_by_world":copy.deepcopy(contract.get("declared_target_model_by_world",{})),
      "target_model_status":copy.deepcopy(contract.get("target_model_status",{"kind":"NOT_PROVIDED"})),
      "coverage":copy.deepcopy(contract["coverage"]),
      "evidence":{"strength":contract["evidence_strength"],
                  "items":[{"id":m["id"],"digest":"sha256:"+m["sha256"]} for m in materials]},
      "field_provenance":{}
    }

    for p in contract["contract_provenance_paths"]:
        ir["field_provenance"][p]={"kind":"DECLARED_CONTRACT",
                                    "contract_sha256":H_file(ROOT/d["assurance_contract"])}

    for b in contract["bindings"]:
        f=facts.get(b["fact"])
        value=b["false"]
        status="UNRESOLVED"
        if f and f["status"]=="RESOLVED":
            value=b["true"] if f["value"] else b["false"]
            status="OBSERVED_DERIVED"
        setpath(ir,b["path"],value)
        ir["field_provenance"][b["path"]]={"kind":status,"fact_ids":[b["fact"]]}

    # Contract consequence/target model fields remain explicit declarations.
    for p in ["declared_target_model_by_world","target_model_status","consequence.source_by_world","boundary.worlds",
              "boundary.post_check_material_transition_possible",
              "discriminator.signature_by_world","coverage.source_family","coverage.in_scope"]:
        ir["field_provenance"].setdefault(
            p,{"kind":"DECLARED_CONTRACT","contract_sha256":H_file(ROOT/d["assurance_contract"])}
        )

    fact_graph={
      "fact_graph_version":"0.1",
      "derivation_id":d["derivation_id"],
      "facts":[facts[k] for k in sorted(facts)],
      "unresolved_required_facts":sorted(unresolved)
    }

    input_identity={
      "derivation_spec_sha256":H_file(derivation_path),
      "rulepack_sha256":H_file(ROOT/d["rulepack"]),
      "assurance_contract_sha256":H_file(ROOT/d["assurance_contract"]),
      "artifact_manifest_sha256":H_file(ROOT/d["artifact_manifest"]),
      "materials":[{"id":m["id"],"sha256":m["sha256"]} for m in sorted(materials,key=lambda x:x["id"])]
    }

    output_identity={
      "fact_graph_sha256":H_bytes(C(fact_graph).encode()),
      "projection_ir_sha256":H_bytes(C(ir).encode())
    }
    deriv_record={
      "derivation_record_version":"0.1",
      "derivation_id":d["derivation_id"],
      "compiler_engine":"python",
      "mode":mode,
      "inputs":input_identity,
      "outputs":output_identity,
      "status":"FULL_SUCCESS" if not unresolved else ("ANALYSIS_PARTIAL" if mode=="analysis" else "FULL_FAILED"),
      "unresolved_required_facts":sorted(unresolved)
    }

    outdir=Path(outdir); outdir.mkdir(parents=True,exist_ok=True)
    (outdir/"facts.canonical.json").write_text(C(fact_graph)+"\n",encoding="utf-8")
    (outdir/"projection-ir.canonical.json").write_text(C(ir)+"\n",encoding="utf-8")
    (outdir/"derivation-record.canonical.json").write_text(C(deriv_record)+"\n",encoding="utf-8")
    (outdir/"facts.pretty.json").write_text(json.dumps(fact_graph,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    (outdir/"projection-ir.pretty.json").write_text(json.dumps(ir,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    (outdir/"derivation-record.pretty.json").write_text(json.dumps(deriv_record,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    if unresolved and mode=="full": return 2
    return 0

def main():
    a=argparse.ArgumentParser()
    a.add_argument("--derivation",required=True)
    a.add_argument("--outdir",required=True)
    a.add_argument("--mode",choices=["full","analysis"])
    z=a.parse_args()
    return compile_one(Path(z.derivation),Path(z.outdir),z.mode)

if __name__=="__main__": raise SystemExit(main())

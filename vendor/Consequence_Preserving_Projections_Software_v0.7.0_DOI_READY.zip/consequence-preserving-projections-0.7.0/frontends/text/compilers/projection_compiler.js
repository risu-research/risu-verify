#!/usr/bin/env node
const fs=require("fs"), path=require("path"), crypto=require("crypto");
const ROOT=path.resolve(__dirname,"../../..");
function J(p){return JSON.parse(fs.readFileSync(p,"utf8"))}
function sortObj(x){
  if(Array.isArray(x)) return x.map(sortObj);
  if(x && typeof x==="object"){
    const y={}; Object.keys(x).sort().forEach(k=>y[k]=sortObj(x[k])); return y;
  }
  return x;
}
function C(x){return JSON.stringify(sortObj(x))}
function Hbuf(b){return crypto.createHash("sha256").update(b).digest("hex")}
function Hfile(p){return Hbuf(fs.readFileSync(p))}
function setpath(o,p,v){let a=p.split("."),c=o; for(let i=0;i<a.length-1;i++){if(!c[a[i]])c[a[i]]={}; c=c[a[i]];} c[a[a.length-1]]=v;}
function region(t,n){let i=t.indexOf(n); if(i<0)return null; let pre=t.slice(0,i), line=(pre.match(/\n/g)||[]).length+1, last=pre.lastIndexOf("\n"), col=i-last; return {startLine:line,startColumn:col,endLine:line+(n.match(/\n/g)||[]).length};}

function primitive(r,m){
  const a=m[r.artifact], p=path.join(ROOT,a.path), t=fs.readFileSync(p,"utf8");
  if(Hfile(p)!==a.sha256) return {id:r.id,status:"ERROR",value:null,error:"ARTIFACT_DIGEST_MISMATCH",rule_id:r.id,artifact:r.artifact};
  let ok=false,ev={};
  if(r.op==="contains"){ok=t.includes(r.needle); if(ok)ev.region=region(t,r.needle);}
  else if(r.op==="all_contains"){ok=r.needles.every(n=>t.includes(n)); ev.regions=r.needles.filter(n=>t.includes(n)).map(n=>region(t,n));}
  else if(r.op==="absent_all"){
    if(r.requires_complete_scope && !a.scope.scope_attested_complete)
      return {id:r.id,status:"UNRESOLVED",value:null,error:"NEGATIVE_EVIDENCE_SCOPE_NOT_ATTESTED_COMPLETE",rule_id:r.id,artifact:r.artifact};
    ok=r.needles.every(n=>!t.includes(n)); ev.negative_scope=a.scope;
  } else if(r.op==="regex_absent"){
    if(r.requires_complete_scope && !a.scope.scope_attested_complete)
      return {id:r.id,status:"UNRESOLVED",value:null,error:"NEGATIVE_EVIDENCE_SCOPE_NOT_ATTESTED_COMPLETE",rule_id:r.id,artifact:r.artifact};
    let flags=(r.flags||[]).includes("MULTILINE")?"m":"";
    ok=(new RegExp(r.pattern,flags)).test(t)===false; ev={negative_scope:a.scope,pattern:r.pattern};
  } else throw new Error("unknown primitive op "+r.op);
  return {id:r.id,status:"RESOLVED",value:!!ok,rule_id:r.id,artifact:r.artifact,
          artifact_sha256:a.sha256,origin:a.origin,evidence:ev};
}
function derive(r,facts){
  let vals=[];
  for(const id of (r.facts||[])){let f=facts[id]; if(!f||f.status!=="RESOLVED")return {id:r.id,status:"UNRESOLVED",value:null,rule_id:r.id,depends_on:r.facts||[]}; vals.push(!!f.value);}
  let v;
  if(r.op==="all_of")v=vals.every(Boolean);
  else if(r.op==="any_of")v=vals.some(Boolean);
  else if(r.op==="not"){if(vals.length!==1)throw new Error("not requires one fact"); v=!vals[0];}
  else throw new Error("unknown derived op "+r.op);
  return {id:r.id,status:"RESOLVED",value:v,rule_id:r.id,depends_on:r.facts||[]};
}
function main(){
  let args=process.argv.slice(2), opt={};
  for(let i=0;i<args.length;i+=2)opt[args[i].replace(/^--/,"")]=args[i+1];
  const dp=path.resolve(opt.derivation), d=J(dp), manifest=J(path.join(ROOT,d.artifact_manifest));
  const rp=J(path.join(ROOT,d.rulepack)), con=J(path.join(ROOT,d.assurance_contract)), mode=opt.mode||d.mode||"full";
  let mats=[];
  for(const id of d.artifact_ids){let a=manifest[id],p=path.join(ROOT,a.path),actual=Hfile(p); if(actual!==a.sha256)throw new Error("artifact digest mismatch: "+id); mats.push({id,path:a.path,sha256:actual,origin:a.origin});}
  let facts={}; for(const r of rp.primitive_rules){let f=primitive(r,manifest);facts[f.id]=f;} for(const r of rp.derived_rules){let f=derive(r,facts);facts[f.id]=f;}
  let unresolved=con.required_facts.filter(id=>!facts[id]||facts[id].status!=="RESOLVED"||facts[id].value!==true).sort();
  let ir={
    ir_version:"0.2",case_id:con.case_id,scope:JSON.parse(JSON.stringify(con.scope)),
    correspondence:{status:"UNRESOLVED"},boundary:JSON.parse(JSON.stringify(con.boundary)),
    consequence:JSON.parse(JSON.stringify(con.consequence)),
    discriminator:{signature_by_world:JSON.parse(JSON.stringify(con.discriminator.signature_by_world)),visibility:"NONE"},
    discharge:{gates_effect:"UNKNOWN",evaluation_cut:"UNKNOWN",mode:"UNRESOLVED"},
    declared_target_model_by_world:JSON.parse(JSON.stringify(con.declared_target_model_by_world||{})),
    target_model_status:JSON.parse(JSON.stringify(con.target_model_status||{kind:"NOT_PROVIDED"})),
    coverage:JSON.parse(JSON.stringify(con.coverage)),
    evidence:{strength:con.evidence_strength,items:mats.map(x=>({id:x.id,digest:"sha256:"+x.sha256}))},
    field_provenance:{}
  };
  const csha=Hfile(path.join(ROOT,d.assurance_contract));
  for(const p of con.contract_provenance_paths) ir.field_provenance[p]={kind:"DECLARED_CONTRACT",contract_sha256:csha};
  for(const b of con.bindings){
    let f=facts[b.fact],value=b.false,status="UNRESOLVED";
    if(f&&f.status==="RESOLVED"){value=f.value?b.true:b.false;status="OBSERVED_DERIVED";}
    setpath(ir,b.path,value); ir.field_provenance[b.path]={kind:status,fact_ids:[b.fact]};
  }
  for(const p of ["declared_target_model_by_world","target_model_status","consequence.source_by_world","boundary.worlds","boundary.post_check_material_transition_possible","discriminator.signature_by_world","coverage.source_family","coverage.in_scope"])
    if(!ir.field_provenance[p])ir.field_provenance[p]={kind:"DECLARED_CONTRACT",contract_sha256:csha};

  const fg={fact_graph_version:"0.1",derivation_id:d.derivation_id,facts:Object.keys(facts).sort().map(k=>facts[k]),unresolved_required_facts:unresolved};
  mats.sort((a,b)=>a.id.localeCompare(b.id));
  const inp={derivation_spec_sha256:Hfile(dp),rulepack_sha256:Hfile(path.join(ROOT,d.rulepack)),assurance_contract_sha256:csha,artifact_manifest_sha256:Hfile(path.join(ROOT,d.artifact_manifest)),materials:mats.map(x=>({id:x.id,sha256:x.sha256}))};
  const outid={fact_graph_sha256:Hbuf(Buffer.from(C(fg))),projection_ir_sha256:Hbuf(Buffer.from(C(ir)))};
  const dr={derivation_record_version:"0.1",derivation_id:d.derivation_id,compiler_engine:"node",mode,inputs:inp,outputs:outid,status:unresolved.length?(mode==="analysis"?"ANALYSIS_PARTIAL":"FULL_FAILED"):"FULL_SUCCESS",unresolved_required_facts:unresolved};
  const od=path.resolve(opt.outdir); fs.mkdirSync(od,{recursive:true});
  fs.writeFileSync(path.join(od,"facts.canonical.json"),C(fg)+"\n");
  fs.writeFileSync(path.join(od,"projection-ir.canonical.json"),C(ir)+"\n");
  fs.writeFileSync(path.join(od,"derivation-record.canonical.json"),C(dr)+"\n");
  fs.writeFileSync(path.join(od,"facts.pretty.json"),JSON.stringify(sortObj(fg),null,2)+"\n");
  fs.writeFileSync(path.join(od,"projection-ir.pretty.json"),JSON.stringify(sortObj(ir),null,2)+"\n");
  fs.writeFileSync(path.join(od,"derivation-record.pretty.json"),JSON.stringify(sortObj(dr),null,2)+"\n");
  process.exit(unresolved.length&&mode==="full"?2:0);
}
main();

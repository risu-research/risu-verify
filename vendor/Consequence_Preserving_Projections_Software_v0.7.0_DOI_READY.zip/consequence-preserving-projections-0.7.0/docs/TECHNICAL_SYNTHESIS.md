# Technical Synthesis — v0.7.0

Projection Assurance evaluates Correspondence (C), Discrimination (D), Operative Placement (O), Exact Realization, and Coverage relative to a declared source consequence and bounded profile.

v0.5 changed how target semantic tables enter the analysis by compiling d, z, and the mechanism interpretation without the per-world K table as compiler input. v0.6 changed how the resulting claim is consumed by carrying a finite proof that a separate compact checker can validate without the producer verifier stack. v0.7 changes how the **source preservation problem itself is authored**.

A v0.7 Source Consequence Contract declares finite coordinate domains, an admissibility predicate, one total source consequence function, Boundary premises, and a source family. Independent Python and Node source compilers enumerate the complete declared Cartesian domain, generate the admitted realizations, and evaluate K on every admitted world. A separate Projection Adapter is pinned to the exact source-contract file and cannot author the source world set or K table.

After source compilation, target semantic derivation remains consequence-blind. The generated worlds enter the existing v0.5 target compiler, but generated K does not enter the target derivation that constructs d, z, carrier-native outcomes, or the target consequence interpretation. The existing structural and Exact Realization semantics then compare the independently constructed target representation against the generated source consequence.

The v0.7 certificate layers this source separation over the v0.6 finite proof. It carries the exact source-contract file bytes as well as the parsed contract snapshot, allowing the consumer checker to verify the adapter's SHA-256 source pin without trusting the producer or requiring the original contract file. Claim-linked external evidence remains separately rechecked when an evidence root is supplied.

The same immutable source contract can be reused across multiple projections. The retained carrier-neutral reuse example binds two target adapters to one identical source semantic digest while producing opposite Exact Realization outcomes. This makes source-claim identity stable while projection quality varies.

The retained canonical cases remain unchanged in scientific meaning. GitHub has sufficient operative information on the declared fixed-review model but a misaligned effect mechanism. Azure narrows the caller surface while preserving the declared create-if-absent consequence through an effect-time guard and remains incomplete for the broader declared source family.

Carrier-specific extraction remains upstream. The source-contract language, target semantic compiler, verifier, proof format, and consumer checkers remain carrier-neutral. v0.7 narrows authored answer-table surfaces and separates source from target; it does not establish that the declared source model or evidence interpretation is the uniquely correct model of a live system.

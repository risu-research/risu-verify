# Prior-Art Boundary — v0.7

v0.7 is intentionally positioned as a specialized assurance architecture, not as a claim to have invented its individual ingredients.

## Established ideas that are not claimed as new

Contract-based design already associates components with assumptions and guarantees and studies refinement/composition. See A. Cimatti, R. Demasi, and S. Tonetta, “Tightening the contract refinements of a system architecture,” *Formal Methods in System Design* 52 (2018), and earlier contract-refinement work.

Semantic-service systems already make service inputs, outputs, preconditions, effects, process models, and groundings explicit. See D. Martin et al., “OWL-S: Semantic Markup for Web Services,” W3C Member Submission, 2004.

Translation validation already validates the semantics of particular translations rather than requiring a once-for-all proof of the translator. See A. Pnueli, M. Siegel, and E. Singerman, “Translation Validation,” TACAS 1998, doi:10.1007/BFb0054170, and G. C. Necula, “Translation Validation for an Optimizing Compiler,” PLDI 2000, doi:10.1145/349299.349314.

Proof-Carrying Code already separates an untrusted producer from a consumer that checks attached proof evidence against a policy. See G. C. Necula, “Proof-Carrying Code,” POPL 1997, doi:10.1145/263699.263712.

Consumer-driven contract testing, including Pact, already records consumer expectations and replays interactions against providers. OpenAPI Arazzo already provides machine-readable API workflows and dependencies. These are useful neighbors, not novelty targets for this release.

Finite-domain enumeration, executable predicates, functional dependency/determinacy, and canonical hashing are also established techniques and are not claimed as new.

## The specialized gap addressed here

Projection Assurance asks a narrower relation that the above systems do not by themselves settle: for a declared consequence of a source operation, did an agent-facing projection preserve the consequence-relevant distinctions and realize the required consequence at the effect cut?

v0.7 makes that relation operational through a specific combination:

`claim-indexed finite source consequence contract`

→ `complete generated declared domain + functional K`

→ `immutable source-contract / target-adapter separation`

→ `consequence-blind target semantic compilation`

→ `C/D/O + Exact Realization + Coverage`

→ `proof-carrying independently executable checking path`.

The value claim is therefore about this end-to-end assurance boundary and the reduced opportunities for authored per-world answer tuning. It is not a claim of a new general contract calculus, a new refinement order, a new model checker, or a new proof-carrying-code theory.

## Remaining boundary

The software still cannot prove that an analyst chose the right coordinate domains, admissibility predicate, source consequence function, Boundary, or semantic interpretation of retained evidence. Those remain modeling/evidence premises. v0.7 deliberately narrows the authored surface and makes its consequences explicit instead of presenting those premises as mechanically established truths.

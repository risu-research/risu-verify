# Release Status — v0.7.0

v0.7.0 is the Source Consequence Contract / Projection Adapter separation release.

The v0.7 path replaces authored source-world and per-world consequence tables with generated realizations and a functional source consequence contract. Target adapters are pinned to an exact source-contract file, target semantic compilation remains consequence-blind, and the proof-carrying consumer path regenerates the source layer before checking the retained finite proof.

The certificate carries the exact source-contract bytes in addition to the parsed contract snapshot. The consumer checker can therefore verify the adapter's source-file SHA-256 pin without trusting producer code or requiring the original source-contract file. Claim-linked external evidence is rehashed separately when a root is supplied.

Current qualification records include:

- Source-contract compiler conformance: 15/15 vectors with Python/Node differential agreement.
- Source-compiler stress qualification: 200/200 valid three-implementation differentials, 200/200 malformed three-implementation rejections, and 50/50 domain-order/metadata metamorphic invariance checks.
- v0.7 source-contract/adversarial gate: 62/62 PASS.
- Retained v0.5 consequence-blind qualification: 63/63 PASS.
- Retained v0.6 proof-carrying TCB qualification: 77/77 PASS.

Historical continuity is recorded by digest rather than by nesting earlier release archives inside the public package. The current lower-layer files and retained historical qualification records are checked against byte identities recorded from v0.6.0 before sealing this release. The predecessor release itself remains independently identifiable by SHA-256.

The release remains model-relative. It does not claim real-system source-model completeness, semantic truth of evidence interpretation, live-runtime certification, independent authorship, or independent reproduction.

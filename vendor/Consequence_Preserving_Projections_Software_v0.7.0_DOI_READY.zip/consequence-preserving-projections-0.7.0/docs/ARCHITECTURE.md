# Architecture — v0.7.0

v0.7 separates the source claim from the target projection before either reaches the mature semantic verifier.

## Producer path

`Source Consequence Contract v0.7`

→ dual-runtime source compilation

→ complete declared finite-domain generation + functional K

`Projection Adapter v0.7`

→ exact SHA-256 pin to source contract

→ normalization into internal Assurance Bundle v0.5

→ consequence-blind target compilation

→ C/D/O + Coverage + Exact Realization

→ evidence/provenance checks

→ v0.6 finite proof construction

→ outer certificate v0.7

The source compiler and target semantic compiler have different information boundaries. The source compiler may read only source coordinates and source constants. The target compiler receives the generated worlds but cannot read the generated K map while deriving d, z, native outcomes, and their target interpretation.

## Source-domain construction

The Source Consequence Contract does not enumerate realizations. It declares finite coordinate domains. The compiler canonicalizes semantic-equal numeric values, rejects semantic duplicates, forms the full Cartesian product, applies a deterministic admissibility predicate, and assigns a deterministic ID derived from the canonical coordinate object.

K is one total expression over source coordinates/constants. The compiler evaluates it on every admitted realization and rejects any value outside the declared codomain. The domain proof commits the complete generated set and K map.

This establishes completeness relative to the declared finite coordinate domains and admissibility rule, not completeness of the real system model.

## Projection separation

A Projection Adapter cannot define the source worlds or source K table. It names one source-contract path and SHA-256 and supplies only target-side structural premises, target coverage, provenance/evidence, and consequence-blind derivation rules.

Changing the source contract therefore invalidates the existing pin. If the claimed source consequence changes, the projection must be evaluated against a newly identified contract rather than silently receiving a favorable revised K table.

## Consumer path and layered TCB

`certificate v0.7`

→ `checker/risu_contract_pcc_check.py`

→ verify the embedded exact source-contract bytes against the adapter pin

→ independently regenerate source domain and K

→ independently normalize the adapter

→ `checker/risu_pcc_check.py`

→ independently replay target derivation and check the finite proof

→ optional source-contract/evidence byte rehash

→ `PASS / PARTIAL / FAIL`

The v0.7 checker deliberately reuses the already qualified compact v0.6 checker as a lower layer instead of duplicating that proof logic. Neither checker imports the producer verifier, source compiler, target compiler, structural kernel, Exact kernel, or certificate builder.

## Reuse property

A source contract is intended to be stable across projections. The release includes two generic adapters pinned to one identical contract. They generate the same source domain and K but differ at the target mechanism; one is exactly preserving and the other is contradicted by mechanism misalignment. This is an executable separation between source-claim identity and projection quality.

## Carrier boundary

Carrier-specific extraction stays upstream. Source-contract compilation, target semantic compilation, structural/Exact analysis, and the consumer checkers contain no GitHub-, Azure-, or PayPal-specific semantic branch. Canonical cases remain data inputs.

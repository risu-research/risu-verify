# Reproducing v0.7.0

No network access is required.

```sh
./reproduce.sh
```

The replay runs current source-contract compiler conformance, a deterministic Python/Node/standalone-checker source-semantics stress differential, retained structural/Exact/target-compiler regressions, the v0.7 source-contract/adversarial gate, canonical source-contract compilation, producer verification and certificate issuance, layered consumer proof checking, shared-contract reuse checks, evidence-linked no-root `PARTIAL` behavior, and release-integrity verification.

Historical archives are not required for this replay. The public release keeps digest references to earlier release/evidence archives and byte commitments for the inherited lower-layer components. This avoids recursive archive nesting while leaving the predecessor identity externally checkable.

The package's own replay is author-controlled and same-host. A successful local replay is not labeled independent reproduction.

# Using Your Own Projection — v0.7

A new v0.7 projection has two independent authored objects.

## 1. Write the source consequence contract

Start from `projections/examples/shared-contract/source-contract.json`.

Declare finite coordinate domains, source constants if needed, an admissibility predicate, one total consequence expression, the Boundary premise, and the declared source family. Do not enumerate worlds or write K by world.

Check the generated domain before writing or evaluating the target adapter:

```sh
./risu-projection source compile source-contract.json --json
```

Review the Cartesian/admitted/excluded counts, generated world records, source semantic digest, and K-map digest. A passing compiler does not by itself establish that the chosen model is adequate; model review remains a separate responsibility.

## 2. Write the Projection Adapter

Start from `adapter-preserved.json` or one of the canonical adapters. Set `source_contract.path` and its exact file SHA-256. The adapter supplies target structural premises, target coverage, evidence/provenance, and the consequence-blind derivation program.

It cannot supply source worlds, K-by-world, target per-world answer tables, d-by-world, z-by-world, or mechanism-consequence-by-world.

## 3. Verify and issue a certificate

```sh
./risu-projection verify adapter.json \
  --require-source-contract --require-blind \
  --certificate certificate.json
```

For evidence-linked CI:

```sh
./risu-projection verify adapter.json \
  --require-source-contract --require-blind --require-evidence \
  --certificate certificate.json

./risu-pcc-check certificate.json --root .
```

The certificate itself carries the exact source-contract file bytes, so the checker first verifies that embedded object against the adapter pin, then regenerates the source domain/K and checks the finite proof. When `--root` is supplied it additionally requires the root source-contract file to match the embedded bytes exactly and rehashes required claim-linked evidence.

## 4. Reuse the source contract

A second adapter may point to the same exact source contract. This is preferable to copying its generated worlds/K into another case. A source-contract change intentionally changes the identity of the source claim and requires a new pin.

Carrier-specific source extraction remains upstream. v0.7 does not attempt to become a universal parser for Go, C#, TypeScript, OpenAPI, or MCP; it keeps the common semantic trusted surface small.

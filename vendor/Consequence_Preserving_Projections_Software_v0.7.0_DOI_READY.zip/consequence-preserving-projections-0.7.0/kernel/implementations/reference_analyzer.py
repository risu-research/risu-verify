#!/usr/bin/env python3
import json, math, sys
PROTOCOL="risu-projection-conformance/0.4"
SAFE_INT=9007199254740991

def _validate_json_value(v,path='value'):
    if v is None or isinstance(v,(bool,str)): return
    if isinstance(v,(int,float)) and not isinstance(v,bool):
        if isinstance(v,float) and not math.isfinite(v): raise ValueError(f'{path}: non-finite JSON number')
        if float(v).is_integer() and abs(int(v))>SAFE_INT: raise ValueError(f'{path}: integer outside cross-runtime safe range')
        return
    if isinstance(v,list):
        for i,x in enumerate(v): _validate_json_value(x,f'{path}[{i}]')
        return
    if isinstance(v,dict):
        for k,x in v.items():
            if not isinstance(k,str): raise ValueError(f'{path}: non-string object key')
            _validate_json_value(x,f'{path}.{k}')
        return
    raise ValueError(f'{path}: unsupported JSON value type {type(v).__name__}')

def json_equal(a,b):
    _validate_json_value(a); _validate_json_value(b)
    if a is None or b is None: return a is b
    if isinstance(a,bool) or isinstance(b,bool): return isinstance(a,bool) and isinstance(b,bool) and a==b
    if isinstance(a,(int,float)) and isinstance(b,(int,float)) and not isinstance(a,bool) and not isinstance(b,bool): return float(a)==float(b)
    if isinstance(a,str) or isinstance(b,str): return isinstance(a,str) and isinstance(b,str) and a==b
    if isinstance(a,list) or isinstance(b,list): return isinstance(a,list) and isinstance(b,list) and len(a)==len(b) and all(json_equal(x,y) for x,y in zip(a,b))
    if isinstance(a,dict) or isinstance(b,dict): return isinstance(a,dict) and isinstance(b,dict) and set(a)==set(b) and all(json_equal(a[k],b[k]) for k in a)
    return False

def _coverage(p):
    fam=p.get('coverage',{}).get('source_family',[]); ins=p.get('coverage',{}).get('in_scope',[])
    if not isinstance(fam,list) or not isinstance(ins,list): raise ValueError('coverage source_family and in_scope must be arrays')
    if any(not isinstance(x,str) for x in fam+ins): raise ValueError('coverage elements must be strings')
    fs,iset=set(fam),set(ins)
    return fs==iset, {'source_only':sorted(fs-iset),'in_scope_only':sorted(iset-fs)}

def _base(C,D,O,cls,cross,precision,coverage_complete,coverage_gap,**kw):
    r={'C':C,'D':D,'O':O,'structural_classification':cls,'declared_model_crosscheck':cross,'precision':precision,
       'coverage_complete':coverage_complete,'coverage_gap':coverage_gap,'D_witness':None,'overdiscrimination_witness':None,'O_basis':None}
    r.update(kw); return r

def evaluate(p):
    coverage_complete,coverage_gap=_coverage(p)
    if p['scope']['status']=='OUTSIDE_DECLARED_SCOPE':
        return _base('NA','NA','NA','OUTSIDE_DECLARED_SCOPE','NA','NA',coverage_complete,coverage_gap)
    cs=p['correspondence']['status']
    if cs=='NOT_ESTABLISHED':
        return _base('C0','NA','NA','CORRESPONDENCE_NOT_ESTABLISHED','NA','NA',coverage_complete,coverage_gap)
    if cs=='UNRESOLVED':
        return _base('CU','NA','NA','UNRESOLVED','NA','NA',coverage_complete,coverage_gap)
    if cs!='ESTABLISHED': raise ValueError(f'unsupported correspondence status {cs!r}')
    worlds=p['boundary']['worlds']; src=p['consequence']['source_by_world']; sig=p['discriminator']['signature_by_world']
    if not isinstance(worlds,list) or not worlds: raise ValueError('boundary.worlds must be a nonempty array')
    if any(not isinstance(w,str) for w in worlds): raise ValueError('world identifiers must be strings')
    if len(set(worlds))!=len(worlds): raise ValueError('boundary.worlds contains duplicates')
    for w in worlds:
        if w not in src or w not in sig: raise ValueError(f'world {w!r} missing consequence or discriminator signature')
        _validate_json_value(sig[w],f'signature[{w}]'); _validate_json_value(src[w],f'consequence[{w}]')
    d_witness=None
    for i,a in enumerate(worlds):
        for b in worlds[i+1:]:
            if json_equal(sig[a],sig[b]) and not json_equal(src[a],src[b]):
                d_witness={'worlds':[a,b],'signature':sig[a],'consequences':[src[a],src[b]]}; break
        if d_witness: break
    D='D0' if d_witness else 'D1'; precision='NA'; over_witness=None
    if D=='D1':
        for i,a in enumerate(worlds):
            for b in worlds[i+1:]:
                if json_equal(src[a],src[b]) and not json_equal(sig[a],sig[b]):
                    over_witness={'worlds':[a,b],'consequence':src[a],'signatures':[sig[a],sig[b]]}; break
            if over_witness: break
        precision='OVERDISCRIMINATING_ON_DECLARED_WORLDS' if over_witness else 'CONSEQUENCE_EXACT_PARTITION'
    g=p['discharge']['gates_effect']; cut=p['discharge']['evaluation_cut']; post=p['boundary']['post_check_material_transition_possible']
    basis={'gates_effect':g,'evaluation_cut':cut,'post_check_material_transition_possible':post}
    if g=='UNKNOWN' or cut=='UNKNOWN': O='OU'
    elif g is False or cut=='NONE': O='O0'
    elif g is True and cut=='ENVIRONMENT': O='O1_REPLACED'
    elif g is True and cut=='EFFECT': O='O1'
    elif g is True and cut=='PRE_EFFECT': O='O0' if post else 'O1'
    else: O='OU'
    if D=='D0': cls='DISCRIMINATION_INADEQUATE'
    elif O=='O0': cls='OPERATIVE_DISCHARGE_MISSING'
    elif O=='OU': cls='UNRESOLVED'
    else: cls='STRUCTURAL_ASSURANCE_ESTABLISHED'
    model=p.get('declared_target_model_by_world')
    if not model: cross='DECLARED_MODEL_NOT_PROVIDED'
    else:
        cross='DECLARED_MODEL_MATCH' if all(w in model and json_equal(model[w],src[w]) for w in worlds) else 'DECLARED_MODEL_MISMATCH'
    return {'C':'C1','D':D,'O':O,'structural_classification':cls,'declared_model_crosscheck':cross,'precision':precision,
            'coverage_complete':coverage_complete,'coverage_gap':coverage_gap,'D_witness':d_witness,'overdiscrimination_witness':over_witness,
            'O_basis':basis,'claim_level':'STRUCTURAL_ONLY' if cross=='DECLARED_MODEL_NOT_PROVIDED' else 'STRUCTURAL_PLUS_DECLARED_MODEL_CROSSCHECK'}

def main():
    for line in sys.stdin:
        if not line.strip(): continue
        q=None
        try:
            q=json.loads(line); out={'protocol':PROTOCOL,'request_id':q.get('request_id'),'ok':True,'result':evaluate(q['profile'])}
        except Exception as e:
            out={'protocol':PROTOCOL,'request_id':q.get('request_id') if isinstance(q,dict) else None,'ok':False,'error':str(e)}
        print(json.dumps(out,sort_keys=True,separators=(',',':')),flush=True)
if __name__=='__main__': main()

#!/usr/bin/env python3
from pathlib import Path
import subprocess,json,argparse,xml.etree.ElementTree as ET,shlex
ROOT=Path(__file__).resolve().parents[1]; PROTOCOL='risu-projection-conformance/0.4'
def subset(g,e):
    for k,v in e.items():
        if g.get(k)!=v:return False,f'{k}: expected {v!r}, got {g.get(k)!r}'
    return True,''
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--testee-cmd',required=True);ap.add_argument('--vectors',default=str(ROOT/'vectors'));ap.add_argument('--expected',default=str(ROOT/'VECTOR_EXPECTATIONS_v0.4.json'));ap.add_argument('--json-out',required=True);ap.add_argument('--junit-out',required=True);a=ap.parse_args()
    exp=json.loads(Path(a.expected).read_text());vd=Path(a.vectors);proc=subprocess.Popen(shlex.split(a.testee_cmd),stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True,bufsize=1);rows=[]
    try:
      for vid in sorted(exp):
        prof=json.loads((vd/f'{vid}.json').read_text());req={'protocol':PROTOCOL,'request_id':vid,'op':'evaluate','profile':prof};proc.stdin.write(json.dumps(req,separators=(',',':'))+'\n');proc.stdin.flush();line=proc.stdout.readline();resp=json.loads(line);ok=resp.get('ok',False);match=False;detail=''
        if ok:match,detail=subset(resp['result'],exp[vid])
        else:detail=resp.get('error','testee error')
        rows.append({'id':vid,'pass':bool(ok and match),'detail':detail,'result':resp.get('result'),'expected':exp[vid]})
    finally:
      if proc.stdin and not proc.stdin.closed:proc.stdin.close()
      proc.terminate();proc.wait(timeout=5)
    report={'protocol':PROTOCOL,'testee_cmd':a.testee_cmd,'total':len(rows),'passed':sum(r['pass'] for r in rows),'results':rows,'verdict':'PASS' if all(r['pass'] for r in rows) else 'FAIL'};Path(a.json_out).write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');suite=ET.Element('testsuite',name='projection-assurance-conformance-v0.4',tests=str(len(rows)),failures=str(sum(not r['pass'] for r in rows)))
    for r in rows:
      tc=ET.SubElement(suite,'testcase',name=r['id']);
      if not r['pass']:f=ET.SubElement(tc,'failure',message=r['detail']);f.text=json.dumps(r,sort_keys=True)
    ET.ElementTree(suite).write(a.junit_out,encoding='utf-8',xml_declaration=True);print(json.dumps({'verdict':report['verdict'],'passed':report['passed'],'total':report['total']}));return 0 if report['verdict']=='PASS' else 2
if __name__=='__main__':raise SystemExit(main())

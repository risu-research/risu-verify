# Third-Party Notices

This research package retains small source blocks for reproducible source-grounded analysis. These excerpts remain subject to their upstream licenses.

- `evidence/github/merge_pull_request.block.go` and `minimal_pull_request.block.go`: GitHub MCP Server, copyright GitHub, MIT License.
- `evidence/github/source_merge_guard.block.go`: go-github, copyright the go-github authors, BSD-style license.
- `evidence/azure/blob_upload_command.block.cs`, `blob_upload_options.block.cs`, `storage_upload_blob.block.cs`: Microsoft Azure MCP Server, copyright Microsoft Corporation, MIT License.
- `evidence/azure/sdk_upload_false_guard.block.cs`: Azure SDK for .NET, copyright Microsoft, MIT License.

See `third_party/licenses/`. Repository/ref/path/blob identities are recorded in `evidence/ARTIFACT_MANIFEST.json`.

License texts with retained upstream copyright notices are provided as `GitHub-MCP-MIT.txt`, `Microsoft-MCP-MIT.txt`, `Azure-SDK-MIT.txt`, and `go-github-BSD.txt`.

#!/usr/bin/env python3
from pathlib import Path
import argparse,json,shlex,subprocess
ROOT=Path(__file__).resolve().parents[1]
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--testee-cmd',required=True);ap.add_argument('--json-out');a=ap.parse_args();vectors=[json.loads(p.read_text()) for p in sorted((ROOT/'vectors').glob('C*.json'))]
    cmd=shlex.split(a.testee_cmd)+['--jsonl'];pr=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,bufsize=1);rows=[]
    try:
        for v in vectors:
            pr.stdin.write(json.dumps(v['payload'],separators=(',',':'))+'\n');pr.stdin.flush();line=pr.stdout.readline()
            if not line:raise RuntimeError('compiler stream ended early: '+pr.stderr.read()[-300:])
            o=json.loads(line);ok=bool(o.get('ok'));passed=(ok==v['accept']);rows.append({'id':v['id'],'status':'PASS' if passed else 'FAIL','expected_accept':v['accept'],'actual_ok':ok,'error':o.get('error'),'result':o.get('result') if v['accept'] else None})
    finally:
        pr.stdin.close();pr.wait(timeout=10)
    rep={'protocol':'risu-semantic-compiler-conformance/0.5','status':'PASS' if all(x['status']=='PASS' for x in rows) else 'FAIL','passed':sum(x['status']=='PASS' for x in rows),'total':len(rows),'checks':rows}
    if a.json_out:Path(a.json_out).write_text(json.dumps(rep,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status':rep['status'],'passed':rep['passed'],'total':rep['total']}));return 0 if rep['status']=='PASS' else 2
if __name__=='__main__':raise SystemExit(main())

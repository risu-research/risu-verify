#!/usr/bin/env python3
import json, math, sys

PROTOCOL='risu-semantic-compiler/0.5'
SAFE_INT=9007199254740991
STAGES={
    'discriminator': {'world','const'},
    'operative_signature': {'world','const'},
    'mechanism': {'z','const'},
    'interpreter': {'native','const'},
}
OPS={'literal','get','object','array','if','eq','neq','and','or','not','is_null'}

def fail(msg):
    raise ValueError(msg)

def validate_json(v,path='value'):
    if v is None or isinstance(v,(bool,str)): return
    if isinstance(v,(int,float)) and not isinstance(v,bool):
        if isinstance(v,float) and not math.isfinite(v): fail(f'{path}: non-finite JSON number')
        if float(v).is_integer() and abs(int(v))>SAFE_INT: fail(f'{path}: integer outside cross-runtime safe range')
        return
    if isinstance(v,list):
        for i,x in enumerate(v): validate_json(x,f'{path}[{i}]')
        return
    if isinstance(v,dict):
        for k,x in v.items():
            if not isinstance(k,str): fail(f'{path}: non-string object key')
            validate_json(x,f'{path}.{k}')
        return
    fail(f'{path}: unsupported JSON value type {type(v).__name__}')

def json_equal(a,b):
    validate_json(a); validate_json(b)
    if a is None or b is None: return a is b
    if isinstance(a,bool) or isinstance(b,bool): return isinstance(a,bool) and isinstance(b,bool) and a==b
    if isinstance(a,(int,float)) and isinstance(b,(int,float)) and not isinstance(a,bool) and not isinstance(b,bool): return float(a)==float(b)
    if isinstance(a,str) or isinstance(b,str): return isinstance(a,str) and isinstance(b,str) and a==b
    if isinstance(a,list) or isinstance(b,list): return isinstance(a,list) and isinstance(b,list) and len(a)==len(b) and all(json_equal(x,y) for x,y in zip(a,b))
    if isinstance(a,dict) or isinstance(b,dict): return isinstance(a,dict) and isinstance(b,dict) and set(a)==set(b) and all(json_equal(a[k],b[k]) for k in a)
    return False

def require_keys(obj,allowed,required,path):
    if not isinstance(obj,dict): fail(f'{path} must be an object')
    extra=set(obj)-set(allowed)
    if extra: fail(f'{path}: unknown keys {sorted(extra)}')
    missing=set(required)-set(obj)
    if missing: fail(f'{path}: missing keys {sorted(missing)}')

def get_path(src,path,where):
    if not isinstance(path,list) or any(not isinstance(x,str) or not x for x in path): fail(f'{where}: path must be an array of nonempty strings')
    cur=src
    for part in path:
        if not isinstance(cur,dict) or part not in cur: fail(f'{where}: missing path component {part!r}')
        cur=cur[part]
    return cur

def validate_expr(expr,allowed_sources,path='expr',depth=0):
    if depth>64: fail(f'{path}: expression nesting exceeds 64')
    if not isinstance(expr,dict): fail(f'{path}: expression must be an object')
    op=expr.get('op')
    if op not in OPS: fail(f'{path}: unsupported op {op!r}')
    if op=='literal':
        require_keys(expr,{'op','value'},{'op','value'},path); validate_json(expr['value'],path+'.value'); return
    if op=='get':
        require_keys(expr,{'op','source','path'},{'op','source','path'},path)
        if expr['source'] not in allowed_sources: fail(f'{path}: source {expr["source"]!r} not permitted in this stage')
        if not isinstance(expr['path'],list) or any(not isinstance(x,str) or not x for x in expr['path']): fail(f'{path}: get.path must be an array of nonempty strings')
        return
    if op=='object':
        require_keys(expr,{'op','fields'},{'op','fields'},path)
        if not isinstance(expr['fields'],dict): fail(f'{path}.fields must be an object')
        for k,v in expr['fields'].items():
            if not isinstance(k,str) or not k: fail(f'{path}.fields contains invalid key')
            validate_expr(v,allowed_sources,f'{path}.fields.{k}',depth+1)
        return
    if op=='array':
        require_keys(expr,{'op','items'},{'op','items'},path)
        if not isinstance(expr['items'],list): fail(f'{path}.items must be an array')
        for i,v in enumerate(expr['items']): validate_expr(v,allowed_sources,f'{path}.items[{i}]',depth+1)
        return
    if op=='if':
        require_keys(expr,{'op','cond','then','else'},{'op','cond','then','else'},path)
        validate_expr(expr['cond'],allowed_sources,path+'.cond',depth+1);validate_expr(expr['then'],allowed_sources,path+'.then',depth+1);validate_expr(expr['else'],allowed_sources,path+'.else',depth+1);return
    if op in {'eq','neq'}:
        require_keys(expr,{'op','left','right'},{'op','left','right'},path)
        validate_expr(expr['left'],allowed_sources,path+'.left',depth+1);validate_expr(expr['right'],allowed_sources,path+'.right',depth+1);return
    if op in {'and','or'}:
        require_keys(expr,{'op','args'},{'op','args'},path)
        if not isinstance(expr['args'],list) or not expr['args']: fail(f'{path}.args must be a nonempty array')
        for i,v in enumerate(expr['args']):validate_expr(v,allowed_sources,f'{path}.args[{i}]',depth+1)
        return
    if op in {'not','is_null'}:
        require_keys(expr,{'op','expr'},{'op','expr'},path);validate_expr(expr['expr'],allowed_sources,path+'.expr',depth+1);return

def read_footprint(expr):
    """Return the exact semantic input paths referenced by an expression."""
    reads=set()
    def walk(x):
        if not isinstance(x,dict): return
        op=x.get('op')
        if op=='get': reads.add((x['source'],tuple(x['path']))); return
        if op=='object':
            for v in x['fields'].values(): walk(v)
        elif op=='array':
            for v in x['items']: walk(v)
        elif op=='if': walk(x['cond']);walk(x['then']);walk(x['else'])
        elif op in {'eq','neq'}: walk(x['left']);walk(x['right'])
        elif op in {'and','or'}:
            for v in x['args']: walk(v)
        elif op in {'not','is_null'}: walk(x['expr'])
    walk(expr)
    return [{'source':src,'path':list(path)} for src,path in sorted(reads,key=lambda q:(q[0],json.dumps(list(q[1]),ensure_ascii=False,separators=(',',':'))))]

def eval_expr(expr,env,path='expr',depth=0):
    if depth>64: fail(f'{path}: expression nesting exceeds 64')
    op=expr['op']
    if op=='literal': return expr['value']
    if op=='get': return get_path(env[expr['source']],expr['path'],path)
    if op=='object': return {k:eval_expr(v,env,f'{path}.{k}',depth+1) for k,v in expr['fields'].items()}
    if op=='array': return [eval_expr(v,env,f'{path}[{i}]',depth+1) for i,v in enumerate(expr['items'])]
    if op=='eq': return json_equal(eval_expr(expr['left'],env,path+'.left',depth+1),eval_expr(expr['right'],env,path+'.right',depth+1))
    if op=='neq': return not json_equal(eval_expr(expr['left'],env,path+'.left',depth+1),eval_expr(expr['right'],env,path+'.right',depth+1))
    if op=='not':
        v=eval_expr(expr['expr'],env,path+'.expr',depth+1)
        if type(v) is not bool: fail(f'{path}: not operand must be boolean')
        return not v
    if op=='is_null': return eval_expr(expr['expr'],env,path+'.expr',depth+1) is None
    if op in {'and','or'}:
        vals=[eval_expr(v,env,f'{path}.args[{i}]',depth+1) for i,v in enumerate(expr['args'])]
        if any(type(v) is not bool for v in vals): fail(f'{path}: {op} operands must be boolean')
        return all(vals) if op=='and' else any(vals)
    if op=='if':
        c=eval_expr(expr['cond'],env,path+'.cond',depth+1)
        if type(c) is not bool: fail(f'{path}: if condition must be boolean')
        return eval_expr(expr['then'] if c else expr['else'],env,path+('.then' if c else '.else'),depth+1)
    fail(f'{path}: unsupported op {op!r}')

def stage_spec(program,name,required=True):
    v=program.get(name)
    if v is None:
        if required: fail(f'program.{name} required')
        return None
    require_keys(v,{'required_fact_ids','expr'},{'required_fact_ids','expr'},f'program.{name}')
    facts=v['required_fact_ids']
    if not isinstance(facts,list) or any(not isinstance(x,str) or not x for x in facts) or len(set(facts))!=len(facts): fail(f'program.{name}.required_fact_ids must be a unique string array')
    validate_expr(v['expr'],STAGES[name],f'program.{name}.expr')
    return v

def validate_payload(p):
    require_keys(p,{'protocol','worlds','profile_constants','established_facts','exact_enabled','program'},{'protocol','worlds','profile_constants','established_facts','exact_enabled','program'},'payload')
    if p['protocol']!=PROTOCOL: fail(f'protocol must be {PROTOCOL}')
    if not isinstance(p['worlds'],list) or not p['worlds']: fail('worlds must be a nonempty array')
    ids=set()
    for i,w in enumerate(p['worlds']):
        require_keys(w,{'id','coordinates'},{'id','coordinates'},f'worlds[{i}]')
        if not isinstance(w['id'],str) or not w['id'] or w['id'] in ids: fail(f'worlds[{i}].id invalid or duplicate')
        ids.add(w['id']);
        if not isinstance(w['coordinates'],dict): fail(f'worlds[{i}].coordinates must be an object')
        if 'id' in w['coordinates']: fail(f'worlds[{i}].coordinates may not contain reserved key id')
        validate_json(w['coordinates'],f'worlds[{i}].coordinates')
    if not isinstance(p['profile_constants'],dict): fail('profile_constants must be an object')
    validate_json(p['profile_constants'],'profile_constants')
    facts=p['established_facts']
    if not isinstance(facts,list) or any(not isinstance(x,str) or not x for x in facts) or len(set(facts))!=len(facts): fail('established_facts must be a unique string array')
    if type(p['exact_enabled']) is not bool: fail('exact_enabled must be boolean')
    prog=p['program'];require_keys(prog,{'program_version','discriminator','operative_signature','mechanism','interpreter'},{'program_version','discriminator'},'program')
    if prog['program_version']!='0.5': fail('program_version must be 0.5')
    stage_spec(prog,'discriminator',True)
    for n in ('operative_signature','mechanism','interpreter'): stage_spec(prog,n,p['exact_enabled'])
    if not p['exact_enabled'] and any(prog.get(n) is not None for n in ('operative_signature','mechanism','interpreter')): fail('exact-disabled program must omit operative_signature, mechanism, and interpreter')
    established=set(facts)
    for n in ('discriminator','operative_signature','mechanism','interpreter'):
        spec=prog.get(n)
        if spec:
            missing=[x for x in spec['required_fact_ids'] if x not in established]
            if missing: fail(f'program.{n} missing established facts: {missing}')
    return True

def find_group(groups,value):
    for g in groups:
        if json_equal(g['value'],value): return g
    return None

def normalize_interpretation(v,native):
    if not isinstance(v,dict) or set(v) not in ({'space','label'},{'space','native'}): fail('interpreter must return exactly {space:C,label:...} or {space:OUTSIDE_C,native:...}')
    if v.get('space')=='C': validate_json(v['label'],'interpreter.label');return v
    if v.get('space')=='OUTSIDE_C':
        if not json_equal(v['native'],native): fail('OUTSIDE_C interpreter.native must equal the native outcome being interpreted')
        return v
    fail('interpreter space must be C or OUTSIDE_C')

def compile_payload(p):
    validate_payload(p)
    prog=p['program'];const=p['profile_constants'];disc={};z_by={};native_by={};alpha_by={}
    for w in p['worlds']:
        wid=w['id'];env={'world':w['coordinates'],'const':const}
        d=eval_expr(prog['discriminator']['expr'],env,'discriminator');validate_json(d,f'discriminator[{wid}]');disc[wid]=d
        if p['exact_enabled']:
            z=eval_expr(prog['operative_signature']['expr'],env,'operative_signature');validate_json(z,f'z[{wid}]');z_by[wid]=z
    fibers=[]
    if p['exact_enabled']:
        for w in p['worlds']:
            wid=w['id'];z=z_by[wid];g=find_group(fibers,z)
            if g is None:
                native=eval_expr(prog['mechanism']['expr'],{'z':z,'const':const},'mechanism');validate_json(native,'native')
                alpha=normalize_interpretation(eval_expr(prog['interpreter']['expr'],{'native':native,'const':const},'interpreter'),native)
                g={'value':z,'native':native,'interpretation':alpha,'worlds':[]};fibers.append(g)
            g['worlds'].append(wid);native_by[wid]=g['native'];alpha_by[wid]=g['interpretation']
    out={
      'protocol':PROTOCOL,
      'derived':{'discriminator_signature_by_world':disc},
      'stage_fact_requirements':{n:list(prog[n]['required_fact_ids']) for n in ('discriminator','operative_signature','mechanism','interpreter') if prog.get(n) is not None},
      'stage_input_footprint':{n:read_footprint(prog[n]['expr']) for n in ('discriminator','operative_signature','mechanism','interpreter') if prog.get(n) is not None},
      'mechanism_fibers':[]
    }
    if p['exact_enabled']:
        out['derived'].update({'operative_signature_by_world':z_by,'native_outcome_by_world':native_by,'mechanism_consequence_by_world':alpha_by})
        out['mechanism_fibers']=[{'operative_signature':g['value'],'native_outcome':g['native'],'mechanism_consequence':g['interpretation'],'worlds':g['worlds']} for g in fibers]
    return out

def _one(raw):
    try:
        p=json.loads(raw);return {'ok':True,'result':compile_payload(p)}
    except Exception as e:return {'ok':False,'error':str(e)}

def main():
    if '--jsonl' in sys.argv[1:]:
        for line in sys.stdin:
            if not line.strip():continue
            out=_one(line);sys.stdout.write(json.dumps(out,sort_keys=True,separators=(',',':'),ensure_ascii=False)+'\n');sys.stdout.flush()
        return 0
    out=_one(sys.stdin.read());sys.stdout.write(json.dumps(out,sort_keys=True,separators=(',',':'),ensure_ascii=False)+'\n');return 0 if out['ok'] else 2
if __name__=='__main__': raise SystemExit(main())

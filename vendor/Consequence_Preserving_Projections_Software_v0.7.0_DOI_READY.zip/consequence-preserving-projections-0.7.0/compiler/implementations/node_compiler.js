#!/usr/bin/env node
'use strict';
const PROTOCOL='risu-semantic-compiler/0.5';
const SAFE_INT=9007199254740991;
const STAGES={discriminator:new Set(['world','const']),operative_signature:new Set(['world','const']),mechanism:new Set(['z','const']),interpreter:new Set(['native','const'])};
const OPS=new Set(['literal','get','object','array','if','eq','neq','and','or','not','is_null']);
function fail(m){throw new Error(m)}
function isObj(v){return v!==null && typeof v==='object' && !Array.isArray(v)}
function validateJson(v,path='value'){
  if(v===null||typeof v==='boolean'||typeof v==='string')return;
  if(typeof v==='number'){
    if(!Number.isFinite(v))fail(`${path}: non-finite JSON number`);
    if(Number.isInteger(v)&&Math.abs(v)>SAFE_INT)fail(`${path}: integer outside cross-runtime safe range`);
    return;
  }
  if(Array.isArray(v)){v.forEach((x,i)=>validateJson(x,`${path}[${i}]`));return;}
  if(isObj(v)){for(const [k,x] of Object.entries(v)){if(typeof k!=='string')fail(`${path}: non-string object key`);validateJson(x,`${path}.${k}`);}return;}
  fail(`${path}: unsupported JSON value type ${typeof v}`);
}
function jsonEqual(a,b){
  validateJson(a);validateJson(b);
  if(a===null||b===null)return a===b;
  if(typeof a==='boolean'||typeof b==='boolean')return typeof a==='boolean'&&typeof b==='boolean'&&a===b;
  if(typeof a==='number'||typeof b==='number')return typeof a==='number'&&typeof b==='number'&&a===b;
  if(typeof a==='string'||typeof b==='string')return typeof a==='string'&&typeof b==='string'&&a===b;
  if(Array.isArray(a)||Array.isArray(b))return Array.isArray(a)&&Array.isArray(b)&&a.length===b.length&&a.every((x,i)=>jsonEqual(x,b[i]));
  if(isObj(a)||isObj(b)){
    if(!isObj(a)||!isObj(b))return false;
    const ak=Object.keys(a).sort(),bk=Object.keys(b).sort();
    return ak.length===bk.length&&ak.every((k,i)=>k===bk[i]&&jsonEqual(a[k],b[k]));
  }
  return false;
}
function requireKeys(obj,allowed,required,path){
  if(!isObj(obj))fail(`${path} must be an object`);
  const extra=Object.keys(obj).filter(k=>!allowed.includes(k)).sort();if(extra.length)fail(`${path}: unknown keys ${JSON.stringify(extra)}`);
  const missing=required.filter(k=>!(k in obj)).sort();if(missing.length)fail(`${path}: missing keys ${JSON.stringify(missing)}`);
}
function getPath(src,path,where){
  if(!Array.isArray(path)||path.some(x=>typeof x!=='string'||!x))fail(`${where}: path must be an array of nonempty strings`);
  let cur=src;for(const part of path){if(!isObj(cur)||!(part in cur))fail(`${where}: missing path component ${JSON.stringify(part)}`);cur=cur[part];}return cur;
}
function validateExpr(expr,allowedSources,path='expr',depth=0){
  if(depth>64)fail(`${path}: expression nesting exceeds 64`);if(!isObj(expr))fail(`${path}: expression must be an object`);const op=expr.op;if(!OPS.has(op))fail(`${path}: unsupported op ${JSON.stringify(op)}`);
  if(op==='literal'){requireKeys(expr,['op','value'],['op','value'],path);validateJson(expr.value,`${path}.value`);return;}
  if(op==='get'){requireKeys(expr,['op','source','path'],['op','source','path'],path);if(!allowedSources.has(expr.source))fail(`${path}: source ${JSON.stringify(expr.source)} not permitted in this stage`);if(!Array.isArray(expr.path)||expr.path.some(x=>typeof x!=='string'||!x))fail(`${path}: get.path must be an array of nonempty strings`);return;}
  if(op==='object'){requireKeys(expr,['op','fields'],['op','fields'],path);if(!isObj(expr.fields))fail(`${path}.fields must be an object`);for(const [k,v] of Object.entries(expr.fields)){if(!k)fail(`${path}.fields contains invalid key`);validateExpr(v,allowedSources,`${path}.fields.${k}`,depth+1);}return;}
  if(op==='array'){requireKeys(expr,['op','items'],['op','items'],path);if(!Array.isArray(expr.items))fail(`${path}.items must be an array`);expr.items.forEach((v,i)=>validateExpr(v,allowedSources,`${path}.items[${i}]`,depth+1));return;}
  if(op==='if'){requireKeys(expr,['op','cond','then','else'],['op','cond','then','else'],path);validateExpr(expr.cond,allowedSources,`${path}.cond`,depth+1);validateExpr(expr.then,allowedSources,`${path}.then`,depth+1);validateExpr(expr.else,allowedSources,`${path}.else`,depth+1);return;}
  if(op==='eq'||op==='neq'){requireKeys(expr,['op','left','right'],['op','left','right'],path);validateExpr(expr.left,allowedSources,`${path}.left`,depth+1);validateExpr(expr.right,allowedSources,`${path}.right`,depth+1);return;}
  if(op==='and'||op==='or'){requireKeys(expr,['op','args'],['op','args'],path);if(!Array.isArray(expr.args)||!expr.args.length)fail(`${path}.args must be a nonempty array`);expr.args.forEach((v,i)=>validateExpr(v,allowedSources,`${path}.args[${i}]`,depth+1));return;}
  if(op==='not'||op==='is_null'){requireKeys(expr,['op','expr'],['op','expr'],path);validateExpr(expr.expr,allowedSources,`${path}.expr`,depth+1);return;}
}
function readFootprint(expr){
  const seen=new Map();
  function walk(x){
    if(!isObj(x))return;const op=x.op;
    if(op==='get'){const key=JSON.stringify([x.source,x.path]);seen.set(key,{source:x.source,path:[...x.path]});return;}
    if(op==='object')Object.values(x.fields).forEach(walk);
    else if(op==='array')x.items.forEach(walk);
    else if(op==='if'){walk(x.cond);walk(x.then);walk(x.else);}
    else if(op==='eq'||op==='neq'){walk(x.left);walk(x.right);}
    else if(op==='and'||op==='or')x.args.forEach(walk);
    else if(op==='not'||op==='is_null')walk(x.expr);
  }
  walk(expr);
  return [...seen.values()].sort((a,b)=>{const ak=a.source+'\u0000'+JSON.stringify(a.path),bk=b.source+'\u0000'+JSON.stringify(b.path);return ak<bk?-1:(ak>bk?1:0);});
}
function evalExpr(expr,env,path='expr',depth=0){
  if(depth>64)fail(`${path}: expression nesting exceeds 64`);const op=expr.op;
  if(op==='literal')return expr.value;
  if(op==='get')return getPath(env[expr.source],expr.path,path);
  if(op==='object'){const o={};for(const [k,v] of Object.entries(expr.fields))o[k]=evalExpr(v,env,`${path}.${k}`,depth+1);return o;}
  if(op==='array')return expr.items.map((v,i)=>evalExpr(v,env,`${path}[${i}]`,depth+1));
  if(op==='eq')return jsonEqual(evalExpr(expr.left,env,`${path}.left`,depth+1),evalExpr(expr.right,env,`${path}.right`,depth+1));
  if(op==='neq')return !jsonEqual(evalExpr(expr.left,env,`${path}.left`,depth+1),evalExpr(expr.right,env,`${path}.right`,depth+1));
  if(op==='not'){const v=evalExpr(expr.expr,env,`${path}.expr`,depth+1);if(typeof v!=='boolean')fail(`${path}: not operand must be boolean`);return !v;}
  if(op==='is_null')return evalExpr(expr.expr,env,`${path}.expr`,depth+1)===null;
  if(op==='and'||op==='or'){const vals=expr.args.map((v,i)=>evalExpr(v,env,`${path}.args[${i}]`,depth+1));if(vals.some(v=>typeof v!=='boolean'))fail(`${path}: ${op} operands must be boolean`);return op==='and'?vals.every(Boolean):vals.some(Boolean);}
  if(op==='if'){const c=evalExpr(expr.cond,env,`${path}.cond`,depth+1);if(typeof c!=='boolean')fail(`${path}: if condition must be boolean`);return evalExpr(c?expr.then:expr.else,env,`${path}.${c?'then':'else'}`,depth+1);}
  fail(`${path}: unsupported op ${JSON.stringify(op)}`);
}
function stageSpec(program,name,required=true){const v=program[name];if(v==null){if(required)fail(`program.${name} required`);return null;}requireKeys(v,['required_fact_ids','expr'],['required_fact_ids','expr'],`program.${name}`);const facts=v.required_fact_ids;if(!Array.isArray(facts)||facts.some(x=>typeof x!=='string'||!x)||new Set(facts).size!==facts.length)fail(`program.${name}.required_fact_ids must be a unique string array`);validateExpr(v.expr,STAGES[name],`program.${name}.expr`);return v;}
function validatePayload(p){
  requireKeys(p,['protocol','worlds','profile_constants','established_facts','exact_enabled','program'],['protocol','worlds','profile_constants','established_facts','exact_enabled','program'],'payload');if(p.protocol!==PROTOCOL)fail(`protocol must be ${PROTOCOL}`);
  if(!Array.isArray(p.worlds)||!p.worlds.length)fail('worlds must be a nonempty array');const ids=new Set();p.worlds.forEach((w,i)=>{requireKeys(w,['id','coordinates'],['id','coordinates'],`worlds[${i}]`);if(typeof w.id!=='string'||!w.id||ids.has(w.id))fail(`worlds[${i}].id invalid or duplicate`);ids.add(w.id);if(!isObj(w.coordinates))fail(`worlds[${i}].coordinates must be an object`);if('id' in w.coordinates)fail(`worlds[${i}].coordinates may not contain reserved key id`);validateJson(w.coordinates,`worlds[${i}].coordinates`);});
  if(!isObj(p.profile_constants))fail('profile_constants must be an object');validateJson(p.profile_constants,'profile_constants');const facts=p.established_facts;if(!Array.isArray(facts)||facts.some(x=>typeof x!=='string'||!x)||new Set(facts).size!==facts.length)fail('established_facts must be a unique string array');if(typeof p.exact_enabled!=='boolean')fail('exact_enabled must be boolean');
  const prog=p.program;requireKeys(prog,['program_version','discriminator','operative_signature','mechanism','interpreter'],['program_version','discriminator'],'program');if(prog.program_version!=='0.5')fail('program_version must be 0.5');stageSpec(prog,'discriminator',true);['operative_signature','mechanism','interpreter'].forEach(n=>stageSpec(prog,n,p.exact_enabled));if(!p.exact_enabled&&['operative_signature','mechanism','interpreter'].some(n=>prog[n]!=null))fail('exact-disabled program must omit operative_signature, mechanism, and interpreter');
  const established=new Set(facts);['discriminator','operative_signature','mechanism','interpreter'].forEach(n=>{const s=prog[n];if(s){const missing=s.required_fact_ids.filter(x=>!established.has(x));if(missing.length)fail(`program.${n} missing established facts: ${JSON.stringify(missing)}`);}});return true;
}
function findGroup(groups,value){return groups.find(g=>jsonEqual(g.value,value))||null;}
function normalizeInterpretation(v,native){if(!isObj(v))fail('interpreter must return exactly {space:C,label:...} or {space:OUTSIDE_C,native:...}');const keys=Object.keys(v).sort();const c=keys.length===2&&keys[0]==='label'&&keys[1]==='space';const o=keys.length===2&&keys[0]==='native'&&keys[1]==='space';if(!c&&!o)fail('interpreter must return exactly {space:C,label:...} or {space:OUTSIDE_C,native:...}');if(v.space==='C'){if(!c)fail('C interpreter result must contain label');validateJson(v.label,'interpreter.label');return v;}if(v.space==='OUTSIDE_C'){if(!o||!jsonEqual(v.native,native))fail('OUTSIDE_C interpreter.native must equal the native outcome being interpreted');return v;}fail('interpreter space must be C or OUTSIDE_C');}
function compilePayload(p){validatePayload(p);const prog=p.program,con=p.profile_constants,disc={},zBy={},nativeBy={},alphaBy={};for(const w of p.worlds){const env={world:w.coordinates,const:con};const d=evalExpr(prog.discriminator.expr,env,'discriminator');validateJson(d,`discriminator[${w.id}]`);disc[w.id]=d;if(p.exact_enabled){const z=evalExpr(prog.operative_signature.expr,env,'operative_signature');validateJson(z,`z[${w.id}]`);zBy[w.id]=z;}}
  const fibers=[];if(p.exact_enabled){for(const w of p.worlds){const z=zBy[w.id];let g=findGroup(fibers,z);if(g===null){const native=evalExpr(prog.mechanism.expr,{z:z,const:con},'mechanism');validateJson(native,'native');const alpha=normalizeInterpretation(evalExpr(prog.interpreter.expr,{native:native,const:con},'interpreter'),native);g={value:z,native:native,interpretation:alpha,worlds:[]};fibers.push(g);}g.worlds.push(w.id);nativeBy[w.id]=g.native;alphaBy[w.id]=g.interpretation;}}
  const out={protocol:PROTOCOL,derived:{discriminator_signature_by_world:disc},stage_fact_requirements:{},stage_input_footprint:{},mechanism_fibers:[]};for(const n of ['discriminator','operative_signature','mechanism','interpreter'])if(prog[n]!=null){out.stage_fact_requirements[n]=[...prog[n].required_fact_ids];out.stage_input_footprint[n]=readFootprint(prog[n].expr);}if(p.exact_enabled){Object.assign(out.derived,{operative_signature_by_world:zBy,native_outcome_by_world:nativeBy,mechanism_consequence_by_world:alphaBy});out.mechanism_fibers=fibers.map(g=>({operative_signature:g.value,native_outcome:g.native,mechanism_consequence:g.interpretation,worlds:g.worlds}));}return out;
}
function one(raw){try{return {ok:true,result:compilePayload(JSON.parse(raw))};}catch(e){return {ok:false,error:e.message};}}
process.stdin.setEncoding('utf8');
if(process.argv.includes('--jsonl')){
  let buf='';process.stdin.on('data',d=>{buf+=d;let i;while((i=buf.indexOf('\n'))>=0){const line=buf.slice(0,i);buf=buf.slice(i+1);if(!line.trim())continue;process.stdout.write(JSON.stringify(one(line))+'\n');}});
  process.stdin.on('end',()=>{if(buf.trim())process.stdout.write(JSON.stringify(one(buf))+'\n');});
}else{
  let raw='';process.stdin.on('data',d=>raw+=d);process.stdin.on('end',()=>{const out=one(raw);process.stdout.write(JSON.stringify(out)+'\n');process.exitCode=out.ok?0:2;});
}

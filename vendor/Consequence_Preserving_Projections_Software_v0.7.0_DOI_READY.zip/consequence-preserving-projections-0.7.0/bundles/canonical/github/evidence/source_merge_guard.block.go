// Upstream: google/go-github
// Ref: 34349a88bac3 (pinned by github-mcp-server go.mod pseudo-version)
// Upstream blob SHA: 27e3784876f4cf0f8bc8b640296f4317546f8044
// Path: github/pulls.go
// Retained PullRequestOptions / merge request / Merge implementation block.

type PullRequestOptions struct {
	CommitTitle string // Title for the automatic commit message. (Optional.)
	SHA         string // SHA that pull request head must match to allow merge. (Optional.)

	MergeMethod string
	DontDefaultIfBlank bool
}

type pullRequestMergeRequest struct {
	CommitMessage *string `json:"commit_message,omitempty"`
	CommitTitle   string  `json:"commit_title,omitempty"`
	MergeMethod   string  `json:"merge_method,omitempty"`
	SHA           string  `json:"sha,omitempty"`
}

func (s *PullRequestsService) Merge(ctx context.Context, owner, repo string, number int, commitMessage string, options *PullRequestOptions) (*PullRequestMergeResult, *Response, error) {
	u := fmt.Sprintf("repos/%v/%v/pulls/%v/merge", owner, repo, number)

	var pullRequestBody pullRequestMergeRequest
	if commitMessage != "" {
		pullRequestBody.CommitMessage = &commitMessage
	}
	if options != nil {
		pullRequestBody.CommitTitle = options.CommitTitle
		pullRequestBody.MergeMethod = options.MergeMethod
		pullRequestBody.SHA = options.SHA
	}
	req, err := s.client.NewRequest(ctx, "PUT", u, &pullRequestBody)
	if err != nil {
		return nil, nil, err
	}
	return nil, nil, nil // retained slice ends after request construction; response logic is not material here.
}

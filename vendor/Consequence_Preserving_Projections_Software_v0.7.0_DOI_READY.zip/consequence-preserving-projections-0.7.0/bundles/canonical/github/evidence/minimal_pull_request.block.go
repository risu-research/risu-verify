// Upstream: github/github-mcp-server
// Ref: 822c87761f8587395b3e1a04b5386b2611252cd1
// Upstream blob SHA: 675ec050bc960246412655a4a240ca6148e99b45
// Path: pkg/github/minimal_types.go
// Retained complete MinimalPullRequest / MinimalPRBranch blocks.

type MinimalPullRequest struct {
	Number             int              `json:"number"`
	Title              string           `json:"title"`
	Body               string           `json:"body,omitempty"`
	State              string           `json:"state"`
	Draft              bool             `json:"draft"`
	Merged             bool             `json:"merged"`
	MergeableState     string           `json:"mergeable_state,omitempty"`
	HTMLURL            string           `json:"html_url"`
	User               *MinimalUser     `json:"user,omitempty"`
	Labels             []string         `json:"labels,omitempty"`
	Assignees          []string         `json:"assignees,omitempty"`
	RequestedReviewers []string         `json:"requested_reviewers,omitempty"`
	MergedBy           string           `json:"merged_by,omitempty"`
	Head               *MinimalPRBranch `json:"head,omitempty"`
	Base               *MinimalPRBranch `json:"base,omitempty"`
	Additions          int              `json:"additions,omitempty"`
	Deletions          int              `json:"deletions,omitempty"`
	ChangedFiles       int              `json:"changed_files,omitempty"`
	Commits            int              `json:"commits,omitempty"`
	Comments           int              `json:"comments,omitempty"`
	CreatedAt          string           `json:"created_at,omitempty"`
	UpdatedAt          string           `json:"updated_at,omitempty"`
	ClosedAt           string           `json:"closed_at,omitempty"`
	MergedAt           string           `json:"merged_at,omitempty"`
	Milestone          string           `json:"milestone,omitempty"`
}

type MinimalPRBranch struct {
	Ref  string               `json:"ref"`
	SHA  string               `json:"sha"`
	Repo *MinimalPRBranchRepo `json:"repo,omitempty"`
}

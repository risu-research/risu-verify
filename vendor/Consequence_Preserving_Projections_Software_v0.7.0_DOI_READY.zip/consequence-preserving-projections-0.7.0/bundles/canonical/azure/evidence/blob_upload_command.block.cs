// Upstream: microsoft/mcp
// Ref: 35089f45a44ba7fe4eb921f84c611791cb9af2a3
// Upstream blob SHA: af341f9f9c9e85f7388ec19f20dabad0f70c5b70
// Path: tools/Azure.Mcp.Tools.Storage/src/Commands/Blob/BlobUploadCommand.cs
// Retained complete command class.

[CommandMetadata(
    Id = "aafb82ac-e35a-4800-b362-c642a3ac1e17",
    Name = "upload",
    Title = "Upload Local File to Blob",
    Description = """
        Uploads a local file to an Azure Storage blob, only if the blob does not exist, returning the last modified time,
        ETag, and content hash of the uploaded blob.
        """,
    Destructive = false,
    Idempotent = false,
    OpenWorld = false,
    ReadOnly = false,
    Secret = false,
    LocalRequired = true)]
public sealed class BlobUploadCommand(ILogger<BlobUploadCommand> logger, IStorageService storageService, ISubscriptionResolver subscriptionResolver)
    : SubscriptionCommand<BlobUploadOptions, BlobUploadResult>(subscriptionResolver)
{
    private readonly ILogger<BlobUploadCommand> _logger = logger;
    private readonly IStorageService _storageService = storageService;

    public override async Task<CommandResponse> ExecuteAsync(CommandContext context, BlobUploadOptions options, CancellationToken cancellationToken)
    {
        try
        {
            var result = await _storageService.UploadBlob(
                options.Account,
                options.Container,
                options.Blob,
                options.LocalFilePath,
                options.Subscription!,
                options.Tenant,
                options.RetryPolicy,
                cancellationToken);
            context.Response.Results = ResponseResult.Create(result, StorageJsonContext.Default.BlobUploadResult);
            return context.Response;
        }
        catch (Exception ex)
        {
            HandleException(context, ex);
            return context.Response;
        }
    }
}

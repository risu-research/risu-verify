// Upstream: microsoft/mcp
// Ref: 35089f45a44ba7fe4eb921f84c611791cb9af2a3
// Upstream blob SHA: 0a7047aebae666cad78aa421bba123c580c2c4c4
// Path: tools/Azure.Mcp.Tools.Storage/src/Services/StorageService.cs
// Retained complete UploadBlob method.

public async Task<BlobUploadResult> UploadBlob(
    string account,
    string container,
    string blob,
    string localFilePath,
    string subscription,
    string? tenant = null,
    RetryPolicyOptions? retryPolicy = null,
    CancellationToken cancellationToken = default)
{
    ValidateRequiredParameters(
        (nameof(account), account),
        (nameof(container), container),
        (nameof(blob), blob),
        (nameof(localFilePath), localFilePath),
        (nameof(subscription), subscription));

    if (!File.Exists(localFilePath))
    {
        throw new FileNotFoundException($"Local file not found: {localFilePath}");
    }

    var blobServiceClient = await CreateBlobServiceClient(account, tenant, retryPolicy, cancellationToken);
    var blobContainerClient = blobServiceClient.GetBlobContainerClient(container);
    var blobClient = blobContainerClient.GetBlobClient(blob);

    using var fileStream = File.OpenRead(localFilePath);
    var response = await blobClient.UploadAsync(fileStream, false, cancellationToken);

    return new(
        Blob: blob,
        Container: container,
        UploadedFile: localFilePath,
        LastModified: response.Value.LastModified,
        ETag: response.Value.ETag.ToString(),
        MD5Hash: response.Value.ContentHash != null ? Convert.ToBase64String(response.Value.ContentHash) : null
    );
}

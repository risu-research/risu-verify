// Upstream: Azure/azure-sdk-for-net
// Ref: e6cb2e254d405749603377c499ce123378d15385 (Azure.Storage.Blobs_12.29.1)
// Upstream blob SHA: 4a2ccb8d5c9fefa201fab5e9be66eae0e694cda9
// Path: sdk/storage/Azure.Storage.Blobs/src/BlobClient.cs
// Retained complete Stream/bool UploadAsync overload.

public virtual Task<Response<BlobContentInfo>> UploadAsync(
    Stream content,
    bool overwrite = false,
    CancellationToken cancellationToken = default) =>
    UploadAsync(
        content,
        conditions: overwrite ? null : new BlobRequestConditions { IfNoneMatch = new ETag(Constants.Wildcard) },
        cancellationToken: cancellationToken);

// Upstream: microsoft/mcp
// Ref: 35089f45a44ba7fe4eb921f84c611791cb9af2a3
// Upstream blob SHA: 25826c5ca63096512814fd6de9b925fa52c269be
// Path: tools/Azure.Mcp.Tools.Storage/src/Options/Blob/BlobUploadOptions.cs
// Retained complete BlobUploadOptions class.

public class BlobUploadOptions : ISubscriptionOption
{
    public required string LocalFilePath { get; set; }
    public required string Account { get; set; }
    public required string Container { get; set; }
    public required string Blob { get; set; }
    public string? Subscription { get; set; }
    public string? Tenant { get; set; }
    public RetryPolicyOptions? RetryPolicy { get; set; }
}

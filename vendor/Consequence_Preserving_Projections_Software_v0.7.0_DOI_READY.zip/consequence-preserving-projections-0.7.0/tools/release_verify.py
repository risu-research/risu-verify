#!/usr/bin/env python3
from pathlib import Path
import ast
import hashlib
import io
import json
import re
import stat
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
EXCLUDED = {"FULL_PACKAGE_MANIFEST.sha256", "PACKAGE_SEAL.json", "RELEASE_VERIFICATION.json"}
TRANSIENT_PREFIXES = ("reproduction-output/",)


def excluded(rel):
    return rel in EXCLUDED or rel.startswith(TRANSIENT_PREFIXES) or "/__pycache__/" in ("/" + rel + "/") or rel.endswith(".pyc")


def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def release_files():
    return sorted(p for p in ROOT.rglob("*") if p.is_file() and not excluded(p.relative_to(ROOT).as_posix()))


def safe_rel(rel):
    if not isinstance(rel, str) or not rel:
        return False
    p = Path(rel)
    return not p.is_absolute() and ".." not in p.parts and "\\" not in rel


def load_json(rel):
    return json.loads((ROOT / rel).read_text())


def py_import_roots(path):
    tree = ast.parse(Path(path).read_text())
    out = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            out.extend(a.name.split(".")[0] for a in node.names)
        elif isinstance(node, ast.ImportFrom):
            out.append((node.module or "").split(".")[0])
    return sorted(set(x for x in out if x))


def publication_surface_hits():
    # Keep internal workflow shorthand and execution-host names out of the public release.
    # The strings are assembled so the release verifier does not introduce the terms it checks for.
    raw_terms = ["P" + str(8), "P" + str(9), "".join(chr(x) for x in (67,104,97,116,71,80,84)), "".join(chr(x) for x in (65,73))]
    pats = [re.compile(rb"(?i)(?<![A-Za-z0-9])" + re.escape(t.encode()) + rb"(?![A-Za-z0-9])") for t in raw_terms]
    text_suffixes = {".md", ".txt", ".json", ".py", ".js", ".sh", ".cff", ".yaml", ".yml", ".go", ".cs", ".toml", ".xml", ".csv", ".html", ".htm", ".rst"}
    text_names = {"LICENSE", "NOTICE", "CITATION.cff"}
    hits = []

    def test(label, data):
        for idx, pat in enumerate(pats):
            if pat.search(data):
                hits.append({"location": label, "term_class": idx})

    def scan_zip(label, data, depth=0):
        if depth > 4:
            return
        try:
            z = zipfile.ZipFile(io.BytesIO(data))
        except Exception:
            return
        for info in z.infolist():
            if info.is_dir() or info.file_size > 25_000_000:
                continue
            test(label + "::filename::" + info.filename, info.filename.encode("utf-8", "ignore"))
            suffix = Path(info.filename).suffix.lower()
            try:
                b = z.read(info)
            except Exception:
                continue
            if suffix == ".zip":
                scan_zip(label + "::" + info.filename, b, depth + 1)
            elif suffix in text_suffixes or Path(info.filename).name in text_names:
                test(label + "::" + info.filename, b)

    for p in release_files():
        rel = p.relative_to(ROOT).as_posix()
        test("filename::" + rel, rel.encode("utf-8", "ignore"))
        suffix = p.suffix.lower()
        if suffix == ".zip":
            scan_zip(rel, p.read_bytes())
        elif suffix in text_suffixes or p.name in text_names:
            try:
                test(rel, p.read_bytes())
            except Exception:
                pass
    return hits


def main(write=False):
    checks = []

    def ck(name, ok, detail=""):
        checks.append({"check": name, "status": "PASS" if ok else "FAIL", "detail": str(detail)})
        return ok

    # Manifest integrity.
    man = ROOT / "FULL_PACKAGE_MANIFEST.sha256"
    declared = {}
    try:
        for line in man.read_text().splitlines():
            if line.strip():
                h, rel = line.split(maxsplit=1)
                declared[rel.lstrip("* ")] = h
        ck("manifest-readable", True)
    except Exception as e:
        ck("manifest-readable", False, e)
    actual = {p.relative_to(ROOT).as_posix(): sha(p) for p in release_files()}
    ck("manifest-file-set", set(declared) == set(actual), f"{len(declared)}/{len(actual)}")
    ck("manifest-hashes", bool(declared) and all(declared.get(k) == v for k, v in actual.items()))

    # Seal and release bindings.
    try:
        seal = load_json("PACKAGE_SEAL.json")
        ck("seal-readable", True)
    except Exception as e:
        seal = {}
        ck("seal-readable", False, e)
    ck("seal-version", seal.get("release_version") == "0.7.0")
    ck("seal-status", seal.get("release_status") == "FROZEN_SOURCE_CONTRACT_SEPARATED_PROOF_CARRYING_QUALIFIED")
    ck("seal-manifest-sha", man.is_file() and seal.get("manifest_sha256") == sha(man))
    ck("seal-source-contract-protocol", seal.get("source_contract_protocol") == "risu-source-consequence-contract/0.7")
    ck("seal-projection-adapter-protocol", seal.get("projection_adapter_protocol") == "0.7")
    ck("seal-certificate-protocol", seal.get("certificate_protocol") == "0.7")
    ck("seal-inner-certificate-protocol", seal.get("inner_certificate_protocol") == "0.6")
    ck("seal-proof-protocol", seal.get("proof_protocol") == "0.6")
    ck("seal-target-compiler-protocol", seal.get("semantic_compiler_protocol") == "risu-semantic-compiler/0.5")
    ck("seal-publication-surface", seal.get("publication_surface") == "COMPACT_PUBLIC_RELEASE")
    ck("seal-historical-archives-embedded", seal.get("historical_archives_embedded") is False)

    for key in ("source_contract_gate", "source_compiler_stress_gate", "qualification_summary", "tcb_profile", "qualification_bindings", "inheritance_bindings", "historical_archive_references"):
        item = seal.get(key, {})
        ok = safe_rel(item.get("path", "")) and (ROOT / item.get("path", "")).is_file() and sha(ROOT / item["path"]) == item.get("sha256")
        ck("seal-" + key + "-sha", ok, item.get("path", ""))
    for key in ("contract_checker", "inner_checker", "source_compiler_python", "source_compiler_node"):
        item = seal.get(key, {})
        ok = safe_rel(item.get("path", "")) and (ROOT / item.get("path", "")).is_file() and sha(ROOT / item["path"]) == item.get("sha256")
        ck("seal-" + key + "-sha", ok, item.get("path", ""))
        if "physical_lines" in item and safe_rel(item.get("path", "")) and (ROOT / item["path"]).is_file():
            ck("seal-" + key + "-lines", len((ROOT / item["path"]).read_text().splitlines()) == item["physical_lines"], item["physical_lines"])

    try:
        qb = load_json("QUALIFICATION_BINDINGS.json")
        ck("qualification-bindings-readable", True)
    except Exception as e:
        qb = {}
        ck("qualification-bindings-readable", False, e)
    ck("qualification-release", qb.get("release") == "0.7.0")
    for name, binding in qb.get("gates", {}).items():
        ok = safe_rel(binding.get("path", "")) and (ROOT / binding.get("path", "")).is_file() and sha(ROOT / binding["path"]) == binding.get("sha256")
        ck("gate-binding:" + name, ok, binding.get("path", ""))
    for key in ("inheritance_bindings", "historical_archive_references"):
        binding = qb.get(key, {})
        ok = safe_rel(binding.get("path", "")) and (ROOT / binding.get("path", "")).is_file() and sha(ROOT / binding["path"]) == binding.get("sha256")
        ck("qualification-" + key, ok, binding.get("path", ""))

    # Digest-only historical lineage and inherited lower-layer identity.
    try:
        lineage = load_json("provenance/INHERITED_COMPONENT_BINDINGS_v0.6.0.json")
        refs = load_json("provenance/HISTORICAL_ARCHIVE_REFERENCES.json")
        ck("lineage-record-readable", True)
    except Exception as e:
        lineage, refs = {}, {}
        ck("lineage-record-readable", False, e)
    predecessor = refs.get("references", {}).get("predecessor_release", {})
    ck("predecessor-release", predecessor.get("release") == "0.6.0" and predecessor.get("bundled") is False)
    ck("predecessor-digest", lineage.get("source_release_sha256") == predecessor.get("sha256") == seal.get("historical_parent_v0_6_0_sha256"))
    ck("no-embedded-predecessor-zip", not any((ROOT / "provenance").rglob("*.zip")))
    for rel, expected in lineage.get("files", {}).items():
        ck("inherited-component:" + rel, safe_rel(rel) and (ROOT / rel).is_file() and sha(ROOT / rel) == expected)
    for rel, expected in lineage.get("historical_records", {}).items():
        ck("inherited-record:" + rel, safe_rel(rel) and (ROOT / rel).is_file() and sha(ROOT / rel) == expected)

    # Current qualification records.
    def gate_ok(rel, expected=None):
        try:
            x = load_json(rel)
            ok = x.get("status") == "PASS" and x.get("passed") == x.get("total")
            if expected is not None:
                ok = ok and x.get("total") == expected
            return ok, f"{x.get('passed')}/{x.get('total')}"
        except Exception as e:
            return False, str(e)

    ok, detail = gate_ok("results/V0.5.0_CONSEQUENCE_BLIND_COMPILATION_GATE.json", 63)
    ck("retained-v0.5-gate", ok, detail)
    ok, detail = gate_ok("results/V0.6.0_PROOF_CARRYING_TCB_GATE.json", 77)
    ck("retained-v0.6-gate", ok, detail)
    ok, detail = gate_ok("results/V0.7.0_SOURCE_CONSEQUENCE_CONTRACT_GATE.json", 62)
    ck("v0.7-source-contract-gate", ok, detail)
    try:
        sg = load_json("results/V0.7.0_SOURCE_COMPILER_STRESS_GATE.json")
        ok = sg.get("status") == "PASS" and sg["valid_triple_differential"]["passed"] == sg["valid_triple_differential"]["total"] and sg["invalid_triple_rejection"]["passed"] == sg["invalid_triple_rejection"]["total"] and sg["metamorphic_domain_order_and_metadata_invariance"]["passed"] == sg["metamorphic_domain_order_and_metadata_invariance"]["total"]
        ck("v0.7-source-stress-gate", ok, f"valid={sg['valid_triple_differential']['passed']}/{sg['valid_triple_differential']['total']}; invalid={sg['invalid_triple_rejection']['passed']}/{sg['invalid_triple_rejection']['total']}; meta={sg['metamorphic_domain_order_and_metadata_invariance']['passed']}/{sg['metamorphic_domain_order_and_metadata_invariance']['total']}")
    except Exception as e:
        ck("v0.7-source-stress-gate", False, e)
    try:
        qs = load_json("results/V0.7.0_QUALIFICATION_SUMMARY.json")
        ck("qualification-summary-status", qs.get("status") == "PASS" and qs.get("release") == "0.7.0")
    except Exception as e:
        ck("qualification-summary-status", False, e)
    try:
        tcb = load_json("results/V0.7.0_TCB_PROFILE.json")
        ck("tcb-profile-status", tcb.get("status") == "PASS")
    except Exception as e:
        tcb = {}
        ck("tcb-profile-status", False, e)

    # Required current artifacts and protocol schemas.
    required = [
        "risu-projection", "risu-pcc-check", "reproduce.sh",
        "checker/risu_contract_pcc_check.py", "checker/risu_pcc_check.py", "checker/risu_pcc_dispatch.py",
        "source_compiler/implementations/reference_source_compiler.py", "source_compiler/implementations/node_source_compiler.js", "source_compiler/runner/conformance_runner.py",
        "spec/SOURCE_CONSEQUENCE_CONTRACT_v0.7.md", "spec/PROJECTION_ADAPTER_v0.7.md", "spec/PROJECTION_ASSURANCE_CERTIFICATE_v0.7.md",
        "spec/source-consequence-contract-v0.7.schema.json", "spec/projection-adapter-v0.7.schema.json", "spec/projection-assurance-certificate-v0.7.schema.json",
        "validation/run_v070_gates.py", "validation/run_v070_source_stress.py",
        "results/V0.7.0_SOURCE_CONSEQUENCE_CONTRACT_GATE.json", "results/V0.7.0_SOURCE_COMPILER_STRESS_GATE.json", "results/V0.7.0_TCB_PROFILE.json", "results/V0.7.0_QUALIFICATION_SUMMARY.json",
        "provenance/INHERITED_COMPONENT_BINDINGS_v0.6.0.json", "provenance/HISTORICAL_ARCHIVE_REFERENCES.json",
        "projections/canonical/github/adapter.json", "projections/canonical/github/source-contract.json", "projections/canonical/azure/adapter.json", "projections/canonical/azure/source-contract.json",
        "projections/examples/shared-contract/source-contract.json", "projections/examples/shared-contract/adapter-preserved.json", "projections/examples/shared-contract/adapter-misaligned.json",
        "docs/PRIOR_ART_BOUNDARY_v0.7.md", "certificates/README.md"
    ]
    for rel in required:
        ck("required:" + rel, (ROOT / rel).is_file())

    # Syntax, executability, and schema parse.
    try:
        for py in ROOT.rglob("*.py"):
            if "__pycache__" not in py.parts:
                compile(py.read_text(encoding="utf-8"), str(py), "exec")
        ck("python-syntax", True)
    except Exception as e:
        ck("python-syntax", False, e)
    for js in ROOT.rglob("*.js"):
        cp = subprocess.run(["node", "--check", str(js)], capture_output=True, text=True)
        ck("node-syntax:" + js.relative_to(ROOT).as_posix(), cp.returncode == 0, cp.stderr[-300:])
    executables = ["reproduce.sh", "risu-projection", "risu-pcc-check", "checker/risu_contract_pcc_check.py", "checker/risu_pcc_check.py", "checker/risu_pcc_dispatch.py", "source_compiler/implementations/reference_source_compiler.py", "source_compiler/implementations/node_source_compiler.js", "validation/run_v070_source_stress.py"]
    for rel in executables:
        ck("executable:" + rel, (ROOT / rel).is_file() and bool((ROOT / rel).stat().st_mode & stat.S_IXUSR))
    schemas = ["spec/source-consequence-contract-v0.7.schema.json", "spec/projection-adapter-v0.7.schema.json", "spec/projection-assurance-certificate-v0.7.schema.json", "spec/semantic-compilation-program-v0.5.schema.json", "spec/projection-assurance-certificate-v0.6.schema.json", "spec/projection-assurance-proof-v0.6.schema.json"]
    for rel in schemas:
        try:
            load_json(rel)
            ck("schema-json:" + rel, True)
        except Exception as e:
            ck("schema-json:" + rel, False, e)

    # Canonical source pins and source reuse identity.
    forbidden = {"world_records", "worlds", "source_by_world", "consequence_by_world", "signature_by_world", "operative_signature_by_world", "mechanism_consequence_by_world", "declared_target_model_by_world", "target_model_by_world"}

    def recursive_keys(v):
        out = []
        if isinstance(v, dict):
            for k, x in v.items():
                out.append(k)
                out.extend(recursive_keys(x))
        elif isinstance(v, list):
            for x in v:
                out.extend(recursive_keys(x))
        return out

    for name in ("github", "azure"):
        base = ROOT / f"projections/canonical/{name}"
        adapter = json.loads((base / "adapter.json").read_text())
        cpath = (base / adapter["source_contract"]["path"]).resolve()
        ck("canonical-source-pin:" + name, cpath.is_file() and sha(cpath) == adapter["source_contract"]["sha256"])
        ck("canonical-no-authored-source-answer:" + name, not (set(recursive_keys(adapter["target"])) & forbidden), sorted(set(recursive_keys(adapter["target"])) & forbidden))
    ex = ROOT / "projections/examples/shared-contract"
    source = ex / "source-contract.json"
    preserved = json.loads((ex / "adapter-preserved.json").read_text())
    misaligned = json.loads((ex / "adapter-misaligned.json").read_text())
    ck("shared-contract-same-file-pin", preserved["source_contract"]["sha256"] == misaligned["source_contract"]["sha256"] == sha(source))

    # Checker TCB source boundary.
    contract_checker = ROOT / "checker/risu_contract_pcc_check.py"
    inner_checker = ROOT / "checker/risu_pcc_check.py"
    allowed_std = {"argparse", "base64", "hashlib", "importlib", "itertools", "json", "math", "os", "sys", "pathlib"}
    for p, label in ((contract_checker, "contract-checker"), (inner_checker, "inner-checker")):
        roots = set(py_import_roots(p))
        ck(label + "-stdlib-only", roots <= allowed_std, sorted(roots))
        src = p.read_text()
        ck(label + "-no-producer-import", not any(x in src for x in ["from verifier", "import verifier", "from compiler", "import compiler", "from kernel", "import kernel", "from exact", "import exact", "from source_compiler", "import source_compiler", "sys.path.insert"]))
        ck(label + "-no-subprocess", "subprocess" not in src)
    if tcb:
        ck("tcb-contract-checker-hash", tcb.get("contract_checker", {}).get("sha256") == sha(contract_checker))
        ck("tcb-inner-checker-hash", tcb.get("inner_checker", {}).get("sha256") == sha(inner_checker))
        ck("tcb-combined-lines", tcb.get("combined_semantic_checker_physical_lines") == len(contract_checker.read_text().splitlines()) + len(inner_checker.read_text().splitlines()))

    # Active shared semantics remain carrier-neutral.
    active = list((ROOT / "verifier").glob("*.py")) + [ROOT / "cli/risu_projection.py", ROOT / "source_compiler/implementations/reference_source_compiler.py", ROOT / "source_compiler/implementations/node_source_compiler.js", contract_checker, inner_checker]
    hits = []
    for p in active:
        text = p.read_text().lower()
        for needle in ("github", "azure", "paypal"):
            if needle in text:
                hits.append(f"{p.relative_to(ROOT)}:{needle}")
    ck("carrier-neutral-active-core", not hits, ",".join(hits))

    # Public-release hygiene.
    symlinks = [p.relative_to(ROOT).as_posix() for p in ROOT.rglob("*") if p.is_symlink()]
    ck("release-tree-no-symlinks", not symlinks, ",".join(symlinks))
    pycache = [p.relative_to(ROOT).as_posix() for p in ROOT.rglob("*") if "__pycache__" in p.parts or p.suffix == ".pyc"]
    ck("release-tree-no-pycache", not pycache, ",".join(pycache[:20]))
    provenance_zips = [p.relative_to(ROOT).as_posix() for p in (ROOT / "provenance").rglob("*.zip")] if (ROOT / "provenance").is_dir() else []
    ck("public-release-no-nested-history-zips", not provenance_zips, provenance_zips)
    expected_gate_zips = {
        "qualification/gates/Projection_Assurance_Azure_Structured_Frontend_Gate_001.zip",
        "qualification/gates/Projection_Assurance_Exact_Realization_Gate_001.zip",
        "qualification/gates/Projection_Assurance_Signature_Grounding_Gate_001.zip",
    }
    actual_gate_zips = {p.relative_to(ROOT).as_posix() for p in (ROOT / "qualification/gates").glob("*.zip")}
    ck("public-release-current-gates-only", actual_gate_zips == expected_gate_zips, sorted(actual_gate_zips))
    surface_hits = publication_surface_hits()
    ck("publication-surface-terminology-clean", not surface_hits, surface_hits[:20])
    ck("citation-version", "version: 0.7.0" in (ROOT / "CITATION.cff").read_text())
    ck("readme-version", "release v0.7.0" in (ROOT / "README.md").read_text())
    ck("no-debug-release-script", not (ROOT / "validation/run_v070_debug.py").exists())

    status = "PASS" if all(x["status"] == "PASS" for x in checks) else "FAIL"
    report = {
        "release": "0.7.0",
        "status": status,
        "manifest_entries": len(actual),
        "passed": sum(x["status"] == "PASS" for x in checks),
        "total": len(checks),
        "checks": checks,
        "nonclaim": "Release verification checks package integrity, digest-only historical lineage, inherited lower-layer byte commitments, source-contract/adapter protocol artifacts, current qualification records, source pins, checker TCB boundaries, syntax, carrier neutrality, publication-surface hygiene, and current offline reproducibility prerequisites. It does not establish real-system model adequacy, semantic truth of evidence interpretations, live-runtime conformance, formal verification of Python/Node runtimes, independent authorship, or independent reproduction."
    }
    if write:
        (ROOT / "RELEASE_VERIFICATION.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if status == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main("--write" in sys.argv))

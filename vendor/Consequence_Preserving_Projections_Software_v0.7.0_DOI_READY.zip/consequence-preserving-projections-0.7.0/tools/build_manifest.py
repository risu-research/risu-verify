#!/usr/bin/env python3
from pathlib import Path
import hashlib
ROOT=Path(__file__).resolve().parents[1]
EXCLUDED={"FULL_PACKAGE_MANIFEST.sha256","PACKAGE_SEAL.json","RELEASE_VERIFICATION.json"}
def excluded(rel): return rel in EXCLUDED or rel.startswith("reproduction-output/") or "/__pycache__/" in ("/"+rel+"/") or rel.endswith(".pyc")
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
rows=[]
for p in sorted(ROOT.rglob("*")):
 if p.is_file():
  rel=p.relative_to(ROOT).as_posix()
  if not excluded(rel): rows.append(f"{sha(p)}  {rel}")
(ROOT/"FULL_PACKAGE_MANIFEST.sha256").write_text("\n".join(rows)+"\n")
print(f"manifest entries: {len(rows)}")

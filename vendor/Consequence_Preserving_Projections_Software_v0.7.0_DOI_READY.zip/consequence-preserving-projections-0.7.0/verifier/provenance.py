EVIDENCE_BINDING_KINDS={'EVIDENCE','QUALIFICATION','SOURCE'}

def _graph(bundle):
    p=bundle.get('provenance',{})
    nodes={n['id']:n for n in p.get('nodes',[])}
    incoming={k:[] for k in nodes}; outgoing={k:[] for k in nodes}
    for e in p.get('edges',[]):
        incoming[e['to']].append(e); outgoing[e['from']].append(e)
    return p,nodes,incoming,outgoing

def upstream_node_ids(bundle,root):
    _,nodes,incoming,_=_graph(bundle)
    seen=set();stack=[root]
    while stack:
        n=stack.pop()
        if n in seen: continue
        seen.add(n)
        for e in incoming[n]: stack.append(e['from'])
    return seen

def claim_paths(bundle):
    p,nodes,incoming,_=_graph(bundle)
    out={}
    for claim,roots in p.get('claim_roots',{}).items():
        seen=set();stack=list(roots);items=[]
        while stack:
            n=stack.pop()
            if n in seen:continue
            seen.add(n);node=nodes[n]
            items.append({'id':n,'kind':node['kind'],'label':node.get('label',n),'binding_ids':node.get('binding_ids',[])})
            for e in incoming[n]:stack.append(e['from'])
        out[claim]=sorted(items,key=lambda x:x['id'])
    return out

def claim_provenance_summary(bundle):
    p,nodes,_,_=_graph(bundle)
    bindings={b['id']:b for b in bundle.get('bindings',[])}
    out={}
    for claim,roots in sorted(p.get('claim_roots',{}).items()):
        per_root=[];all_evidence=[];all_epistemic=[];all_required=[]
        for root in roots:
            ids=upstream_node_ids(bundle,root)
            enodes=sorted(n for n in ids if nodes[n]['kind']=='EVIDENCE')
            bids=[];ep=[];req=[]
            for nid in enodes:
                for bid in nodes[nid].get('binding_ids',[]):
                    if bid not in bids:bids.append(bid)
                    b=bindings[bid]
                    if b['kind'] in EVIDENCE_BINDING_KINDS:
                        if bid not in ep:ep.append(bid)
                        if b.get('required',True) and bid not in req:req.append(bid)
            per_root.append({'root':root,'evidence_node_ids':enodes,'binding_ids':sorted(bids),'epistemic_binding_ids':sorted(ep),'required_epistemic_binding_ids':sorted(req)})
            all_evidence.extend(enodes);all_epistemic.extend(ep);all_required.extend(req)
        out[claim]={
            'roots':list(roots),
            'root_support':per_root,
            'evidence_node_ids':sorted(set(all_evidence)),
            'epistemic_binding_ids':sorted(set(all_epistemic)),
            'required_epistemic_binding_ids':sorted(set(all_required)),
            'provenance_mode':p.get('mode','DECLARED_ONLY')
        }
    return out

def claim_assurance(bundle,binding_report=None):
    summary=claim_provenance_summary(bundle)
    mode=bundle.get('provenance',{}).get('mode','DECLARED_ONLY')
    rows={r.get('id'):r for r in (binding_report or {}).get('bindings',[])}
    report_status=(binding_report or {}).get('status','NOT_RECHECKED')
    out={}
    for claim,s in summary.items():
        if mode=='DECLARED_ONLY': estatus='NOT_APPLICABLE_DECLARED_ONLY'
        elif report_status=='NOT_RECHECKED': estatus='NOT_RECHECKED'
        else:
            req=s['required_epistemic_binding_ids']
            estatus='PASS' if req and all(rows.get(bid,{}).get('status')=='PASS' for bid in req) else 'FAIL'
        out[claim]={**s,'evidence_integrity':estatus}
    return out

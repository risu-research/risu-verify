import copy
from .common import digest_obj,require
from .engine import evaluate_bundle,VERIFIER_BOUNDARY
from .bundle import validate_bundle_shape,verify_bindings
from .provenance import claim_paths,claim_provenance_summary,claim_assurance
from .proof import build_proof

CERT_VERSION='0.6'
CERT_SEMANTICS='PROOF_CARRYING_CONSEQUENCE_BLIND_MODEL_RELATIVE_WITH_EXPLICIT_EVIDENCE_STATE'
PROOF_CHECKER_BOUNDARY={
    'model_relative':True,
    'evidence_integrity_does_not_establish_semantic_adequacy':True,
    'blind_compilation_is_input_independence_not_authorship_independence':True,
    'proof_checker_reduces_tcb_but_does_not_establish_model_adequacy':True,
    'world_model_adequacy':'NOT_ESTABLISHED_BY_CHECKER',
    'evidence_fact_semantic_truth':'NOT_ESTABLISHED_BY_CHECKER',
    'general_source_equivalence':'NOT_ESTABLISHED_BY_CHECKER',
    'live_runtime_conformance':'NOT_ESTABLISHED_BY_CHECKER',
    'independent_reproduction':'NOT_ESTABLISHED_BY_CHECKER'
}

def build_certificate(bundle,bundle_root=None):
    require(bundle.get('bundle_version')=='0.5','v0.6 proof-carrying certificates require bundle_version 0.5')
    mode=bundle.get('provenance',{}).get('mode','DECLARED_ONLY')
    r=evaluate_bundle(bundle,bundle_root,check_bindings=bundle_root is not None)
    if r['model_verification_status']!='PASS':raise ValueError('bundle model verification failed; certificate not issued')
    if mode=='EVIDENCE_LINKED' and r['evidence_verification_status']!='PASS':raise ValueError('EVIDENCE_LINKED certificate requires successful byte recheck of claim-linked evidence')
    if r['verification_status']!='PASS':raise ValueError('bundle verification is not complete; certificate not issued')
    snapshot=copy.deepcopy(bundle);proof=build_proof(bundle,bundle_root)
    return {
        'certificate_version':CERT_VERSION,'bundle_protocol':snapshot['bundle_version'],'bundle_id':snapshot['bundle_id'],'bundle_snapshot':snapshot,'bundle_digest':digest_obj(snapshot),
        'semantic_input_digests':{'semantic':digest_obj(snapshot['semantic']),'structural_input':digest_obj(snapshot['semantic']['structural_template']),'derivation':digest_obj(snapshot['semantic']['derivation'])},
        'proof':proof,'proof_digest':proof['proof_digest'],
        'results':{'structural':r['structural'],'exact_realization':r['exact_realization'],'cross_layer':r['cross_layer']},
        'model_verification_at_issuance':'PASS','evidence_verification_at_issuance':r['evidence_verification_status'],'assurance_class_at_issuance':'PROOF_CARRYING_'+r['semantic_assurance_class'],
        'claim_provenance':claim_provenance_summary(snapshot),'claim_assurance_at_issuance':r['claim_assurance'],'provenance_paths':r['provenance_paths'],
        'verifier_boundary':VERIFIER_BOUNDARY,'proof_checker_boundary':PROOF_CHECKER_BOUNDARY,'certificate_semantics':CERT_SEMANTICS
    }

def verify_certificate(cert,evidence_root=None):
    checks=[]
    def ck(name,cond,detail=''):checks.append({'check':name,'status':'PASS' if cond else 'FAIL','detail':detail})
    evidence_required=False;evidence_rechecked=False
    try:
        allowed={'certificate_version','bundle_protocol','bundle_id','bundle_snapshot','bundle_digest','semantic_input_digests','proof','proof_digest','results','model_verification_at_issuance','evidence_verification_at_issuance','assurance_class_at_issuance','claim_provenance','claim_assurance_at_issuance','provenance_paths','verifier_boundary','proof_checker_boundary','certificate_semantics'}
        require(set(cert)<=allowed,f'unknown certificate keys: {sorted(set(cert)-allowed)}');require(cert.get('certificate_version')==CERT_VERSION,f'certificate_version must be {CERT_VERSION}');ck('certificate-version',True)
        b=cert['bundle_snapshot'];validate_bundle_shape(b);require(b.get('bundle_version')=='0.5','v0.6 certificate requires bundle 0.5');ck('bundle-shape',True);ck('bundle-protocol',cert.get('bundle_protocol')==b['bundle_version']);mode=b.get('provenance',{}).get('mode','DECLARED_ONLY');evidence_required=mode=='EVIDENCE_LINKED'
        ck('bundle-id',cert.get('bundle_id')==b['bundle_id']);ck('bundle-full-digest',digest_obj(b)==cert.get('bundle_digest'));ck('certificate-semantics',cert.get('certificate_semantics')==CERT_SEMANTICS);ck('verifier-boundary',cert.get('verifier_boundary')==VERIFIER_BOUNDARY);ck('proof-checker-boundary',cert.get('proof_checker_boundary')==PROOF_CHECKER_BOUNDARY)
        sid=cert.get('semantic_input_digests',{});ck('semantic-input-digest',sid.get('semantic')==digest_obj(b['semantic']));ck('structural-input-digest',sid.get('structural_input')==digest_obj(b['semantic']['structural_template']));ck('derivation-input-digest',sid.get('derivation')==digest_obj(b['semantic']['derivation']))
        rr=evaluate_bundle(b,None,check_bindings=False);ck('model-full-recompute',rr['model_verification_status']=='PASS')
        ck('structural-full-recompute',rr['structural']==cert['results']['structural']);ck('exact-full-recompute',rr['exact_realization']==cert['results'].get('exact_realization'));ck('cross-layer-recompute',rr['cross_layer']==cert['results']['cross_layer'])
        pp=build_proof(b,None);ck('proof-full-recompute',pp==cert.get('proof'));ck('proof-digest',pp['proof_digest']==cert.get('proof_digest'))
        expected_class='PROOF_CARRYING_'+(rr['semantic_assurance_class'].replace('EVIDENCE_NOT_RECHECKED','EVIDENCE_VERIFIED') if evidence_required else rr['semantic_assurance_class']);ck('issuance-assurance-class',cert.get('assurance_class_at_issuance')==expected_class)
        ck('issuance-model-status',cert.get('model_verification_at_issuance')=='PASS');ck('issuance-evidence-status',cert.get('evidence_verification_at_issuance')==('PASS' if evidence_required else 'NOT_APPLICABLE_DECLARED_ONLY'))
        ck('provenance-path-recompute',claim_paths(b)==cert.get('provenance_paths'));cp=claim_provenance_summary(b);ck('claim-provenance-recompute',cp==cert.get('claim_provenance'))
        issuance=cert.get('claim_assurance_at_issuance',{});ck('claim-assurance-shape',set(issuance)==set(cp))
        for claim,s in cp.items():
            row=issuance.get(claim,{});static={k:row.get(k) for k in ['roots','root_support','evidence_node_ids','epistemic_binding_ids','required_epistemic_binding_ids','provenance_mode']};ck('claim-assurance-static:'+claim,static==s);ck('claim-assurance-issuance-evidence:'+claim,row.get('evidence_integrity')==('PASS' if evidence_required else 'NOT_APPLICABLE_DECLARED_ONLY'))
        if evidence_required:
            if evidence_root is not None:
                br=verify_bindings(b,evidence_root);evidence_rechecked=True;ck('binding-byte-recheck',br['status']=='PASS',br['status']);ca=claim_assurance(b,br)
                for claim,row in ca.items():ck('claim-evidence-recheck:'+claim,row['evidence_integrity']=='PASS',row['evidence_integrity'])
            else:checks.append({'check':'binding-byte-recheck','status':'NOT_RECHECKED','detail':'evidence root not supplied'})
        else:checks.append({'check':'binding-byte-recheck','status':'NOT_APPLICABLE','detail':'DECLARED_ONLY certificate'})
    except Exception as e:ck('exception',False,str(e))
    if any(x['status']=='FAIL' for x in checks):status='FAIL'
    elif evidence_required and not evidence_rechecked:status='PARTIAL'
    else:status='PASS'
    return {'status':status,'model_recompute_status':'PASS' if status!='FAIL' else 'FAIL','proof_recompute_status':'PASS' if status!='FAIL' else 'FAIL','evidence_recheck_status':'PASS' if evidence_required and evidence_rechecked and status=='PASS' else ('NOT_RECHECKED' if evidence_required and not evidence_rechecked and status!='FAIL' else ('NOT_APPLICABLE' if not evidence_required else 'FAIL')),'checks':checks,'passed':sum(x['status']=='PASS' for x in checks),'failed':sum(x['status']=='FAIL' for x in checks),'not_rechecked':sum(x['status']=='NOT_RECHECKED' for x in checks),'total':len(checks)}

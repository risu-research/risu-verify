from pathlib import Path
import copy,json,re
from .common import require,digest_obj,safe_resolve,sha256_file
from .bundle import validate_bundle_shape
from .source_contract import load_pinned_source_contract

FORBIDDEN_TARGET_KEYS={'world_records','worlds','source_by_world','consequence_by_world','signature_by_world','operative_signature_by_world','mechanism_consequence_by_world','declared_target_model_by_world','target_model_by_world'}

def _keys_recursive(v):
    out=[]
    if isinstance(v,dict):
        for k,x in v.items():out.append(k);out.extend(_keys_recursive(x))
    elif isinstance(v,list):
        for x in v:out.extend(_keys_recursive(x))
    return out

def load_adapter(path):
    p=Path(path)
    if p.is_dir():p=p/'adapter.json'
    require(p.is_file(),f'projection adapter not found: {p}')
    a=json.loads(p.read_text());return a,p,p.parent

def validate_adapter_shape(a):
    allowed={'adapter_version','adapter_id','metadata','annotations','source_contract','target','bindings','provenance','claim_boundary'}
    require(isinstance(a,dict) and set(a)<=allowed,f'unknown adapter keys: {sorted(set(a)-allowed) if isinstance(a,dict) else "not-object"}')
    require(a.get('adapter_version')=='0.7','adapter_version must be 0.7');require(isinstance(a.get('adapter_id'),str) and a['adapter_id'],'adapter_id required')
    ref=a.get('source_contract');require(isinstance(ref,dict) and set(ref)=={'path','sha256'},'source_contract must contain path and sha256');require(isinstance(ref['path'],str) and ref['path'],'source contract path required');require(isinstance(ref['sha256'],str) and re.fullmatch(r'[0-9a-f]{64}',ref['sha256']),'source contract sha256 required')
    t=a.get('target');require(isinstance(t,dict) and set(t)=={'structural_template','coverage','exact_enabled','derivation'},'target must contain structural_template, coverage, exact_enabled, derivation')
    st=t['structural_template'];require(isinstance(st,dict),'target.structural_template object required');bad=sorted(set(_keys_recursive(st))&FORBIDDEN_TARGET_KEYS);require(not bad,f'target structural template may not author source/world answer tables: {bad}')
    cov=t['coverage'];require(isinstance(cov,dict) and set(cov)=={'in_scope'},'target.coverage must contain only in_scope');ins=cov['in_scope'];require(isinstance(ins,list) and ins and all(isinstance(x,str) and x for x in ins) and len(set(ins))==len(ins),'target.coverage.in_scope unique strings required')
    require(type(t['exact_enabled']) is bool,'target.exact_enabled must be boolean')
    d=t['derivation'];require(isinstance(d,dict) and set(d)=={'mode','profile_constants','facts','program'},'target.derivation invalid keys');require(d.get('mode')=='CONSEQUENCE_BLIND','target.derivation.mode must be CONSEQUENCE_BLIND');require(isinstance(d['profile_constants'],dict),'profile_constants object required');require(isinstance(d['facts'],list),'facts array required');require(isinstance(d['program'],dict),'program object required')
    # reuse mature v0.5 provenance/binding validator after normalization
    require(isinstance(a.get('bindings'),list),'bindings array required');require(isinstance(a.get('provenance'),dict),'provenance object required');require(isinstance(a.get('claim_boundary'),dict),'claim_boundary object required')
    return True

def normalize_adapter_with_compiled_source(a,contract,src,src_rec):
    validate_adapter_shape(a)
    t=a['target'];st=copy.deepcopy(t['structural_template'])
    st['boundary']={'declaration':contract['boundary']['declaration'],'post_check_material_transition_possible':contract['boundary']['post_check_material_transition_possible'],'worlds':[w['id'] for w in src['world_records']]}
    st['consequence']={'lens':contract['consequence']['lens'],'source_by_world':copy.deepcopy(src['consequence_by_world'])}
    st['coverage']={'source_family':sorted(contract['source_family']),'in_scope':sorted(t['coverage']['in_scope'])}
    st.pop('declared_target_model_by_world',None)
    der={'mode':'CONSEQUENCE_BLIND','world_records':copy.deepcopy(src['world_records']),'profile_constants':copy.deepcopy(t['derivation']['profile_constants']),'facts':copy.deepcopy(t['derivation']['facts']),'program':copy.deepcopy(t['derivation']['program'])}
    b={'bundle_version':'0.5','bundle_id':a['adapter_id'],'metadata':copy.deepcopy(a.get('metadata',{})),'annotations':copy.deepcopy(a.get('annotations',{})),'claim_boundary':copy.deepcopy(a['claim_boundary']),'bindings':copy.deepcopy(a['bindings']),'provenance':copy.deepcopy(a['provenance']),'semantic':{'structural_template':st,'exact_enabled':t['exact_enabled'],'derivation':der}}
    validate_bundle_shape(b)
    rec={'status':'PASS','mode':'SOURCE_CONTRACT_SEPARATED_PROJECTION','adapter_id':a['adapter_id'],'adapter_digest':digest_obj(a),'source_contract_id':contract['contract_id'],'source_contract_file_sha256':src_rec['source_contract_file_sha256'],'source_semantic_digest':src['source_semantic_digest'],'source_compilation':src_rec,'generated_world_count':len(src['world_records']),'generated_world_digest':src['domain_proof']['admitted_world_digest'],'generated_consequence_digest':src['domain_proof']['consequence_map_digest'],'normalized_bundle_digest':digest_obj(b),'claim_boundary':{'source_and_target_separate_objects':True,'adapter_cannot_author_world_table':True,'adapter_cannot_author_source_consequence_table':True,'target_compilation_remains_consequence_blind':True,'source_contract_adequacy':'NOT_ESTABLISHED','target_evidence_semantic_truth':'NOT_ESTABLISHED'}}
    return b,contract,src,rec

def normalize_adapter(a,root):
    validate_adapter_shape(a);contract,src,src_rec,src_path=load_pinned_source_contract(a,root)
    return normalize_adapter_with_compiled_source(a,contract,src,src_rec)

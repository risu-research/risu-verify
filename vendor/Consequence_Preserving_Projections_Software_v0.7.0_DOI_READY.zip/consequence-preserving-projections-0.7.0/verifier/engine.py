import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'kernel/implementations'));sys.path.insert(0,str(ROOT/'exact/implementations'))
from reference_analyzer import evaluate as structural,json_equal
from reference_exact import evaluate as exact
from .bundle import validate_bundle_shape,verify_bindings,verify_cross_layer
from .provenance import claim_paths,claim_assurance
from .common import digest_obj
from .semantic_compiler import compile_bundle

VERIFIER_BOUNDARY={
    'model_relative':True,
    'evidence_integrity_does_not_establish_semantic_adequacy':True,
    'blind_compilation_is_input_independence_not_authorship_independence':True,
    'world_model_adequacy':'NOT_ESTABLISHED_BY_VERIFIER',
    'evidence_fact_semantic_truth':'NOT_ESTABLISHED_BY_VERIFIER',
    'general_source_equivalence':'NOT_ESTABLISHED_BY_VERIFIER',
    'live_runtime_conformance':'NOT_ESTABLISHED_BY_VERIFIER',
    'independent_reproduction':'NOT_ESTABLISHED_BY_VERIFIER'
}

def _semantic_view(bundle):
    if bundle.get('bundle_version')=='0.5':
        compiled,record=compile_bundle(bundle);return compiled,record
    return bundle,{'status':'NOT_APPLICABLE','mode':'DECLARED_SEMANTICS_LEGACY_V0.4'}

def evaluate_bundle(bundle,bundle_root=None,check_bindings=True):
    validate_bundle_shape(bundle);semantic_bundle,compilation=_semantic_view(bundle);cross=verify_cross_layer(semantic_bundle,json_equal)
    sprof=semantic_bundle['semantic']['structural_profile'];s=structural(sprof)
    eprof=semantic_bundle['semantic'].get('exact_profile');e=exact(eprof) if eprof is not None else None
    mode=bundle.get('provenance',{}).get('mode','DECLARED_ONLY')
    if check_bindings and bundle_root is not None:binds=verify_bindings(bundle,bundle_root)
    else:binds={'status':'NOT_RECHECKED','bindings':[],'rechecked':False}
    prov=claim_paths(bundle);cass=claim_assurance(bundle,binds)
    model_status='PASS' if cross['status'] in {'PASS','NOT_APPLICABLE'} and compilation.get('status') in {'PASS','NOT_APPLICABLE'} else 'FAIL'
    if mode=='DECLARED_ONLY':evidence_status='NOT_APPLICABLE_DECLARED_ONLY'
    elif binds['status']=='PASS' and all(x['evidence_integrity']=='PASS' for x in cass.values()):evidence_status='PASS'
    elif binds['status']=='NOT_RECHECKED':evidence_status='NOT_RECHECKED'
    else:evidence_status='FAIL'
    overall='FAIL' if model_status=='FAIL' or evidence_status=='FAIL' else ('PARTIAL' if evidence_status=='NOT_RECHECKED' else 'PASS')
    if bundle.get('bundle_version')=='0.5':assurance='BLIND_COMPILED_EVIDENCE_VERIFIED' if evidence_status=='PASS' else ('BLIND_COMPILED_DECLARED_ONLY' if mode=='DECLARED_ONLY' else 'BLIND_COMPILED_EVIDENCE_NOT_RECHECKED')
    else:assurance='DECLARED_SEMANTICS_EVIDENCE_VERIFIED' if evidence_status=='PASS' else ('DECLARED_SEMANTICS_DECLARED_ONLY' if mode=='DECLARED_ONLY' else 'DECLARED_SEMANTICS_EVIDENCE_NOT_RECHECKED')
    return {
        'software_release':'0.6.0','bundle_version':bundle['bundle_version'],'bundle_id':bundle['bundle_id'],'bundle_digest':digest_obj(bundle),
        'semantic_assurance_class':assurance,'compilation':compilation,
        'structural':s,'exact_realization':e,'cross_layer':cross,
        'model_verification_status':model_status,'evidence_verification_status':evidence_status,'verification_status':overall,
        'binding_integrity':binds,'provenance_paths':prov,'claim_assurance':cass,'claim_boundary':bundle.get('claim_boundary',{}),'verifier_boundary':VERIFIER_BOUNDARY
    }

import json,hashlib,math
from pathlib import Path
SAFE_INT=9007199254740991

def canonical_bytes(obj):
    return json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode('utf-8')
def digest_obj(obj): return hashlib.sha256(canonical_bytes(obj)).hexdigest()
def sha256_file(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()
def require(cond,msg):
    if not cond: raise ValueError(msg)
def safe_resolve(root,rel):
    require(isinstance(rel,str) and rel and not Path(rel).is_absolute(),'binding path must be a nonempty relative path')
    root=Path(root).resolve(); p=(root/rel).resolve()
    try:p.relative_to(root)
    except ValueError: raise ValueError(f'binding path escapes bundle root: {rel}')
    return p

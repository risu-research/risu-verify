from pathlib import Path
import copy,json,os,shutil,subprocess,sys,tempfile
from .common import canonical_bytes,digest_obj,require,sha256_file

ROOT=Path(__file__).resolve().parents[1]
PY_COMPILER=ROOT/'compiler/implementations/reference_compiler.py'
NODE_COMPILER=ROOT/'compiler/implementations/node_compiler.js'
PROTOCOL='risu-semantic-compiler/0.5'
_DUAL_CACHE={}
FORBIDDEN_PAYLOAD_KEYS={
    'source_by_world','consequence_by_world','declared_target_model_by_world','target_model_by_world',
    'compatibility_consequence_by_world','compatibility_target_model_by_world','compatibility_contract_signature_by_world',
    'signature_by_world','operative_signature_by_world','mechanism_consequence_by_world','expected_verdict','expected_result'
}

def _keys_recursive(v):
    out=[]
    if isinstance(v,dict):
        for k,x in v.items():out.append(k);out.extend(_keys_recursive(x))
    elif isinstance(v,list):
        for x in v:out.extend(_keys_recursive(x))
    return out

def build_compiler_payload(bundle):
    require(bundle.get('bundle_version')=='0.5','semantic compiler requires bundle_version 0.5')
    sem=bundle['semantic'];der=sem['derivation'];facts=der.get('facts',[])
    payload={
        'protocol':PROTOCOL,
        'worlds':[{'id':w['id'],'coordinates':copy.deepcopy(w['coordinates'])} for w in der['world_records']],
        'profile_constants':copy.deepcopy(der.get('profile_constants',{})),
        'established_facts':sorted(f['id'] for f in facts if f.get('status')=='ESTABLISHED'),
        'exact_enabled':bool(sem.get('exact_enabled',False)),
        'program':copy.deepcopy(der['program'])
    }
    seen=set(_keys_recursive(payload));bad=sorted(seen & FORBIDDEN_PAYLOAD_KEYS)
    require(not bad,f'compiler firewall violation: forbidden semantic-table keys in sanitized payload: {bad}')
    return payload,{
        'policy':'PER_WORLD_CONSEQUENCE_TABLE_EXCLUDED',
        'transport':'CANONICAL_JSON_STDIN_ONLY',
        'bundle_path_exposed_to_compiler':False,
        'source_consequence_table_exposed_to_compiler':False,
        'target_model_exposed_to_compiler':False,
        'predeclared_discriminator_table_exposed_to_compiler':False,
        'predeclared_exact_tables_exposed_to_compiler':False,
        'world_identifier_available_for_output_keying_but_not_expression_lookup':True,
        'os_level_sandbox':False,
        'forbidden_key_audit':'PASS'
    }

def _run(cmd,payload):
    env={}
    for k in ('PATH','LANG','LC_ALL','PYTHONIOENCODING'):
        if k in os.environ:env[k]=os.environ[k]
    env.setdefault('PYTHONIOENCODING','utf-8')
    with tempfile.TemporaryDirectory(prefix='risu-semantic-compiler-') as td:
        cp=subprocess.run(cmd,input=canonical_bytes(payload),stdout=subprocess.PIPE,stderr=subprocess.PIPE,cwd=td,env=env,timeout=30)
    text=cp.stdout.decode('utf-8','replace').strip()
    try:obj=json.loads(text)
    except Exception:raise ValueError(f'compiler returned invalid JSON rc={cp.returncode}: {text[:300]} stderr={cp.stderr.decode("utf-8","replace")[-300:]}')
    if cp.returncode!=0 or not obj.get('ok'):
        raise ValueError(f'compiler rejected sanitized input: {obj.get("error") or cp.stderr.decode("utf-8","replace")[-300:]}')
    return obj['result']

def run_dual_compiler(payload):
    node=shutil.which('node');require(node is not None,'Node.js is required for BLIND_COMPILED dual-runtime qualification')
    pysha=sha256_file(PY_COMPILER);nsha=sha256_file(NODE_COMPILER);key=(digest_obj(payload),pysha,nsha)
    if key in _DUAL_CACHE:
        out,rec=_DUAL_CACHE[key];return copy.deepcopy(out),copy.deepcopy(rec)
    py=_run([sys.executable,str(PY_COMPILER)],payload);js=_run([node,str(NODE_COMPILER)],payload)
    require(canonical_bytes(py)==canonical_bytes(js),'semantic compiler Python/Node outputs differ')
    rec={
        'status':'PASS','protocol':PROTOCOL,'python_compiler_sha256':pysha,'node_compiler_sha256':nsha,
        'python_output_digest':digest_obj(py),'node_output_digest':digest_obj(js),'full_result_differential':'PASS'
    }
    _DUAL_CACHE[key]=(copy.deepcopy(py),copy.deepcopy(rec));return py,rec

def _validate_derived_world_maps(derived,worlds,exact_enabled):
    expected=set(worlds)
    needed=['discriminator_signature_by_world']
    if exact_enabled:needed+=['operative_signature_by_world','native_outcome_by_world','mechanism_consequence_by_world']
    for k in needed:
        require(k in derived and isinstance(derived[k],dict),f'compiler output missing {k}')
        require(set(derived[k])==expected,f'compiler output {k} world set differs from declared world set')

def compile_bundle(bundle):
    payload,firewall=build_compiler_payload(bundle);out,diff=run_dual_compiler(payload)
    derived=out['derived'];sem=bundle['semantic'];template=copy.deepcopy(sem['structural_template']);worlds=list(template['boundary']['worlds']);_validate_derived_world_maps(derived,worlds,sem.get('exact_enabled',False))
    disc=template.setdefault('discriminator',{});require('signature_by_world' not in disc,'v0.5 structural_template may not predeclare discriminator.signature_by_world');disc['signature_by_world']=copy.deepcopy(derived['discriminator_signature_by_world'])
    if sem.get('exact_enabled',False):
        exact={
            'worlds':worlds,
            'consequence_by_world':copy.deepcopy(template['consequence']['source_by_world']),
            'operative_signature_by_world':copy.deepcopy(derived['operative_signature_by_world']),
            'mechanism_consequence_by_world':copy.deepcopy(derived['mechanism_consequence_by_world'])
        }
    else:exact=None
    compiled=copy.deepcopy(bundle);compiled['bundle_version']='0.4';compiled['semantic']={'structural_profile':template,'exact_profile':exact}
    record={
        'status':'PASS','mode':'CONSEQUENCE_BLIND_DUAL_RUNTIME','compiler_protocol':PROTOCOL,
        'sanitized_input_digest':digest_obj(payload),'program_digest':digest_obj(payload['program']),
        'firewall':firewall,'dual_runtime':diff,
        'derived_output_digest':digest_obj(out),'derived':copy.deepcopy(derived),
        'stage_fact_requirements':copy.deepcopy(out.get('stage_fact_requirements',{})),
        'stage_input_footprint':copy.deepcopy(out.get('stage_input_footprint',{})),
        'mechanism_fibers':copy.deepcopy(out.get('mechanism_fibers',[])),
        'compiled_structural_profile_digest':digest_obj(template),'compiled_exact_profile_digest':digest_obj(exact) if exact is not None else None,
        'claim_boundary':{
            'per_world_source_consequence_not_compiler_input':True,
            'target_model_not_compiler_input':True,
            'mechanism_stage_reads_only_operative_signature_and_constants':True,
            'interpreter_stage_reads_only_native_outcome_and_constants':True,
            'authorship_independence':'NOT_ESTABLISHED',
            'world_model_adequacy':'NOT_ESTABLISHED',
            'evidence_fact_semantic_truth':'NOT_ESTABLISHED_BY_COMPILER'
        }
    }
    return compiled,record

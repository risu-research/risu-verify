import base64,copy,hashlib,json
from .common import digest_obj,require,sha256_file,safe_resolve
from .projection_adapter import normalize_adapter,normalize_adapter_with_compiled_source,validate_adapter_shape
from .source_contract import compile_source_contract
from .engine import evaluate_bundle
from .certificate import build_certificate as build_inner_certificate,verify_certificate as verify_inner_certificate

CERT_VERSION='0.7'
CERT_SEMANTICS='SOURCE_CONSEQUENCE_CONTRACT_SEPARATED_PROJECTION_WITH_PROOF_CARRYING_INNER_CERTIFICATE'
BOUNDARY={
 'model_relative':True,
 'source_contract_separated_from_projection_adapter':True,
 'worlds_generated_from_declared_finite_domain':True,
 'source_consequence_generated_from_total_declared_function':True,
 'target_compilation_consequence_blind':True,
 'source_contract_file_pin_self_contained':True,
 'source_contract_adequacy':'NOT_ESTABLISHED_BY_VERIFIER',
 'evidence_fact_semantic_truth':'NOT_ESTABLISHED_BY_VERIFIER',
 'live_runtime_conformance':'NOT_ESTABLISHED_BY_VERIFIER',
 'independent_reproduction':'NOT_ESTABLISHED_BY_VERIFIER'
}

def build_projection_certificate(adapter,root):
    b,c,src,rec=normalize_adapter(adapter,root)
    inner=build_inner_certificate(b,root)
    source_path=safe_resolve(root,adapter['source_contract']['path']);source_bytes=source_path.read_bytes()
    require(sha256_file(source_path)==rec['source_contract_file_sha256'],'source contract changed during certificate issuance')
    return {
      'certificate_version':CERT_VERSION,'certificate_semantics':CERT_SEMANTICS,'adapter_id':adapter['adapter_id'],
      'source_contract_snapshot':copy.deepcopy(c),'source_contract_snapshot_digest':digest_obj(c),'source_contract_file_sha256':rec['source_contract_file_sha256'],'source_contract_file_b64':base64.b64encode(source_bytes).decode('ascii'),
      'adapter_snapshot':copy.deepcopy(adapter),'adapter_digest':digest_obj(adapter),
      'source_compilation':copy.deepcopy(rec['source_compilation']),'source_domain_proof':copy.deepcopy(src['domain_proof']),
      'normalized_bundle_digest':digest_obj(b),'inner_certificate':inner,'inner_certificate_digest':digest_obj(inner),
      'results':copy.deepcopy(inner['results']),'verifier_boundary':BOUNDARY
    }

def verify_projection_certificate(cert,evidence_root=None):
    checks=[]
    def ck(n,c,d=''):checks.append({'check':n,'status':'PASS' if c else 'FAIL','detail':d})
    try:
      allowed={'certificate_version','certificate_semantics','adapter_id','source_contract_snapshot','source_contract_snapshot_digest','source_contract_file_sha256','source_contract_file_b64','adapter_snapshot','adapter_digest','source_compilation','source_domain_proof','normalized_bundle_digest','inner_certificate','inner_certificate_digest','results','verifier_boundary'}
      require(isinstance(cert,dict) and set(cert)<=allowed,f'unknown v0.7 certificate keys: {sorted(set(cert)-allowed) if isinstance(cert,dict) else "not-object"}')
      require(cert.get('certificate_version')==CERT_VERSION,'certificate_version must be 0.7');ck('certificate-version',True)
      ck('certificate-semantics',cert.get('certificate_semantics')==CERT_SEMANTICS);ck('verifier-boundary',cert.get('verifier_boundary')==BOUNDARY)
      c=cert['source_contract_snapshot'];a=cert['adapter_snapshot'];validate_adapter_shape(a)
      ck('source-contract-snapshot-digest',digest_obj(c)==cert.get('source_contract_snapshot_digest'));ck('adapter-digest',digest_obj(a)==cert.get('adapter_digest'));ck('adapter-id',a['adapter_id']==cert.get('adapter_id'))
      ck('source-contract-pin-record',a['source_contract']['sha256']==cert.get('source_contract_file_sha256'))
      raw=base64.b64decode(cert.get('source_contract_file_b64',''),validate=True);ck('source-contract-embedded-byte-pin',hashlib.sha256(raw).hexdigest()==cert.get('source_contract_file_sha256'));ck('source-contract-embedded-snapshot',json.loads(raw.decode('utf-8'))==c)
      src,srec=compile_source_contract(c);srec={**srec,'source_contract_file_sha256':cert['source_contract_file_sha256'],'source_contract_path':a['source_contract']['path'],'source_contract_id':c['contract_id']}
      ck('source-compilation-recompute',srec==cert.get('source_compilation'));ck('source-domain-proof',src['domain_proof']==cert.get('source_domain_proof'))
      b,_,_,_=normalize_adapter_with_compiled_source(a,c,src,srec);ck('normalized-bundle-digest',digest_obj(b)==cert.get('normalized_bundle_digest'));inner=cert['inner_certificate'];ck('inner-certificate-digest',digest_obj(inner)==cert.get('inner_certificate_digest'));ck('inner-bundle-equals-normalized',inner.get('bundle_snapshot')==b)
      if evidence_root is not None:
        sp=safe_resolve(evidence_root,a['source_contract']['path']);ck('source-contract-byte-pin',sp.is_file() and sha256_file(sp)==a['source_contract']['sha256']);ck('source-contract-root-bytes-equal-embedded',sp.is_file() and sp.read_bytes()==raw);ck('source-contract-root-snapshot',sp.is_file() and json.loads(sp.read_text())==c)
      ir=verify_inner_certificate(inner,evidence_root);ck('inner-certificate-model',ir['status']!='FAIL',ir['status']);
      if evidence_root is not None and b.get('provenance',{}).get('mode')=='EVIDENCE_LINKED':ck('inner-evidence-recheck',ir['status']=='PASS',ir['status'])
      ck('result-commitment',cert.get('results')==inner.get('results'))
    except Exception as e:ck('exception',False,str(e))
    fail=any(x['status']=='FAIL' for x in checks);partial=(not fail and cert.get('inner_certificate',{}).get('bundle_snapshot',{}).get('provenance',{}).get('mode')=='EVIDENCE_LINKED' and evidence_root is None)
    return {'status':'FAIL' if fail else ('PARTIAL' if partial else 'PASS'),'checks':checks,'passed':sum(x['status']=='PASS' for x in checks),'failed':sum(x['status']=='FAIL' for x in checks),'total':len(checks)}

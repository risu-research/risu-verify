from pathlib import Path
import json,re
from .common import require,safe_resolve,sha256_file
from .provenance import EVIDENCE_BINDING_KINDS,upstream_node_ids

EDGE_RULES={
    # v0.4-compatible relations
    'SUPPORTS':({'EVIDENCE','DERIVATION'},{'DERIVATION','CLAIM'}),
    'GROUNDS':({'EVIDENCE'},{'DERIVATION','CLAIM'}),
    'DERIVES':({'DECLARATION','DERIVATION'},{'DERIVATION','CLAIM'}),
    'BOUNDS':({'DECLARATION'},{'DERIVATION','CLAIM'}),
    # v0.5 consequence-blind compilation relations
    'ESTABLISHES':({'EVIDENCE'},{'FACT'}),
    'USES':({'FACT','DECLARATION'},{'DERIVATION'})
}
CLAIMS={'C','D','O','EXACT','COVERAGE'}
NODE_KINDS={'EVIDENCE','FACT','DECLARATION','DERIVATION','CLAIM'}

def load_bundle(path):
    p=Path(path)
    if p.is_dir(): p=p/'bundle.json'
    require(p.is_file(),f'bundle not found: {p}')
    obj=json.loads(p.read_text())
    return obj,p,p.parent

def _validate_v04_semantic(sem):
    require(isinstance(sem,dict),'semantic object required')
    allowed={'structural_profile','exact_profile'};require(set(sem)<=allowed,f'unknown semantic keys: {sorted(set(sem)-allowed)}')
    require(isinstance(sem.get('structural_profile'),dict),'semantic.structural_profile required')
    if sem.get('exact_profile') is not None:require(isinstance(sem['exact_profile'],dict),'exact_profile must be object or null')

def _required_program_facts(program):
    out={}
    if not isinstance(program,dict):return out
    for stage in ('discriminator','operative_signature','mechanism','interpreter'):
        spec=program.get(stage)
        if isinstance(spec,dict):
            fs=spec.get('required_fact_ids',[])
            if isinstance(fs,list):out[stage]=list(fs)
    return out

def _validate_v05_semantic(sem,prov,node_by_id,binding_by_id,bundle):
    require(isinstance(sem,dict),'semantic object required')
    allowed={'structural_template','exact_enabled','derivation'};require(set(sem)<=allowed,f'unknown v0.5 semantic keys: {sorted(set(sem)-allowed)}')
    st=sem.get('structural_template');require(isinstance(st,dict),'semantic.structural_template required')
    require(type(sem.get('exact_enabled')) is bool,'semantic.exact_enabled must be boolean')
    require(isinstance(st.get('boundary'),dict) and isinstance(st['boundary'].get('worlds'),list) and st['boundary']['worlds'],'structural_template.boundary.worlds must be nonempty array')
    worlds=st['boundary']['worlds'];require(all(isinstance(w,str) and w for w in worlds) and len(set(worlds))==len(worlds),'structural_template boundary world identifiers must be unique strings')
    require(isinstance(st.get('consequence'),dict) and isinstance(st['consequence'].get('source_by_world'),dict),'structural_template.consequence.source_by_world required')
    for w in worlds:require(w in st['consequence']['source_by_world'],f'source consequence missing world {w}')
    disc=st.get('discriminator',{});require(isinstance(disc,dict),'structural_template.discriminator must be object if present');require('signature_by_world' not in disc,'v0.5 structural_template may not predeclare discriminator.signature_by_world')
    der=sem.get('derivation');require(isinstance(der,dict),'semantic.derivation required')
    allowed_d={'mode','world_records','profile_constants','facts','program'};require(set(der)<=allowed_d,f'unknown derivation keys: {sorted(set(der)-allowed_d)}')
    require(der.get('mode')=='CONSEQUENCE_BLIND','derivation.mode must be CONSEQUENCE_BLIND')
    wr=der.get('world_records');require(isinstance(wr,list) and wr,'derivation.world_records must be nonempty array')
    ids=[]
    for i,r in enumerate(wr):
        require(isinstance(r,dict) and set(r)<= {'id','coordinates'} and set(r)>= {'id','coordinates'},f'world_records[{i}] must contain only id and coordinates')
        require(isinstance(r['id'],str) and r['id'],'world record id required');require(isinstance(r['coordinates'],dict),f'world record {r["id"]} coordinates must be object');require('id' not in r['coordinates'],f'world record {r["id"]} coordinates may not contain reserved key id');ids.append(r['id'])
    require(ids==worlds,'derivation.world_records ids and order must exactly match structural_template.boundary.worlds')
    pc=der.get('profile_constants',{});require(isinstance(pc,dict),'derivation.profile_constants must be object')
    facts=der.get('facts',[]);require(isinstance(facts,list),'derivation.facts must be array');fids=set();fact_by_id={};fact_nodes=set()
    for f in facts:
        require(isinstance(f,dict) and set(f)<= {'id','status','provenance_node'},f'unknown fact keys: {sorted(set(f)-{"id","status","provenance_node"})}')
        require(isinstance(f.get('id'),str) and f['id'] and f['id'] not in fids,f'duplicate or invalid fact id {f.get("id")}');fids.add(f['id']);fact_by_id[f['id']]=f
        require(f.get('status') in {'ESTABLISHED','UNRESOLVED','CONTRADICTED'},f'unsupported fact status {f.get("status")}')
        pn=f.get('provenance_node')
        if pn is not None:
            require(pn in node_by_id,f'fact {f["id"]} references unknown provenance_node {pn}');require(node_by_id[pn]['kind']=='FACT',f'fact {f["id"]} provenance_node must be FACT');require(pn not in fact_nodes,f'FACT provenance node reused across fact declarations: {pn}');fact_nodes.add(pn)
    program=der.get('program');require(isinstance(program,dict),'derivation.program required')
    req_by_stage=_required_program_facts(program);defined=set(fact_by_id)
    for stage,reqs in req_by_stage.items():
        require(len(reqs)==len(set(reqs)) and all(isinstance(x,str) and x for x in reqs),f'{stage}.required_fact_ids must be unique strings')
        require(set(reqs)<=defined,f'{stage} references undefined facts: {sorted(set(reqs)-defined)}')
        for fid in reqs:require(fact_by_id[fid]['status']=='ESTABLISHED',f'{stage} requires fact {fid} but status is {fact_by_id[fid]["status"]}')
    if prov.get('mode')=='EVIDENCE_LINKED':
        # Every established fact actually used by the blind compiler must be a byte-grounded FACT in the provenance DAG.
        used=set(x for xs in req_by_stage.values() for x in xs)
        for fid in sorted(used):
            f=fact_by_id[fid];pn=f.get('provenance_node');require(pn is not None,f'EVIDENCE_LINKED compiler fact {fid} missing provenance_node')
            upstream=upstream_node_ids(bundle,pn);enodes=[n for n in upstream if node_by_id[n]['kind']=='EVIDENCE'];req=[]
            for n in enodes:
                for bid in node_by_id[n].get('binding_ids',[]):
                    b=binding_by_id[bid]
                    if b['kind'] in EVIDENCE_BINDING_KINDS and b.get('required',True):req.append(bid)
            require(req,f'compiler fact {fid} has no upstream required evidence/source/qualification binding')
            targets=[]
            if fid in set(req_by_stage.get('discriminator',[])):targets.append('D')
            if fid in set(req_by_stage.get('operative_signature',[])+req_by_stage.get('mechanism',[])+req_by_stage.get('interpreter',[])):targets.append('EXACT')
            for target in targets:
                roots=prov.get('claim_roots',{}).get(target,[])
                require(any(pn in upstream_node_ids(bundle,r) for r in roots),f'compiler fact {fid} provenance node is not upstream of the {target} claim')
    return True

def validate_bundle_shape(b):
    allowed={'bundle_version','bundle_id','metadata','semantic','bindings','provenance','claim_boundary','annotations'}
    require(isinstance(b,dict),'bundle must be an object');require(set(b)<=allowed,f'unknown top-level bundle keys: {sorted(set(b)-allowed)}')
    version=b.get('bundle_version');require(version in {'0.4','0.5'},'bundle_version must be 0.4 or 0.5')
    require(isinstance(b.get('bundle_id'),str) and b['bundle_id'],'bundle_id required')
    sem=b.get('semantic');require(isinstance(sem,dict),'semantic object required')
    binds=b.get('bindings',[]);require(isinstance(binds,list),'bindings must be array')
    ids=set();binding_by_id={}
    for x in binds:
        require(isinstance(x,dict),'binding must be object');allowed_b={'id','kind','path','sha256','required','role'};require(set(x)<=allowed_b,f'unknown binding keys: {sorted(set(x)-allowed_b)}');require(isinstance(x.get('id'),str) and x['id'],'binding id required');require(x['id'] not in ids,f'duplicate binding id {x["id"]}');ids.add(x['id']);binding_by_id[x['id']]=x
        require(x.get('kind') in {'EVIDENCE','QUALIFICATION','SOURCE','AUXILIARY'},f'unsupported binding kind {x.get("kind")}')
        require(isinstance(x.get('path'),str) and x['path'],'binding path required');require(isinstance(x.get('sha256'),str) and re.fullmatch(r'[0-9a-f]{64}',x['sha256']) is not None,'binding sha256 must be 64 lowercase hex characters');require(isinstance(x.get('required',True),bool),'binding required must be boolean')
    prov=b.get('provenance',{'mode':'DECLARED_ONLY','nodes':[],'edges':[],'claim_roots':{}});require(isinstance(prov,dict),'provenance must be object');require(set(prov)<= {'mode','nodes','edges','claim_roots'},f'unknown provenance keys: {sorted(set(prov)-{"mode","nodes","edges","claim_roots"})}')
    require(prov.get('mode') in {'DECLARED_ONLY','EVIDENCE_LINKED'},'unsupported provenance mode')
    nodes=prov.get('nodes',[]);edges=prov.get('edges',[]);roots=prov.get('claim_roots',{});require(isinstance(nodes,list) and isinstance(edges,list) and isinstance(roots,dict),'invalid provenance containers')
    nids=set();node_by_id={};referenced_binding_ids=set()
    for n in nodes:
        allowed_n={'id','kind','label','binding_ids'};require(isinstance(n,dict) and set(n)<=allowed_n,f'unknown provenance node keys: {sorted(set(n)-allowed_n)}');require(isinstance(n.get('id'),str) and n['id'],'provenance node id required');require(n['id'] not in nids,f'duplicate provenance node {n["id"]}');nids.add(n['id']);node_by_id[n['id']]=n
        require(n.get('kind') in NODE_KINDS,f'unsupported provenance node kind {n.get("kind")}')
        bids=n.get('binding_ids',[]);require(isinstance(bids,list) and len(bids)==len(set(bids)),f'provenance node {n["id"]} binding_ids must be a unique array')
        for bid in bids:require(bid in ids,f'provenance node {n["id"]} references unknown binding {bid}')
        if n['kind']=='EVIDENCE':
            require(bids,f'EVIDENCE node {n["id"]} must reference at least one binding');require(any(binding_by_id[bid]['kind'] in EVIDENCE_BINDING_KINDS for bid in bids),f'EVIDENCE node {n["id"]} must reference at least one EVIDENCE/QUALIFICATION/SOURCE binding')
        else:require(not bids,f'only EVIDENCE nodes may carry binding_ids: {n["id"]}')
        referenced_binding_ids.update(bids)
    adj={n:set() for n in nids};indeg={n:0 for n in nids};edge_keys=set()
    for e in edges:
        allowed_e={'from','to','relation'};require(isinstance(e,dict) and set(e)<=allowed_e,f'unknown provenance edge keys: {sorted(set(e)-allowed_e)}');require(e.get('from') in nids and e.get('to') in nids,'provenance edge references unknown node');rel=e.get('relation');require(rel in EDGE_RULES,f'unsupported provenance relation {rel}')
        key=(e['from'],e['to'],rel);require(key not in edge_keys,f'duplicate provenance edge {key}');edge_keys.add(key)
        src=node_by_id[e['from']]['kind'];dst=node_by_id[e['to']]['kind'];sa,da=EDGE_RULES[rel];require(src in sa and dst in da,f'invalid provenance edge typing: {src} -{rel}-> {dst}')
        if e['to'] not in adj[e['from']]:adj[e['from']].add(e['to']);indeg[e['to']]+=1
    q=[n for n,d in indeg.items() if d==0];seen=0
    while q:
        n=q.pop();seen+=1
        for m in adj[n]:
            indeg[m]-=1
            if indeg[m]==0:q.append(m)
    require(seen==len(nids),'provenance graph contains a cycle')
    rooted_claim_nodes=set();root_owner={}
    for claim,rs in roots.items():
        require(claim in CLAIMS,f'unsupported claim root key {claim}');require(isinstance(rs,list) and rs and len(rs)==len(set(rs)),f'claim root {claim} must be a nonempty unique array')
        for r in rs:
            require(r in nids,f'claim root {claim} references unknown node {r}');require(node_by_id[r]['kind']=='CLAIM',f'claim root {claim} must reference CLAIM nodes, got {node_by_id[r]["kind"]}: {r}');require(r not in root_owner,f'CLAIM root {r} is reused across claim types {root_owner.get(r)} and {claim}');root_owner[r]=claim;rooted_claim_nodes.add(r)
    all_claim_nodes={n['id'] for n in nodes if n['kind']=='CLAIM'};require(all_claim_nodes==rooted_claim_nodes,f'every CLAIM node must be rooted exactly through claim_roots; unrooted={sorted(all_claim_nodes-rooted_claim_nodes)}')
    if version=='0.4':_validate_v04_semantic(sem)
    exact_present=(sem.get('exact_profile') is not None) if version=='0.4' else bool(sem.get('exact_enabled'))
    if prov.get('mode')=='DECLARED_ONLY':
        require(not any(n['kind']=='EVIDENCE' for n in nodes),'DECLARED_ONLY provenance may not contain EVIDENCE nodes; use AUXILIARY bindings for non-epistemic files');require(not any(x['kind'] in EVIDENCE_BINDING_KINDS for x in binds),'DECLARED_ONLY bundles may not declare EVIDENCE/QUALIFICATION/SOURCE bindings')
    if prov.get('mode')=='EVIDENCE_LINKED':
        for needed in ('C','D','O','COVERAGE'):require(needed in roots,f'EVIDENCE_LINKED provenance missing {needed} claim root')
        if exact_present:require('EXACT' in roots,'EVIDENCE_LINKED provenance missing EXACT claim root')
        used_evidence_nodes=set();used_required_epistemic=set()
        for claim,rs in roots.items():
            for r in rs:
                upstream=upstream_node_ids(b,r);enodes=[nid for nid in upstream if node_by_id[nid]['kind']=='EVIDENCE'];used_evidence_nodes.update(enodes);required_ep=[]
                for nid in enodes:
                    for bid in node_by_id[nid].get('binding_ids',[]):
                        bx=binding_by_id[bid]
                        if bx['kind'] in EVIDENCE_BINDING_KINDS and bx.get('required',True):required_ep.append(bid);used_required_epistemic.add(bid)
                require(required_ep,f'EVIDENCE_LINKED root {claim}:{r} has no upstream required evidence/qualification/source binding')
        all_evidence_nodes={n['id'] for n in nodes if n['kind']=='EVIDENCE'};require(all_evidence_nodes<=used_evidence_nodes,f'dangling EVIDENCE nodes not upstream of any claim: {sorted(all_evidence_nodes-used_evidence_nodes)}')
        epistemic={x['id'] for x in binds if x['kind'] in EVIDENCE_BINDING_KINDS};require(epistemic<=referenced_binding_ids,f'epistemic bindings not referenced by any EVIDENCE node: {sorted(epistemic-referenced_binding_ids)}')
        required_epistemic={x['id'] for x in binds if x['kind'] in EVIDENCE_BINDING_KINDS and x.get('required',True)};require(required_epistemic<=used_required_epistemic,f'required epistemic bindings not used by any claim path: {sorted(required_epistemic-used_required_epistemic)}')
    if version=='0.5':_validate_v05_semantic(sem,prov,node_by_id,binding_by_id,b)
    return True

def verify_bindings(b,root):
    declared=b.get('bindings',[])
    if not declared:return {'status':'NO_BINDINGS_DECLARED','bindings':[],'rechecked':True}
    rows=[]
    for x in declared:
        try:
            p=safe_resolve(root,x['path']);exists=p.is_file();got=sha256_file(p) if exists else None
            if not exists and not x.get('required',True):status='OPTIONAL_MISSING'
            elif exists and got==x['sha256']:status='PASS'
            else:status='FAIL'
            rows.append({'id':x['id'],'kind':x['kind'],'path':x['path'],'required':x.get('required',True),'status':status,'expected_sha256':x['sha256'],'actual_sha256':got})
        except Exception as e:rows.append({'id':x.get('id'),'kind':x.get('kind'),'path':x.get('path'),'required':x.get('required',True),'status':'FAIL','error':str(e)})
    ok=all(r['status']=='PASS' or (r['status']=='OPTIONAL_MISSING' and not r['required']) for r in rows)
    return {'status':'PASS' if ok else 'FAIL','bindings':rows,'rechecked':True}

def verify_cross_layer(b,json_equal):
    sem=b['semantic'];exact=sem.get('exact_profile')
    if exact is None:return {'status':'NOT_APPLICABLE','mode':'STRUCTURAL_ONLY'}
    s=sem['structural_profile'];sw=s['boundary']['worlds'];ew=exact['worlds'];require(set(sw)==set(ew) and len(sw)==len(ew),'exact and structural profiles must use the same declared world set')
    K=s['consequence']['source_by_world'];EK=exact['consequence_by_world']
    for w in sw:require(w in EK and json_equal(K[w],EK[w]),f'exact consequence does not match structural source consequence at world {w}')
    return {'status':'PASS','mode':'SAME_DECLARED_PROFILE','worlds':len(sw)}

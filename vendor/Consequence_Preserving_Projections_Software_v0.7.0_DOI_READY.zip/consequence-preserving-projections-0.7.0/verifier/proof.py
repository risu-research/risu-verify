import copy
from .common import digest_obj
from .engine import evaluate_bundle,json_equal
from .provenance import claim_provenance_summary
from .semantic_compiler import build_compiler_payload

PROOF_VERSION='0.6'
PROOF_SEMANTICS='FINITE_CONSEQUENCE_ASSURANCE_PROOF_WITH_BLIND_COMPILATION_AND_LOCAL_WITNESSES'

def _jeq(a,b): return json_equal(a,b)

def _groups(worlds, values):
    gs=[]
    for w in worlds:
        v=values[w]
        g=next((x for x in gs if _jeq(x['value'],v)),None)
        if g is None:
            g={'value':copy.deepcopy(v),'worlds':[]};gs.append(g)
        g['worlds'].append(w)
    return gs

def _d_proof(worlds,K,D):
    if D['D']=='D0':
        return {'status':'D0','kind':'DIVERGENT_PAIR','witness':copy.deepcopy(D['D_witness'])}
    if D['D']!='D1': return {'status':D['D'],'kind':'NOT_APPLICABLE'}
    rows=[]
    for g in _groups(worlds,D['_d_by_world']):
        rows.append({'signature':g['value'],'worlds':g['worlds'],'consequence':copy.deepcopy(K[g['worlds'][0]])})
    return {'status':'D1','kind':'FIBER_DECODER','fibers':rows,'precision':D['precision'],'overdiscrimination_witness':copy.deepcopy(D['overdiscrimination_witness'])}

def _o_rule(s):
    b=s['O_basis']
    if b is None:return 'NOT_APPLICABLE'
    g,cut,post=b['gates_effect'],b['evaluation_cut'],b['post_check_material_transition_possible']
    if g=='UNKNOWN' or cut=='UNKNOWN':return 'UNKNOWN_INPUT'
    if g is False or cut=='NONE':return 'NO_EFFECT_GATE'
    if g is True and cut=='ENVIRONMENT':return 'ENVIRONMENT_REPLACEMENT'
    if g is True and cut=='EFFECT':return 'EFFECT_GATE'
    if g is True and cut=='PRE_EFFECT':return 'PRE_EFFECT_MATERIAL_TRANSITION' if post else 'PRE_EFFECT_STABLE'
    return 'UNSUPPORTED_PATTERN'

def build_proof(bundle,bundle_root=None):
    r=evaluate_bundle(bundle,bundle_root,check_bindings=bundle_root is not None)
    if r['model_verification_status']!='PASS':raise ValueError('cannot build proof for failed model verification')
    if bundle.get('bundle_version')!='0.5':raise ValueError('proof-carrying certificate requires bundle_version 0.5 consequence-blind compilation')
    worlds=list(bundle['semantic']['structural_template']['boundary']['worlds'])
    K=bundle['semantic']['structural_template']['consequence']['source_by_world']
    d=r['compilation']['derived']['discriminator_signature_by_world']
    s=copy.deepcopy(r['structural']);s['_d_by_world']=d
    structural={
        'C':{'status':s['C'],'correspondence_status':bundle['semantic']['structural_template']['correspondence']['status']},
        'D':_d_proof(worlds,K,s),
        'O':{'status':s['O'],'rule':_o_rule(s),'premises':copy.deepcopy(s['O_basis'])},
        'coverage':{'complete':s['coverage_complete'],'source_only':copy.deepcopy(s['coverage_gap']['source_only']),'in_scope_only':copy.deepcopy(s['coverage_gap']['in_scope_only'])},
        'classification':s['structural_classification'],
        'declared_model_crosscheck':s['declared_model_crosscheck']
    }
    e=r['exact_realization'];exact={'enabled':e is not None}
    if e is not None:
        exact.update({
            'z_sufficiency':{'sufficient':e['z_sufficient'],'fibers':copy.deepcopy(e['required_decoder']) if e['z_sufficient'] else None,'witness':copy.deepcopy(e['z_witness'])},
            'alpha_alignment':{'status':e['alpha_alignment_status'],'aligned':e['alpha_aligned'],'witness':copy.deepcopy(e['alignment_witness'])},
            'world_mismatches':copy.deepcopy(e['world_mismatches']),'outside_c':copy.deepcopy(e['outside_c']),
            'exact':e['exact'],'status':e['status'],'failure_mode':e['failure_mode'],'minimal_counterexample':copy.deepcopy(e['minimal_counterexample'])
        })
    payload,firewall=build_compiler_payload(bundle)
    proof={
        'proof_version':PROOF_VERSION,'proof_semantics':PROOF_SEMANTICS,'bundle_digest':digest_obj(bundle),
        'blind_compilation':{
            'protocol':r['compilation']['compiler_protocol'],'sanitized_input_digest':digest_obj(payload),'program_digest':digest_obj(payload['program']),
            'firewall':copy.deepcopy(firewall),'stage_input_footprint':copy.deepcopy(r['compilation']['stage_input_footprint']),
            'derived':copy.deepcopy(r['compilation']['derived']),'mechanism_fibers':copy.deepcopy(r['compilation']['mechanism_fibers'])
        },
        'structural':structural,'exact':exact,'cross_layer':copy.deepcopy(r['cross_layer']),
        'claim_support':copy.deepcopy(claim_provenance_summary(bundle)),
        'verdict_commitment':{'structural':copy.deepcopy(r['structural']),'exact_realization':copy.deepcopy(r['exact_realization']),'cross_layer':copy.deepcopy(r['cross_layer'])}
    }
    proof['proof_digest']=digest_obj(proof)
    return proof

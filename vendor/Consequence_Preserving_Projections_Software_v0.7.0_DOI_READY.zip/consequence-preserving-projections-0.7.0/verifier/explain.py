import json

def _j(v):return json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def render(result):
    s=result['structural'];e=result.get('exact_realization');lines=[]
    lines.append(f"Overall verification: {result.get('verification_status','UNKNOWN')}")
    lines.append(f"Model recomputation: {result.get('model_verification_status','UNKNOWN')}")
    lines.append(f"Evidence verification: {result.get('evidence_verification_status','UNKNOWN')}")
    lines.append(f"Semantic assurance: {result.get('semantic_assurance_class','UNKNOWN')}")
    comp=result.get('compilation',{})
    if comp.get('status')=='PASS':
        lines.append('Consequence-blind compilation: PASS — per-world source consequence, target model, and predeclared d/z/effect tables were excluded from the compiler payload.')
        dr=comp.get('dual_runtime',{});lines.append(f"Compiler differential: {dr.get('full_result_differential','UNKNOWN')} (Python/Node).")
    lines.append(f"Structural: {s['C']} / {s['D']} / {s['O']} — {s['structural_classification']}")
    if s.get('D_witness'):
        w=s['D_witness'];lines.append(f"Discrimination witness: worlds {w['worlds'][0]} and {w['worlds'][1]} share discriminator {_j(w['signature'])} but require consequences {_j(w['consequences'][0])} and {_j(w['consequences'][1])}.")
    if s.get('O_basis'):
        b=s['O_basis'];lines.append(f"Operative placement basis: gates_effect={_j(b['gates_effect'])}, evaluation_cut={b['evaluation_cut']}, post_check_material_transition_possible={_j(b['post_check_material_transition_possible'])}.")
    if not s.get('coverage_complete'):
        g=s.get('coverage_gap',{});lines.append(f"Coverage is incomplete. Source-only capabilities: {_j(g.get('source_only',[]))}.")
    if e is not None:
        lines.append(f"Exact Realization: {e['status']} — {e['failure_mode']}")
        if e['failure_mode']=='OPERATIVE_INSUFFICIENCY' and e.get('minimal_counterexample'):
            m=e['minimal_counterexample'];lines.append(f"Minimal operative witness: {m['worlds'][0]} and {m['worlds'][1]} receive the same compiled operative signature {_j(m['signature'])} but require different consequences {_j(m['consequences'])}.")
            lines.append('Repair obligation: introduce, reacquire, or revalidate consequence-relevant information before the effect; deterministic post-processing of the unchanged signature is insufficient.')
        elif e['failure_mode']=='MECHANISM_MISALIGNMENT' and e.get('minimal_counterexample'):
            lines.append(f"Effect mismatch: {_j(e['minimal_counterexample']['detail'])}.");lines.append('Repair obligation: align the grounded effect mechanism with the unique consequence decoder required on each operative-signature fiber.')
        elif e['status']=='REALIZATION_ESTABLISHED':lines.append('The compiled operative signature is sufficient and the compiled grounded mechanism interpretation agrees with the required consequence decoder on every declared world.')
    ca=result.get('claim_assurance',{})
    for claim in ['C','D','O','EXACT','COVERAGE']:
        if claim in ca:
            row=ca[claim];bids=row.get('required_epistemic_binding_ids',[])
            if bids:lines.append(f"{claim} evidence path: {', '.join(bids)} — {row.get('evidence_integrity')}.")
    if result.get('evidence_verification_status')=='NOT_RECHECKED':lines.append('The semantic model was recomputed, but claim-linked evidence bytes were not rechecked; this is a partial verification, not an evidence-verified PASS.')
    vb=result.get('verifier_boundary',{})
    if vb:lines.append('Verifier boundary: blind compilation establishes input separation from the per-world K table, not authorship independence, world-model adequacy, live-runtime conformance, general source equivalence, or independent reproduction.')
    return '\n'.join(lines)

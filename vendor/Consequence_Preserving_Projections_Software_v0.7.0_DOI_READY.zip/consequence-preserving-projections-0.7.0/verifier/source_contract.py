from pathlib import Path
import copy,json,os,shutil,subprocess,sys,tempfile
from .common import canonical_bytes,digest_obj,require,sha256_file,safe_resolve

ROOT=Path(__file__).resolve().parents[1]
PY_COMPILER=ROOT/'source_compiler/implementations/reference_source_compiler.py'
NODE_COMPILER=ROOT/'source_compiler/implementations/node_source_compiler.js'
PROTOCOL='risu-source-consequence-contract/0.7'
_CACHE={}

def load_source_contract(path):
    p=Path(path)
    require(p.is_file(),f'source contract not found: {p}')
    return json.loads(p.read_text()),p

def _run(cmd,obj):
    env={k:os.environ[k] for k in ('PATH','LANG','LC_ALL','PYTHONIOENCODING') if k in os.environ};env.setdefault('PYTHONIOENCODING','utf-8')
    with tempfile.TemporaryDirectory(prefix='risu-source-contract-') as td:
        cp=subprocess.run(cmd,input=canonical_bytes(obj),stdout=subprocess.PIPE,stderr=subprocess.PIPE,cwd=td,env=env,timeout=30)
    text=cp.stdout.decode('utf-8','replace').strip()
    try:r=json.loads(text)
    except Exception:raise ValueError(f'source compiler returned invalid JSON rc={cp.returncode}: {text[:300]} stderr={cp.stderr.decode("utf-8","replace")[-300:]}')
    if cp.returncode!=0 or not r.get('ok'):raise ValueError(f'source contract rejected: {r.get("error") or cp.stderr.decode("utf-8","replace")[-300:]}')
    return r['result']

def compile_source_contract(contract):
    pysha=sha256_file(PY_COMPILER);nsha=sha256_file(NODE_COMPILER);key=(digest_obj(contract),pysha,nsha)
    if key in _CACHE:
        out,rec=_CACHE[key];return copy.deepcopy(out),copy.deepcopy(rec)
    node=shutil.which('node');require(node is not None,'Node.js is required for v0.7 dual source-contract compilation')
    py=_run([sys.executable,str(PY_COMPILER)],contract);js=_run([node,str(NODE_COMPILER)],contract)
    require(canonical_bytes(py)==canonical_bytes(js),'source-contract Python/Node outputs differ')
    rec={'status':'PASS','protocol':PROTOCOL,'python_compiler_sha256':pysha,'node_compiler_sha256':nsha,'full_result_differential':'PASS','source_output_digest':digest_obj(py),'source_semantic_digest':py['source_semantic_digest'],'domain_proof':copy.deepcopy(py['domain_proof']),'stage_input_footprint':copy.deepcopy(py['stage_input_footprint']),'claim_boundary':{'authored_world_table':False,'authored_per_world_consequence_table':False,'declared_domain_adequacy':'NOT_ESTABLISHED','consequence_function_adequacy':'NOT_ESTABLISHED','boundary_adequacy':'NOT_ESTABLISHED'}}
    _CACHE[key]=(copy.deepcopy(py),copy.deepcopy(rec));return py,rec

def load_pinned_source_contract(adapter,root):
    ref=adapter.get('source_contract');require(isinstance(ref,dict) and set(ref)=={'path','sha256'},'source_contract must contain exactly path and sha256')
    p=safe_resolve(root,ref['path']);require(p.is_file(),f'source contract not found: {ref["path"]}');got=sha256_file(p);require(got==ref['sha256'],f'source contract hash mismatch: expected {ref["sha256"]}, got {got}')
    c=json.loads(p.read_text());out,rec=compile_source_contract(c);rec={**rec,'source_contract_file_sha256':got,'source_contract_path':ref['path'],'source_contract_id':c['contract_id']};return c,out,rec,p

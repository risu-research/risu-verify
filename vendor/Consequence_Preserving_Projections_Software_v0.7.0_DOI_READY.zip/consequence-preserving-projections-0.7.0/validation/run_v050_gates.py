#!/usr/bin/env python3
from pathlib import Path
import copy,json,os,subprocess,sys,tempfile,shutil
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from verifier.bundle import validate_bundle_shape,verify_bindings
from verifier.engine import evaluate_bundle,VERIFIER_BOUNDARY
from verifier.semantic_compiler import compile_bundle,build_compiler_payload
from verifier.certificate import build_certificate,verify_certificate
from verifier.common import canonical_bytes

checks=[]
def ck(name,cond,detail=''):
    checks.append({'check':name,'status':'PASS' if cond else 'FAIL','detail':detail})
def rejects(name,fn,contains=None):
    try:fn();ck(name,False,'unexpected accept')
    except Exception as e:ck(name,contains in str(e) if contains else True,str(e))
def load(rel):
    p=ROOT/rel;return json.loads((p/'bundle.json').read_text()),p

gh,ghroot=load('bundles/canonical/github');az,azroot=load('bundles/canonical/azure');gp,gproot=load('bundles/examples/generic-preserved');gd0,gd0root=load('bundles/examples/generic-d0-exact-established');gm,gmroot=load('bundles/examples/generic-d1-mechanism-misaligned');gi,giroot=load('bundles/examples/generic-operative-insufficient');gst,gstroot=load('bundles/examples/logical-operation-static-token')
# 1. Canonical and carrier-neutral semantic outcomes.
for b,r in [(gh,ghroot),(az,azroot),(gp,gproot),(gd0,gd0root),(gm,gmroot),(gi,giroot),(gst,gstroot)]:validate_bundle_shape(b)
rgh=evaluate_bundle(gh,ghroot);raz=evaluate_bundle(az,azroot);rgp=evaluate_bundle(gp,gproot);rgd=evaluate_bundle(gd0,gd0root);rgm=evaluate_bundle(gm,gmroot);rgi=evaluate_bundle(gi,giroot);rgs=evaluate_bundle(gst,gstroot)
ck('canonical-github-evidence-pass',rgh['verification_status']=='PASS' and rgh['evidence_verification_status']=='PASS')
ck('canonical-github-semantic-result',rgh['structural']['C']=='C1' and rgh['structural']['D']=='D1' and rgh['structural']['O']=='O0' and rgh['exact_realization']['failure_mode']=='MECHANISM_MISALIGNMENT')
ck('canonical-azure-evidence-pass',raz['verification_status']=='PASS' and raz['evidence_verification_status']=='PASS')
ck('canonical-azure-semantic-result',raz['structural']['C']=='C1' and raz['structural']['D']=='D1' and raz['structural']['O']=='O1' and raz['exact_realization']['status']=='REALIZATION_ESTABLISHED')
ck('canonical-blind-assurance-class',rgh['semantic_assurance_class']==raz['semantic_assurance_class']=='BLIND_COMPILED_EVIDENCE_VERIFIED')
ck('generic-preserved',rgp['structural']['D']=='D1' and rgp['exact_realization']['status']=='REALIZATION_ESTABLISHED')
ck('generic-d0-exact-established',rgd['structural']['D']=='D0' and rgd['exact_realization']['status']=='REALIZATION_ESTABLISHED')
ck('generic-d1-mechanism-misaligned',rgm['structural']['D']=='D1' and rgm['exact_realization']['failure_mode']=='MECHANISM_MISALIGNMENT')
ck('generic-operative-insufficient',rgi['structural']['D']=='D1' and rgi['exact_realization']['failure_mode']=='OPERATIVE_INSUFFICIENCY')
ck('generic-static-token-insufficient',rgs['exact_realization']['failure_mode']=='OPERATIVE_INSUFFICIENCY')
ck('all-v05-compilation-pass',all(r['compilation']['status']=='PASS' and r['compilation']['dual_runtime']['full_result_differential']=='PASS' for r in [rgh,raz,rgp,rgd,rgm,rgi,rgs]))
# 2. Firewall/dataflow noninterference.
_,c0=compile_bundle(gp)
mk=copy.deepcopy(gp);mk['semantic']['structural_template']['consequence']['source_by_world']={'w0':'SAME','w1':'SAME'};validate_bundle_shape(mk);_,ckmut=compile_bundle(mk)
ck('K-mutation-does-not-change-derived-semantics',c0['derived_output_digest']==ckmut['derived_output_digest'])
ck('K-mutation-does-not-change-input-footprint',c0['stage_input_footprint']==ckmut['stage_input_footprint'])
allowed_footprints={'discriminator':{'world','const'},'operative_signature':{'world','const'},'mechanism':{'z','const'},'interpreter':{'native','const'}}
ck('compiler-footprint-stage-namespace-discipline',all({x['source'] for x in rows}<=allowed_footprints[stage] for stage,rows in c0['stage_input_footprint'].items()))
ck('compiler-footprint-excludes-fact-and-consequence-namespaces',all(x['source'] not in {'facts','K','consequence','target_model'} for rows in c0['stage_input_footprint'].values() for x in rows))
rt=evaluate_bundle(mk,gproot);ck('K-mutation-can-change-verdict-not-compiler',rt['exact_realization']['status']!='REALIZATION_ESTABLISHED' and c0['derived_output_digest']==ckmut['derived_output_digest'])
mt=copy.deepcopy(gp);mt['semantic']['structural_template']['declared_target_model_by_world']={'w0':'X','w1':'X'};validate_bundle_shape(mt);_,ct=compile_bundle(mt);ck('target-model-noninterference',ct['derived_output_digest']==c0['derived_output_digest'])
ir=copy.deepcopy(gp);ir['semantic']['derivation']['world_records'][0]['coordinates']['irrelevant']={'x':[1,2]};ir['semantic']['derivation']['world_records'][1]['coordinates']['irrelevant']={'x':[9,8]};validate_bundle_shape(ir);_,ci=compile_bundle(ir);ck('unused-world-coordinate-noninterference',ci['derived_output_digest']==c0['derived_output_digest'] and ci['sanitized_input_digest']!=c0['sanitized_input_digest'])
uc=copy.deepcopy(gp);uc['semantic']['derivation']['profile_constants']['unused']='changed';validate_bundle_shape(uc);_,cu=compile_bundle(uc);ck('unused-profile-constant-noninterference',cu['derived_output_digest']==c0['derived_output_digest'])
payload,audit=build_compiler_payload(gh);keys=json.dumps(payload,sort_keys=True);ck('firewall-no-source-consequence-table','source_by_world' not in keys and 'consequence_by_world' not in keys);ck('firewall-no-target-model','declared_target_model_by_world' not in keys and 'target_model_by_world' not in keys);ck('firewall-no-predeclared-semantic-tables','signature_by_world' not in keys and 'operative_signature_by_world' not in keys and 'mechanism_consequence_by_world' not in keys);ck('firewall-stdin-no-bundle-path',audit['transport']=='CANONICAL_JSON_STDIN_ONLY' and not audit['bundle_path_exposed_to_compiler'] and not audit['os_level_sandbox'])
# 3. Injection/stage-boundary failures.
def inject_d():
 b=copy.deepcopy(gp);b['semantic']['structural_template']['discriminator']['signature_by_world']={'w0':'a','w1':'b'};validate_bundle_shape(b)
rejects('reject-predeclared-discriminator-table',inject_d,'may not predeclare')
def inject_exact():
 b=copy.deepcopy(gp);b['semantic']['exact_profile']={};validate_bundle_shape(b)
rejects('reject-v05-exact-profile-injection',inject_exact,'unknown v0.5 semantic keys')
def forbidden_payload_key():
 b=copy.deepcopy(gp);b['semantic']['derivation']['profile_constants']['source_by_world']={'w0':'ALLOW'};validate_bundle_shape(b);compile_bundle(b)
rejects('reject-firewall-key-smuggling',forbidden_payload_key,'firewall violation')
def world_id_coord():
 b=copy.deepcopy(gp);b['semantic']['derivation']['world_records'][0]['coordinates']['id']='w0';validate_bundle_shape(b)
rejects('reject-world-id-coordinate',world_id_coord,'reserved key id')
def mech_reads_world():
 b=copy.deepcopy(gp);b['semantic']['derivation']['program']['mechanism']['expr']={'op':'get','source':'world','path':['z']};validate_bundle_shape(b);compile_bundle(b)
rejects('reject-mechanism-world-read',mech_reads_world,'not permitted')
def interp_reads_z():
 b=copy.deepcopy(gp);b['semantic']['derivation']['program']['interpreter']['expr']={'op':'get','source':'z','path':[]};validate_bundle_shape(b);compile_bundle(b)
rejects('reject-interpreter-z-read',interp_reads_z,'not permitted')
def disc_reads_native():
 b=copy.deepcopy(gp);b['semantic']['derivation']['program']['discriminator']['expr']={'op':'get','source':'native','path':[]};validate_bundle_shape(b);compile_bundle(b)
rejects('reject-discriminator-native-read',disc_reads_native,'not permitted')
# 4. Fact/evidence provenance for compiled stages.
def unresolved_fact():
 b=copy.deepcopy(gh);next(f for f in b['semantic']['derivation']['facts'] if f['id']=='GH_HEAD_IDENTITY_AVAILABLE')['status']='UNRESOLVED';validate_bundle_shape(b)
rejects('reject-required-fact-unresolved',unresolved_fact,'requires fact')
def missing_fact_node():
 b=copy.deepcopy(gh);next(f for f in b['semantic']['derivation']['facts'] if f['id']=='GH_HEAD_IDENTITY_AVAILABLE').pop('provenance_node');validate_bundle_shape(b)
rejects('reject-required-fact-no-provenance-node',missing_fact_node,'missing provenance_node')
def wrong_fact_node_kind():
 b=copy.deepcopy(gh);next(f for f in b['semantic']['derivation']['facts'] if f['id']=='GH_HEAD_IDENTITY_AVAILABLE')['provenance_node']='CLAIM-D';validate_bundle_shape(b)
rejects('reject-fact-node-wrong-kind',wrong_fact_node_kind,'must be FACT')
def fact_not_upstream_d():
 b=copy.deepcopy(gh);b['provenance']['edges']=[e for e in b['provenance']['edges'] if not (e['from']=='FACT-GH-HEAD' and e['to']=='DERIVE-GH-D')];validate_bundle_shape(b)
rejects('reject-compiler-fact-not-upstream-D',fact_not_upstream_d)
def fact_not_upstream_exact():
 b=copy.deepcopy(gh);b['provenance']['edges']=[e for e in b['provenance']['edges'] if not (e['from']=='FACT-GH-HEAD' and e['to']=='DERIVE-GH-EXACT')];validate_bundle_shape(b)
rejects('reject-shared-compiler-fact-not-upstream-EXACT',fact_not_upstream_exact,'not upstream of the EXACT claim')
def fact_no_evidence():
 b=copy.deepcopy(gh);b['provenance']['edges']=[e for e in b['provenance']['edges'] if e['to']!='FACT-GH-HEAD'];validate_bundle_shape(b)
rejects('reject-fact-without-required-evidence',fact_no_evidence,'no upstream required evidence')
def bad_establish_edge():
 b=copy.deepcopy(gh);b['provenance']['edges'].append({'from':'DECL-BOUNDARY','to':'FACT-GH-HEAD','relation':'ESTABLISHES'});validate_bundle_shape(b)
rejects('reject-ESTABLISHES-edge-type',bad_establish_edge,'invalid provenance edge typing')
def bad_uses_edge():
 b=copy.deepcopy(gh);b['provenance']['edges'].append({'from':'N-B-GH_MERGE','to':'DERIVE-GH-D','relation':'USES'});validate_bundle_shape(b)
rejects('reject-USES-edge-type',bad_uses_edge,'invalid provenance edge typing')
# 5. Compiler conformance and implementation diversity.
def run_comp(cmd):
 cp=subprocess.run([sys.executable,str(ROOT/'compiler/runner/conformance_runner.py'),'--testee-cmd',cmd],capture_output=True,text=True,timeout=60);return cp.returncode,cp.stdout.strip()
rc,out=run_comp(f'{sys.executable} {ROOT/"compiler/implementations/reference_compiler.py"}');ck('compiler-python-conformance-15',rc==0 and '"passed": 15' in out,out)
rc,out=run_comp(f'node {ROOT/"compiler/implementations/node_compiler.js"}');ck('compiler-node-conformance-15',rc==0 and '"passed": 15' in out,out)
# Full accepted result differential across all vectors using persistent JSONL processes.
vectors=[json.loads(p.read_text()) for p in sorted((ROOT/'compiler/vectors').glob('C*.json'))]
def stream_all(cmd):
 pr=subprocess.Popen(cmd+['--jsonl'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,bufsize=1);out=[]
 try:
  for v in vectors:
   pr.stdin.write(json.dumps(v['payload'],separators=(',',':'))+'\n');pr.stdin.flush();out.append(json.loads(pr.stdout.readline()))
 finally:pr.stdin.close();pr.wait(timeout=10)
 return out
po=stream_all([sys.executable,str(ROOT/'compiler/implementations/reference_compiler.py')]);no=stream_all(['node',str(ROOT/'compiler/implementations/node_compiler.js')]);diffs=[];reject_parity=[]
for v,a,n in zip(vectors,po,no):
 if bool(a.get('ok'))!=bool(n.get('ok')):reject_parity.append(v['id'])
 if v['accept'] and a.get('result')!=n.get('result'):diffs.append(v['id'])
ck('compiler-accept-reject-dual-runtime-parity',not reject_parity,','.join(reject_parity))
ck('compiler-full-result-dual-runtime-accepted-vectors',not diffs,','.join(diffs))
active=(ROOT/'compiler/implementations/reference_compiler.py').read_text().lower()+(ROOT/'compiler/implementations/node_compiler.js').read_text().lower();ck('compiler-vendor-neutral',not any(x in active for x in ['github','azure','paypal']))
py=(ROOT/'compiler/implementations/reference_compiler.py').read_text();js=(ROOT/'compiler/implementations/node_compiler.js').read_text();ck('compiler-no-filesystem-semantic-input',all(x not in py for x in ['pathlib','open(','subprocess','os.environ']) and all(x not in js for x in ["require('fs')",'require("fs")','process.cwd']))
# 6. Functional mechanism construction.
_,cstatic=compile_bundle(gst);fib=cstatic['mechanism_fibers'];ck('same-z-single-mechanism-fiber',len(fib)==1 and len(fib[0]['worlds'])==3)
ck('mechanism-function-by-construction',len({json.dumps(f['native_outcome'],sort_keys=True) for f in fib})==1 and len({json.dumps(f['mechanism_consequence'],sort_keys=True) for f in fib})==1)
# 7. Certificate recompiles and binds compilation state.
cert=build_certificate(gh,ghroot);vr=verify_certificate(cert,ghroot);ck('certificate-full-root-pass',vr['status']=='PASS' and vr['failed']==0)
vr0=verify_certificate(cert,None);ck('certificate-no-root-partial',vr0['status']=='PARTIAL' and vr0['evidence_recheck_status']=='NOT_RECHECKED')
t=copy.deepcopy(cert);t['proof']['blind_compilation']['firewall']['source_consequence_table_exposed_to_compiler']=True;ck('tamper-certificate-firewall',verify_certificate(t,ghroot)['status']=='FAIL')
t=copy.deepcopy(cert);t['proof']['blind_compilation']['derived']['discriminator_signature_by_world']['H1']='H0';ck('tamper-certificate-derived-output',verify_certificate(t,ghroot)['status']=='FAIL')
t=copy.deepcopy(cert);t['proof']['blind_compilation']['stage_input_footprint']['discriminator']=[];ck('tamper-certificate-stage-footprint',verify_certificate(t,ghroot)['status']=='FAIL')
t=copy.deepcopy(cert);t['bundle_snapshot']['semantic']['derivation']['program']['discriminator']['expr']={'op':'literal','value':'same'};ck('tamper-certificate-derivation-program',verify_certificate(t,ghroot)['status']=='FAIL')
t=copy.deepcopy(cert);t['bundle_snapshot']['semantic']['structural_template']['consequence']['source_by_world']['H1']='MERGED_REVIEWED_HEAD';ck('tamper-certificate-K',verify_certificate(t,ghroot)['status']=='FAIL')
t=copy.deepcopy(cert);t['results']['structural']['D']='D0';ck('tamper-certificate-result',verify_certificate(t,ghroot)['status']=='FAIL')
t=copy.deepcopy(cert);t['verifier_boundary']['blind_compilation_is_input_independence_not_authorship_independence']=False;ck('tamper-verifier-boundary',verify_certificate(t,ghroot)['status']=='FAIL')
# Issuance without evidence root must fail.
rejects('evidence-linked-certificate-no-root-refused',lambda:build_certificate(gh,None),'successful byte recheck')
# Evidence tamper remains fail closed.
with tempfile.TemporaryDirectory() as td:
 td=Path(td);shutil.copytree(ghroot,td/'b');bb=json.loads((td/'b/bundle.json').read_text());bp=td/'b'/bb['bindings'][0]['path'];bp.write_bytes(bp.read_bytes()+b'X');rr=evaluate_bundle(bb,td/'b');ck('evidence-byte-tamper-fails',rr['verification_status']=='FAIL' and rr['evidence_verification_status']=='FAIL');ck('certificate-evidence-tamper-fails',verify_certificate(cert,td/'b')['status']=='FAIL')
# 8. Semantic metamorphics.
wr=copy.deepcopy(gp);wr['semantic']['structural_template']['boundary']['worlds']=['left','right'];wr['semantic']['structural_template']['consequence']['source_by_world']={'left':'ALLOW','right':'BLOCK'};wr['semantic']['derivation']['world_records'][0]['id']='left';wr['semantic']['derivation']['world_records'][1]['id']='right';validate_bundle_shape(wr);rw=evaluate_bundle(wr,gproot);ck('metamorphic-world-renaming',rw['structural']['D']==rgp['structural']['D'] and rw['exact_realization']['status']==rgp['exact_realization']['status'])
wo=copy.deepcopy(gp);wo['semantic']['structural_template']['boundary']['worlds']=['w1','w0'];wo['semantic']['derivation']['world_records']=[wo['semantic']['derivation']['world_records'][1],wo['semantic']['derivation']['world_records'][0]];validate_bundle_shape(wo);ro=evaluate_bundle(wo,gproot);ck('metamorphic-world-order',ro['structural']['D']==rgp['structural']['D'] and ro['exact_realization']['status']==rgp['exact_realization']['status'])
# 9. Fixed verifier claim boundary cannot be upgraded by author text.
ub=copy.deepcopy(gp);ub['claim_boundary']['independent_reproduction']='ESTABLISHED_BY_AUTHOR';ru=evaluate_bundle(ub,gproot);ck('user-boundary-cannot-upgrade',ru['verifier_boundary']==VERIFIER_BOUNDARY and ru['verifier_boundary']['independent_reproduction']=='NOT_ESTABLISHED_BY_VERIFIER')
# 10. Legacy v0.4 bundle still verifies as declared semantics, not blind compiled.
parent=ROOT/'provenance/parent/Consequence_Preserving_Projections_Software_v0.4.1.zip'
with tempfile.TemporaryDirectory() as td:
 subprocess.run(['unzip','-q',str(parent),'-d',td],check=True);base=next(Path(td).glob('consequence-preserving-projections-0.4.1'));lb=json.loads((base/'bundles/examples/generic-preserved/bundle.json').read_text());lr=evaluate_bundle(lb,base/'bundles/examples/generic-preserved');ck('legacy-v04-supported-but-not-blind',lr['bundle_version']=='0.4' and lr['compilation']['status']=='NOT_APPLICABLE' and lr['semantic_assurance_class'].startswith('DECLARED_SEMANTICS'))
# 11. Active compiler/verifier code has no vendor branches.
needle=['github','azure','paypal'];files=list((ROOT/'verifier').glob('*.py'))+[ROOT/'cli/risu_projection.py',ROOT/'compiler/implementations/reference_compiler.py',ROOT/'compiler/implementations/node_compiler.js'];hits=[]
for f in files:
 s=f.read_text().lower()
 for n in needle:
  if n in s:hits.append(f'{f.relative_to(ROOT)}:{n}')
ck('carrier-neutral-active-core-scan',not hits,','.join(hits))
report={'gate':'PROJECTION_ASSURANCE_V0.5.0_CONSEQUENCE_BLIND_COMPILATION_GATE','status':'PASS' if all(x['status']=='PASS' for x in checks) else 'FAIL','checks':checks,'passed':sum(x['status']=='PASS' for x in checks),'total':len(checks),'nonclaim':'The gate establishes deterministic input separation, compiler-stage restrictions, dual-runtime agreement, provenance/evidence integrity behavior, and model-relative semantic recomputation on the retained finite profiles. It does not establish authorship independence, adequacy of the world model or evidence interpretation, live-runtime conformance, or independent reproduction.'}
out=ROOT/'results/V0.5.0_CONSEQUENCE_BLIND_COMPILATION_GATE.json';out.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');print(json.dumps({'status':report['status'],'passed':report['passed'],'total':report['total']}));raise SystemExit(0 if report['status']=='PASS' else 2)

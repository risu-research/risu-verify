#!/usr/bin/env python3
from pathlib import Path
import sys,json,copy,tempfile,subprocess,shutil,os
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from verifier.bundle import load_bundle,validate_bundle_shape,verify_bindings
from verifier.engine import evaluate_bundle,VERIFIER_BOUNDARY
from verifier.certificate import build_certificate,verify_certificate
from verifier.common import canonical_bytes
sys.path.insert(0,str(ROOT/'kernel/implementations'));sys.path.insert(0,str(ROOT/'exact/implementations'))
from reference_analyzer import evaluate as structural
from reference_exact import evaluate as exact
checks=[]
def ck(name,cond,detail=''):
    checks.append({'check':name,'status':'PASS' if cond else 'FAIL','detail':detail})
    if not cond: raise AssertionError(f'{name}: {detail}')
def rejects(name,fn):
    try:fn();ok=False;detail='accepted malformed input'
    except Exception as e:ok=True;detail=str(e)
    ck(name,ok,detail)
def core(x):return {k:x[k] for k in ['C','D','O','structural_classification','precision','coverage_complete']}
# 1. Generic bundles remain first-class and cross-axis semantics are unchanged.
expect={'GENERIC-PRESERVED':('D1','REALIZATION_ESTABLISHED'),'GENERIC-D0-EXACT-ESTABLISHED':('D0','REALIZATION_ESTABLISHED'),'GENERIC-D1-MECHANISM-MISALIGNED':('D1','REALIZATION_CONTRADICTED'),'GENERIC-OPERATIVE-INSUFFICIENT':('D1','REALIZATION_CONTRADICTED')}
for p in sorted((ROOT/'bundles/examples').glob('*/bundle.json')):
    b,_,r=load_bundle(p);out=evaluate_bundle(b,r);ck('generic:'+b['bundle_id'],out['verification_status']=='PASS' and out['evidence_verification_status']=='NOT_APPLICABLE_DECLARED_ONLY' and (out['structural']['D'],out['exact_realization']['status'])==expect[b['bundle_id']])
# 2. Canonical evidence-linked bundles must have claim-specific evidence and pass byte recheck.
canonical={}
for vendor in ['github','azure']:
    b,p,r=load_bundle(ROOT/f'bundles/canonical/{vendor}');out=evaluate_bundle(b,r);canonical[vendor]=(b,r,out)
    ck('canonical-bundle:'+vendor,out['verification_status']=='PASS' and out['evidence_verification_status']=='PASS' and all(x['evidence_integrity']=='PASS' for x in out['claim_assurance'].values()))
    cert=build_certificate(b,r);vr=verify_certificate(cert,r);ck('canonical-certificate-full:'+vendor,vr['status']=='PASS' and vr['evidence_recheck_status']=='PASS',str(vr))
    partial=verify_certificate(cert);ck('canonical-certificate-no-root-partial:'+vendor,partial['status']=='PARTIAL' and partial['model_recompute_status']=='PASS' and partial['evidence_recheck_status']=='NOT_RECHECKED',str(partial))
# 3. EVIDENCE_LINKED bundles cannot silently degrade to an evidence-bound PASS.
gb,_,gr=load_bundle(ROOT/'bundles/examples/generic-preserved');gh,ghroot,_=canonical['github']
partial=evaluate_bundle(gh,None,check_bindings=False);ck('bundle-no-binding-recheck-is-partial',partial['verification_status']=='PARTIAL' and partial['model_verification_status']=='PASS' and partial['evidence_verification_status']=='NOT_RECHECKED')
rejects('certificate-build-refuses-unchecked-evidence',lambda:build_certificate(gh,None))
# Declared-only certificates need no evidence root and remain full model-relative certificates.
gcert=build_certificate(gb,gr);gvr=verify_certificate(gcert);ck('declared-only-certificate-no-root-pass',gvr['status']=='PASS' and gvr['evidence_recheck_status']=='NOT_APPLICABLE',str(gvr))
# 4. Reproduce the previously possible disconnected-evidence labeling attack; it must fail closed.
def disconnected_attack():
    b=copy.deepcopy(gb);b['provenance']['mode']='EVIDENCE_LINKED';b['bindings']=[{'id':'DECORATION','kind':'EVIDENCE','path':'decorative.txt','sha256':'0'*64,'required':True}];b['provenance']['nodes'].append({'id':'evidence-decoration','kind':'EVIDENCE','binding_ids':['DECORATION']});validate_bundle_shape(b)
rejects('trust-boundary-disconnected-evidence',disconnected_attack)
# A claim root must be a CLAIM node.
def bad_root_kind():
    b=copy.deepcopy(gb);b['provenance']['claim_roots']['C']=['decl'];validate_bundle_shape(b)
rejects('trust-boundary-root-kind',bad_root_kind)
# Every claim root in EVIDENCE_LINKED mode must independently reach required epistemic evidence.
def one_root_unbacked():
    b=copy.deepcopy(gh);b['provenance']['nodes'].append({'id':'CLAIM-C-2','kind':'CLAIM','label':'unbacked parallel C root'});b['provenance']['claim_roots']['C'].append('CLAIM-C-2');b['provenance']['edges'].append({'from':'DECL-BOUNDARY','to':'CLAIM-C-2','relation':'DERIVES'});validate_bundle_shape(b)
rejects('trust-boundary-each-root-needs-evidence',one_root_unbacked)
# Optional evidence alone cannot support an EVIDENCE_LINKED claim.
def optional_only():
    b=copy.deepcopy(gb);b['provenance']['mode']='EVIDENCE_LINKED';b['bindings']=[{'id':'OPT','kind':'EVIDENCE','path':'x','sha256':'0'*64,'required':False}];b['provenance']['nodes'].append({'id':'ev','kind':'EVIDENCE','binding_ids':['OPT']})
    for claim,rs in b['provenance']['claim_roots'].items():b['provenance']['edges'].append({'from':'ev','to':rs[0],'relation':'SUPPORTS'})
    validate_bundle_shape(b)
rejects('trust-boundary-optional-only-not-evidence',optional_only)
# AUXILIARY bytes are never sufficient epistemic support.
def auxiliary_only():
    b=copy.deepcopy(gb);b['provenance']['mode']='EVIDENCE_LINKED';b['bindings']=[{'id':'AUX','kind':'AUXILIARY','path':'x','sha256':'0'*64,'required':True}];b['provenance']['nodes'].append({'id':'ev','kind':'EVIDENCE','binding_ids':['AUX']});validate_bundle_shape(b)
rejects('trust-boundary-auxiliary-not-epistemic',auxiliary_only)
# Required epistemic bindings cannot float outside the claim DAG.
def unused_required_binding():
    b=copy.deepcopy(gh);b['bindings'].append({'id':'UNUSED','kind':'SOURCE','path':'unused','sha256':'0'*64,'required':True});validate_bundle_shape(b)
rejects('trust-boundary-unused-required-binding',unused_required_binding)
# Evidence nodes cannot be decorative/dangling.
def dangling_evidence_node():
    b=copy.deepcopy(gh);bid=gh['bindings'][0]['id'];b['provenance']['nodes'].append({'id':'dangling-evidence','kind':'EVIDENCE','binding_ids':[bid]});validate_bundle_shape(b)
rejects('trust-boundary-dangling-evidence-node',dangling_evidence_node)
# Only EVIDENCE nodes can bind files.
def claim_carries_binding():
    b=copy.deepcopy(gh);bid=gh['bindings'][0]['id'];next(n for n in b['provenance']['nodes'] if n['id']=='CLAIM-C')['binding_ids']=[bid];validate_bundle_shape(b)
rejects('trust-boundary-non-evidence-binding-node',claim_carries_binding)
# Edge types are checked, not just relation spelling.
def invalid_edge_typing():
    b=copy.deepcopy(gh);b['provenance']['edges'].append({'from':'CLAIM-C','to':'CLAIM-D','relation':'SUPPORTS'});validate_bundle_shape(b)
rejects('trust-boundary-edge-type',invalid_edge_typing)
# Unrooted CLAIM nodes are rejected.
def unrooted_claim():
    b=copy.deepcopy(gb);b['provenance']['nodes'].append({'id':'orphan-claim','kind':'CLAIM'});validate_bundle_shape(b)
rejects('trust-boundary-unrooted-claim',unrooted_claim)
# A single CLAIM node cannot impersonate multiple assurance axes.
def reused_claim_root():
    b=copy.deepcopy(gb);b['provenance']['claim_roots']['D']=['c'];b['provenance']['nodes']=[n for n in b['provenance']['nodes'] if n['id']!='d'];b['provenance']['edges']=[e for e in b['provenance']['edges'] if e['to']!='d'];validate_bundle_shape(b)
rejects('trust-boundary-claim-root-not-reusable',reused_claim_root)
# DECLARED_ONLY is semantically clean: epistemic bindings require EVIDENCE_LINKED mode.
def declared_only_with_epistemic_binding():
    b=copy.deepcopy(gb);b['bindings']=[{'id':'E','kind':'SOURCE','path':'x','sha256':'0'*64,'required':True}];validate_bundle_shape(b)
rejects('trust-boundary-declared-only-no-epistemic-bindings',declared_only_with_epistemic_binding)
# Even optional epistemic bindings must participate in an evidence node rather than float as decorative metadata.
def unused_optional_epistemic_binding():
    b=copy.deepcopy(gh);b['bindings'].append({'id':'OPT-UNUSED','kind':'EVIDENCE','path':'unused','sha256':'0'*64,'required':False});validate_bundle_shape(b)
rejects('trust-boundary-unused-optional-epistemic-binding',unused_optional_epistemic_binding)
# 5. Certificate trust state is explicit and tamper-resistant.
cert=build_certificate(gh,ghroot)
t=copy.deepcopy(cert);t['results']['structural']['D']='D0';ck('tamper-certificate-result',verify_certificate(t,ghroot)['status']=='FAIL')
t=copy.deepcopy(cert);t['bundle_snapshot']['semantic']['structural_profile']['discriminator']['signature_by_world']['H1']='H0';ck('tamper-certificate-input',verify_certificate(t,ghroot)['status']=='FAIL')
t=copy.deepcopy(cert);t['verifier_boundary']['live_runtime_conformance']='ESTABLISHED';ck('tamper-verifier-boundary',verify_certificate(t,ghroot)['status']=='FAIL')
t=copy.deepcopy(cert);t['claim_provenance']['C']['required_epistemic_binding_ids']=[];ck('tamper-claim-provenance',verify_certificate(t,ghroot)['status']=='FAIL')
t=copy.deepcopy(cert);t['claim_assurance_at_issuance']['C']['evidence_integrity']='NOT_RECHECKED';ck('tamper-issuance-evidence-status',verify_certificate(t,ghroot)['status']=='FAIL')
# User claim-boundary prose can never upgrade fixed verifier boundary.
tb=copy.deepcopy(gb);tb['claim_boundary']['independent_reproduction']='ESTABLISHED_BY_USER';out=evaluate_bundle(tb,gr);ck('user-boundary-cannot-upgrade-verifier-boundary',out['verifier_boundary']==VERIFIER_BOUNDARY and out['verifier_boundary']['independent_reproduction']=='NOT_ESTABLISHED_BY_VERIFIER')
# 6. Byte-integrity failures remain fail-closed, including symlink escape.
tb=copy.deepcopy(gh);tb['bindings'][0]['path']='../../outside';vr=verify_bindings(tb,ghroot);ck('binding-path-traversal-fail-closed',vr['status']=='FAIL')
with tempfile.TemporaryDirectory() as td:
    td=Path(td);shutil.copytree(ghroot,td/'b');x=json.loads((td/'b/bundle.json').read_text());p=td/'b'/x['bindings'][0]['path'];p.write_bytes(p.read_bytes()+b'X');ck('binding-byte-tamper',verify_bindings(x,td/'b')['status']=='FAIL')
    cert=build_certificate(gh,ghroot);ck('certificate-evidence-tamper-fails',verify_certificate(cert,td/'b')['status']=='FAIL')
with tempfile.TemporaryDirectory() as td:
    td=Path(td);(td/'b').mkdir();outside=td/'outside';outside.write_text('x');os.symlink(outside,td/'b/link');x=copy.deepcopy(gb);x['bindings']=[{'id':'E','kind':'EVIDENCE','path':'link','sha256':'0'*64,'required':True}];ck('binding-symlink-escape-fail-closed',verify_bindings(x,td/'b')['status']=='FAIL')
# 7. Orthogonality metamorphics remain unchanged by trust hardening.
sp=gb['semantic']['structural_profile'];ep=gb['semantic']['exact_profile'];baseS=structural(sp);baseE=exact(ep)
m=copy.deepcopy(sp);m['declared_target_model_by_world']={'w0':'X','w1':'X'};ms=structural(m);ck('noninterference-target-model',all(ms[k]==baseS[k] for k in ['C','D','O','structural_classification','precision','coverage_complete']))
om=copy.deepcopy(sp);om['discharge']['gates_effect']=False;ck('noninterference-O-vs-exact',exact(ep)==baseE and structural(om)['O']=='O0')
dm=copy.deepcopy(sp);dm['discriminator']['signature_by_world']={'w0':'same','w1':'same'};ck('noninterference-D-vs-exact',structural(dm)['D']=='D0' and exact(ep)==baseE)
zm=copy.deepcopy(ep);zm['operative_signature_by_world']={'w0':'same','w1':'same'};ze=exact(zm);ck('direction-z-collapse',ze['failure_mode']=='OPERATIVE_INSUFFICIENCY' and structural(sp)==baseS)
am=copy.deepcopy(ep);am['mechanism_consequence_by_world']['w1']={'space':'C','label':'ALLOW'};ae=exact(am);ck('direction-alpha-misalignment',ae['z_sufficient'] and ae['failure_mode']=='MECHANISM_MISALIGNMENT')
ren={'w0':'left','w1':'right'};rs=copy.deepcopy(sp);rs['boundary']['worlds']=[ren[w] for w in sp['boundary']['worlds']];rs['consequence']['source_by_world']={ren[k]:v for k,v in sp['consequence']['source_by_world'].items()};rs['discriminator']['signature_by_world']={ren[k]:v for k,v in sp['discriminator']['signature_by_world'].items()};ck('metamorphic-world-renaming',core(structural(rs))==core(baseS))
obj=copy.deepcopy(sp);obj['discriminator']['signature_by_world']={'w0':{'a':1,'b':2},'w1':{'b':3,'a':1}};obj2=copy.deepcopy(obj);obj2['discriminator']['signature_by_world']={'w0':{'b':2,'a':1},'w1':{'a':1,'b':3}};ck('metamorphic-object-key-order',core(structural(obj))==core(structural(obj2)))
# Provenance cycle remains rejected.
tb=copy.deepcopy(gb);tb['provenance']['edges'].append({'from':'c','to':'decl','relation':'DERIVES'});rejects('provenance-cycle-fail-closed',lambda:validate_bundle_shape(tb))
# 8. Runtime core stays carrier-neutral.
needle=['github','azure','paypal'];files=list((ROOT/'verifier').glob('*.py'))+[ROOT/'cli/risu_projection.py'];hits=[]
for f in files:
    s=f.read_text().lower()
    for n in needle:
        if n in s:hits.append(f'{f.relative_to(ROOT)}:{n}')
ck('carrier-neutral-core-scan',not hits,','.join(hits))
# 9. Full Python/Node semantic differential remains intact.
def stream(cmd,protocol,profiles):
    pr=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True);out=[]
    try:
        for i,p in enumerate(profiles):pr.stdin.write(json.dumps({'protocol':protocol,'request_id':str(i),'profile':p},separators=(',',':'))+'\n');pr.stdin.flush();out.append(json.loads(pr.stdout.readline()))
    finally:pr.stdin.close();pr.terminate();pr.wait(timeout=5)
    return out
sv=[json.loads(p.read_text()) for p in sorted((ROOT/'kernel/vectors').glob('V*.json'))];pv=stream([sys.executable,str(ROOT/'kernel/implementations/reference_analyzer.py')],'risu-projection-conformance/0.4',sv);nv=stream(['node',str(ROOT/'kernel/implementations/node_analyzer.js')],'risu-projection-conformance/0.4',sv);ck('structural-full-dual-runtime',all(a['result']==b['result'] for a,b in zip(pv,nv)))
ev=[json.loads(p.read_text()) for p in sorted((ROOT/'exact/vectors').glob('E*.json'))];pe=stream([sys.executable,str(ROOT/'exact/implementations/reference_exact.py')],'risu-projection-exact/0.4',ev);ne=stream(['node',str(ROOT/'exact/implementations/node_exact.js')],'risu-projection-exact/0.4',ev);ck('exact-full-dual-runtime',all(a['result']==b['result'] for a,b in zip(pe,ne)))
report={'gate':'PROJECTION_ASSURANCE_V0.4.1_TRUST_BOUNDARY_GATE','status':'PASS' if all(x['status']=='PASS' for x in checks) else 'FAIL','checks':checks,'passed':sum(x['status']=='PASS' for x in checks),'total':len(checks)}
out=ROOT/'results/V0.4.1_TRUST_BOUNDARY_GATE.json';out.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');print(json.dumps({'status':report['status'],'passed':report['passed'],'total':report['total']}));raise SystemExit(0 if report['status']=='PASS' else 2)

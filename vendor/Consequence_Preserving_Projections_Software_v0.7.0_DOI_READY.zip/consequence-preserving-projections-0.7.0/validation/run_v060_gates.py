#!/usr/bin/env python3
from pathlib import Path
import ast,copy,hashlib,json,os,shutil,subprocess,sys,tempfile
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from verifier.bundle import load_bundle
from verifier.certificate import build_certificate,verify_certificate
from verifier.common import canonical_bytes,digest_obj,sha256_file

CHECKER=ROOT/'checker/risu_pcc_check.py'
checks=[]
def ck(n,c,d=''):checks.append({'check':n,'status':'PASS' if c else 'FAIL','detail':d})
def run_checker(cert,root=None,isolated=False):
    with tempfile.TemporaryDirectory() as td:
        td=Path(td);cp=td/'cert.json';cp.write_bytes(canonical_bytes(cert)+b'\n')
        exe=CHECKER
        if isolated:
            exe=td/'pcc.py';shutil.copy2(CHECKER,exe)
        cmd=[sys.executable,str(exe),str(cp),'--json']
        if root is not None:cmd += ['--root',str(root)]
        p=subprocess.run(cmd,capture_output=True,text=True,timeout=30,cwd=td if isolated else ROOT)
        try:o=json.loads(p.stdout)
        except Exception:o={'status':'PARSE_FAIL','stdout':p.stdout,'stderr':p.stderr}
        return p.returncode,o

def cert_for(rel):
    b,p,r=load_bundle(ROOT/rel);return b,r,build_certificate(b,r)

# 1. Reference checker is intentionally standalone and small.
src=CHECKER.read_text();tree=ast.parse(src);imports=[]
for n in ast.walk(tree):
    if isinstance(n,ast.Import):imports += [a.name.split('.')[0] for a in n.names]
    elif isinstance(n,ast.ImportFrom):imports.append((n.module or '').split('.')[0])
allowed={'argparse','hashlib','json','math','os','sys','pathlib'}
ck('tcb-stdlib-imports-only',set(imports)<=allowed,','.join(sorted(set(imports)-allowed)))
ck('tcb-no-project-imports',not any(x in src for x in ['from verifier','import verifier','from compiler','import compiler','from kernel','import kernel','from exact','import exact','sys.path.insert']))
ck('tcb-no-subprocess-or-dynamic-exec',all(x not in src for x in ['subprocess','eval(','exec(','__import__']))
ck('tcb-single-reference-file',CHECKER.is_file())
lines=len(src.splitlines());ck('tcb-reference-checker-under-400-lines',lines<400,str(lines))
ck('tcb-carrier-neutral',not any(x in src.lower() for x in ['github','azure','paypal']))
ck('tcb-executable',bool(CHECKER.stat().st_mode & 0o100))

# 2. Every retained v0.5 bundle gets a v0.6 proof-carrying certificate accepted by both paths.
bundles=[
 'bundles/canonical/github/bundle.json','bundles/canonical/azure/bundle.json',
 'bundles/examples/generic-preserved/bundle.json','bundles/examples/generic-d0-exact-established/bundle.json',
 'bundles/examples/generic-d1-mechanism-misaligned/bundle.json','bundles/examples/generic-operative-insufficient/bundle.json',
 'bundles/examples/logical-operation-static-token/bundle.json']
certs={}
for rel in bundles:
    b,p,root=load_bundle(ROOT/rel);c=build_certificate(b,root);certs[rel]=(b,root,c)
    m=verify_certificate(c,root);rc,q=run_checker(c,root)
    name=Path(rel).parent.name
    ck('certificate-v06-main:'+name,m['status']=='PASS' and m['failed']==0)
    ck('certificate-v06-pcc:'+name,rc==0 and q['status']=='PASS' and q['failed']==0,str(q.get('checks',[])[-1:] if q else ''))
    ck('certificate-proof-digest:'+name,c['proof_digest']==c['proof']['proof_digest'])

# 3. Checker is independently runnable with no RISU package tree present.
_,groot,gcert=certs['bundles/examples/generic-preserved/bundle.json'];rc,q=run_checker(gcert,None,isolated=True);ck('isolated-standalone-declared-only',rc==0 and q['status']=='PASS')
_,ghroot,ghcert=certs['bundles/canonical/github/bundle.json'];rc,q=run_checker(ghcert,ghroot,isolated=True);ck('isolated-standalone-evidence-linked',rc==0 and q['status']=='PASS')
# no-root evidence certificate is explicitly partial, never full PASS
rc,q=run_checker(ghcert,None,isolated=True);ck('isolated-no-root-partial',rc==4 and q['status']=='PARTIAL' and q['evidence_status']=='NOT_RECHECKED')

# 4. Proof/result/certificate tampering fails, including attacks that recompute the outer proof digest.
def mutate(name,fn,root=ghroot):
    t=copy.deepcopy(ghcert);fn(t);rc,q=run_checker(t,root);ck(name,rc==2 and q['status']=='FAIL',str(q.get('checks',[])[-2:]))
mutate('reject-proof-d-status',lambda t:t['proof']['structural']['D'].__setitem__('status','D0'))
def proof_status_rehash(t):
    t['proof']['structural']['D']['status']='D0';p={k:v for k,v in t['proof'].items() if k!='proof_digest'};t['proof']['proof_digest']=digest_obj(p);t['proof_digest']=t['proof']['proof_digest']
mutate('reject-proof-d-status-even-rehashed',proof_status_rehash)
def derived_rehash(t):
    t['proof']['blind_compilation']['derived']['discriminator_signature_by_world']['H1']='H0';p={k:v for k,v in t['proof'].items() if k!='proof_digest'};t['proof']['proof_digest']=digest_obj(p);t['proof_digest']=t['proof']['proof_digest']
mutate('reject-compiled-derived-forgery-even-rehashed',derived_rehash)
def result_forge(t):
    t['results']['structural']['D']='D0';t['proof']['verdict_commitment']['structural']['D']='D0';p={k:v for k,v in t['proof'].items() if k!='proof_digest'};t['proof']['proof_digest']=digest_obj(p);t['proof_digest']=t['proof']['proof_digest']
mutate('reject-result-and-commitment-forgery',result_forge)
mutate('reject-proof-digest',lambda t:t.__setitem__('proof_digest','0'*64))
mutate('reject-checker-boundary',lambda t:t['proof_checker_boundary'].__setitem__('world_model_adequacy','ESTABLISHED'))
mutate('reject-verifier-boundary',lambda t:t['verifier_boundary'].__setitem__('world_model_adequacy','ESTABLISHED'))
mutate('reject-unknown-certificate-field',lambda t:t.__setitem__('favorable_verdict',True))
mutate('reject-unknown-bundle-field',lambda t:t['bundle_snapshot'].__setitem__('favorable_verdict',True))
mutate('reject-claim-support-tamper',lambda t:t['proof']['claim_support']['D'].__setitem__('roots',[]))
mutate('reject-semantic-input-digest',lambda t:t['semantic_input_digests'].__setitem__('derivation','0'*64))

def bundle_k_forge(t):
    t['bundle_snapshot']['semantic']['structural_template']['consequence']['source_by_world']['H1']='MERGED_REVIEWED_HEAD';t['bundle_digest']=digest_obj(t['bundle_snapshot'])
mutate('reject-bundle-K-forgery-even-redigested',bundle_k_forge)
def program_forge(t):
    t['bundle_snapshot']['semantic']['derivation']['program']['discriminator']['expr']={'op':'literal','value':'same'};t['bundle_digest']=digest_obj(t['bundle_snapshot']);t['semantic_input_digests']['semantic']=digest_obj(t['bundle_snapshot']['semantic']);t['semantic_input_digests']['derivation']=digest_obj(t['bundle_snapshot']['semantic']['derivation'])
mutate('reject-derivation-program-forgery-even-redigested',program_forge)

# 5. Evidence mutation is caught by standalone checker.
with tempfile.TemporaryDirectory() as td:
    dst=Path(td)/'github';shutil.copytree(ghroot,dst);b=json.loads((dst/'bundle.json').read_text());target=dst/b['bindings'][0]['path'];target.write_bytes(target.read_bytes()+b'X');rc,q=run_checker(ghcert,dst,isolated=True);ck('reject-evidence-byte-tamper',rc==2 and q['status']=='FAIL')

# 6. Local proof covers the intended cross-axis geometries without collapsing verdict dimensions.
def q(rel):
    b,r,c=certs[rel];return c['proof'],c['results']
p,r=q('bundles/examples/generic-d0-exact-established/bundle.json');ck('proof-D0-exact-established',p['structural']['D']['status']=='D0' and p['exact']['status']=='REALIZATION_ESTABLISHED')
p,r=q('bundles/examples/generic-d1-mechanism-misaligned/bundle.json');ck('proof-D1-mechanism-misaligned',p['structural']['D']['status']=='D1' and p['exact']['failure_mode']=='MECHANISM_MISALIGNMENT')
p,r=q('bundles/examples/generic-operative-insufficient/bundle.json');ck('proof-operative-insufficiency-witness',p['exact']['z_sufficiency']['sufficient'] is False and p['exact']['z_sufficiency']['witness'] is not None)
p,r=q('bundles/canonical/azure/bundle.json');ck('proof-coverage-separate-from-exact',p['exact']['status']=='REALIZATION_ESTABLISHED' and p['structural']['coverage']['complete'] is False)

# 7. Main verifier and standalone checker agree on certificate result commitments for all retained bundles.
for rel,(b,root,c) in certs.items():
    rc,qc=run_checker(c,root);mv=verify_certificate(c,root);name=Path(rel).parent.name;ck('main-pcc-status-agreement:'+name,qc['status']==mv['status']=='PASS')

# 8. The proof object is auditable rather than a favorable-status token.
for rel,(b,root,c) in certs.items():
    p=c['proof'];name=Path(rel).parent.name;ck('proof-has-blind-derived:'+name,'derived' in p['blind_compilation'] and 'stage_input_footprint' in p['blind_compilation']);ck('proof-has-local-structural:'+name,all(x in p['structural'] for x in ['C','D','O','coverage']));ck('proof-has-verdict-commitment:'+name,p['verdict_commitment']==c['results'])

checker_profile={'checker':'checker/risu_pcc_check.py','sha256':sha256_file(CHECKER),'physical_lines':lines,'imports':sorted(set(imports)),'project_imports':False,'subprocess_used':False,'trust_boundary':'Python interpreter/stdlib JSON, SHA-256 and filesystem semantics plus this checker source remain trusted. The checker does not establish authored-model adequacy, semantic truth of evidence interpretations, live-runtime conformance, or independent reproduction.'}
report={'gate':'PROJECTION_ASSURANCE_V0.6.0_PROOF_CARRYING_TCB_GATE','status':'PASS' if all(x['status']=='PASS' for x in checks) else 'FAIL','checks':checks,'passed':sum(x['status']=='PASS' for x in checks),'total':len(checks),'checker_profile':checker_profile,'nonclaim':'The gate establishes that retained v0.5 certificates can be checked by a standalone standard-library-only reference checker that independently re-evaluates the restricted derivation language and finite semantic proof. It does not make the Python runtime, authored semantic premises, evidence interpretation, live system, or authorship independent.'}
(ROOT/'results/V0.6.0_PROOF_CARRYING_TCB_GATE.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');(ROOT/'results/V0.6.0_TCB_PROFILE.json').write_text(json.dumps(checker_profile,indent=2,sort_keys=True)+'\n');print(json.dumps({'status':report['status'],'passed':report['passed'],'total':report['total'],'checker_lines':lines,'checker_sha256':checker_profile['sha256']}));raise SystemExit(0 if report['status']=='PASS' else 2)

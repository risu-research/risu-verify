#!/usr/bin/env python3
from pathlib import Path
import ast,base64,copy,hashlib,json,os,shutil,subprocess,sys,tempfile
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from verifier.projection_adapter import load_adapter,normalize_adapter,normalize_adapter_with_compiled_source,validate_adapter_shape
from verifier.source_contract import compile_source_contract
from verifier.engine import evaluate_bundle
from verifier.semantic_compiler import compile_bundle
from verifier.certificate_v07 import build_projection_certificate,verify_projection_certificate
from verifier.common import canonical_bytes,digest_obj,sha256_file

checks=[]
def ck(n,c,d=''):checks.append({'check':n,'status':'PASS' if c else 'FAIL','detail':d})
def reject(n,fn):
    try:fn();ck(n,False,'accepted')
    except Exception as e:ck(n,True,str(e)[:240])
def run_pcc(cert,root=None,isolated=False):
    with tempfile.TemporaryDirectory() as td:
        td=Path(td);cp=td/'cert.json';cp.write_bytes(canonical_bytes(cert)+b'\n')
        if isolated:
            cdir=td/'checker';cdir.mkdir();
            for f in ['risu_contract_pcc_check.py','risu_pcc_check.py','risu_pcc_dispatch.py']:shutil.copy2(ROOT/'checker'/f,cdir/f)
            exe=cdir/'risu_pcc_dispatch.py'
        else:exe=ROOT/'checker/risu_pcc_dispatch.py'
        cmd=[sys.executable,str(exe),str(cp),'--json']
        if root is not None:cmd += ['--root',str(root)]
        p=subprocess.run(cmd,capture_output=True,text=True,cwd=td,timeout=40)
        try:o=json.loads(p.stdout)
        except Exception:o={'status':'PARSE_FAIL','stdout':p.stdout,'stderr':p.stderr}
        return p.returncode,o

def loadv(rel):
    a,p,r=load_adapter(ROOT/rel);b,c,s,ar=normalize_adapter(a,r);res=evaluate_bundle(b,r);cert=build_projection_certificate(a,r);return a,r,b,c,s,ar,res,cert

# A. Source compiler conformance and canonical contracts.
cp=subprocess.run([sys.executable,str(ROOT/'source_compiler/runner/conformance_runner.py')],capture_output=True,text=True,timeout=60);cr=json.loads(cp.stdout);ck('source-compiler-conformance-15-15',cp.returncode==0 and cr['status']=='PASS' and cr['passed']==15 and cr['total']==15)
GH=loadv('projections/canonical/github');AZ=loadv('projections/canonical/azure')
for name,x in [('github',GH),('azure',AZ)]:
    a,r,b,c,s,ar,res,cert=x;ck('source-dual-runtime:'+name,ar['source_compilation']['full_result_differential']=='PASS');ck('source-generated-no-authored-worlds:'+name,'world_records' not in a['target']['derivation']);ck('adapter-no-authored-K:'+name,'consequence' not in a['target']['structural_template']);ck('source-domain-totality:'+name,s['domain_proof']['k_totality']=='PASS');ck('normalized-v05-valid:'+name,b['bundle_version']=='0.5');ck('evidence-pass:'+name,res['evidence_verification_status']=='PASS')
ck('github-outcome-retained',GH[6]['structural']['structural_classification']=='OPERATIVE_DISCHARGE_MISSING' and GH[6]['exact_realization']['failure_mode']=='MECHANISM_MISALIGNMENT')
ck('azure-outcome-retained',AZ[6]['structural']['structural_classification']=='STRUCTURAL_ASSURANCE_ESTABLISHED' and AZ[6]['exact_realization']['status']=='REALIZATION_ESTABLISHED' and AZ[6]['structural']['coverage_complete'] is False)
ck('azure-domain-completeness-6-to-3',AZ[4]['domain_proof']['cartesian_cardinality']==6 and AZ[4]['domain_proof']['admitted_cardinality']==3 and AZ[4]['domain_proof']['excluded_cardinality']==3)

# B. Source contract / target adapter separation is fail-closed.
a=copy.deepcopy(GH[0]);a['target']['structural_template']['worlds']=['x'];reject('reject-adapter-authored-worlds',lambda:validate_adapter_shape(a))
a=copy.deepcopy(GH[0]);a['target']['structural_template']['source_by_world']={'x':'y'};reject('reject-adapter-authored-K-table',lambda:validate_adapter_shape(a))
a=copy.deepcopy(GH[0]);a['target']['derivation']['world_records']=[];reject('reject-adapter-world-records',lambda:validate_adapter_shape(a))
a=copy.deepcopy(GH[0]);a['target']['structural_template']['declared_target_model_by_world']={};reject('reject-adapter-authored-target-table',lambda:validate_adapter_shape(a))
with tempfile.TemporaryDirectory() as td:
    d=Path(td);shutil.copytree(GH[1],d/'p');p=d/'p';a=json.loads((p/'adapter.json').read_text());a['source_contract']['sha256']='0'*64;(p/'adapter.json').write_text(json.dumps(a));reject('reject-source-contract-pin-mismatch',lambda:normalize_adapter(a,p))

# C. Complete-domain behavior and semantic invariance.
c0=copy.deepcopy(GH[3]);out0,rec0=compile_source_contract(c0)
c1=copy.deepcopy(c0);c1['coordinates']['request_head']=list(reversed(c1['coordinates']['request_head']));out1,rec1=compile_source_contract(c1);ck('domain-value-order-semantic-invariant',out0==out1)
c2=copy.deepcopy(c0);c2['metadata']={'irrelevant':'changed'};out2,rec2=compile_source_contract(c2);ck('source-metadata-semantic-invariant',out0==out2)
# K mutation changes source semantics but must not change target blind derivation for same generated worlds.
cm=copy.deepcopy(c0);cm['consequence']['expr']['then']['value']='STALE_REQUEST_REJECTED';cm['consequence']['expr']['else']['value']='MERGED_REVIEWED_HEAD';om,rm=compile_source_contract(cm);ck('K-mutation-changes-source-semantic-digest',om['source_semantic_digest']!=out0['source_semantic_digest'] and om['domain_proof']['admitted_world_digest']==out0['domain_proof']['admitted_world_digest'])
base_b,_,_,_=normalize_adapter_with_compiled_source(GH[0],c0,out0,{**rec0,'source_contract_file_sha256':GH[0]['source_contract']['sha256'],'source_contract_path':'source-contract.json','source_contract_id':c0['contract_id']})
mut_b,_,_,_=normalize_adapter_with_compiled_source(GH[0],cm,om,{**rm,'source_contract_file_sha256':GH[0]['source_contract']['sha256'],'source_contract_path':'source-contract.json','source_contract_id':cm['contract_id']})
bc,_=compile_bundle(base_b);mc,_=compile_bundle(mut_b);ck('K-mutation-target-compilation-noninterference',bc['semantic']['structural_profile']['discriminator']['signature_by_world']==mc['semantic']['structural_profile']['discriminator']['signature_by_world'] and bc['semantic']['exact_profile']['operative_signature_by_world']==mc['semantic']['exact_profile']['operative_signature_by_world'] and bc['semantic']['exact_profile']['mechanism_consequence_by_world']==mc['semantic']['exact_profile']['mechanism_consequence_by_world'])
# Domain expansion must generate a new world without target code changes.
ce=copy.deepcopy(c0);ce['coordinates']['request_head'].append('H2');oe,re=compile_source_contract(ce);ck('domain-expansion-generates-new-world',oe['domain_proof']['admitted_cardinality']==3 and oe['domain_proof']['cartesian_cardinality']==3)
eb,_,_,_=normalize_adapter_with_compiled_source(GH[0],ce,oe,{**re,'source_contract_file_sha256':GH[0]['source_contract']['sha256'],'source_contract_path':'source-contract.json','source_contract_id':ce['contract_id']});er=evaluate_bundle(eb,None,check_bindings=False);ck('domain-expansion-target-core-still-generic',len(er['compilation']['derived']['discriminator_signature_by_world'])==3 and er['exact_realization']['failure_mode']=='MECHANISM_MISALIGNMENT')

# D. Reuse: one immutable source contract, two target projections, opposite exact outcomes.
P=loadv('projections/examples/shared-contract/adapter-preserved.json');M=loadv('projections/examples/shared-contract/adapter-misaligned.json');ck('one-contract-two-adapters-same-source-digest',P[5]['source_semantic_digest']==M[5]['source_semantic_digest']);ck('source-contract-reuse-distinguishes-targets',P[6]['exact_realization']['status']=='REALIZATION_ESTABLISHED' and M[6]['exact_realization']['failure_mode']=='MECHANISM_MISALIGNMENT')

# E. v0.7 certificates are accepted by producer and layered standalone checker.
for name,x in [('github',GH),('azure',AZ),('shared-preserved',P),('shared-misaligned',M)]:
    a,r,b,c,s,ar,res,cert=x;vr=verify_projection_certificate(cert,r);rc,q=run_pcc(cert,r);raw=base64.b64decode(cert['source_contract_file_b64'],validate=True);ck('v07-main-cert:'+name,vr['status']=='PASS');ck('v07-layered-pcc:'+name,rc==0 and q['status']=='PASS',str(q.get('checks',[])[-1:]));ck('v07-inner-normalized-binding:'+name,cert['inner_certificate']['bundle_snapshot']==b);ck('v07-self-contained-source-pin:'+name,hashlib.sha256(raw).hexdigest()==cert['source_contract_file_sha256'] and json.loads(raw.decode('utf-8'))==c)
# Isolated checker TCB excludes producer tree.
rc,q=run_pcc(GH[7],GH[1],isolated=True);ck('isolated-layered-checker-evidence-linked',rc==0 and q['status']=='PASS')
rc,q=run_pcc(P[7],None,isolated=True);ck('isolated-layered-checker-declared-only',rc==0 and q['status']=='PASS')
rc,q=run_pcc(GH[7],None,isolated=True);ck('isolated-no-root-partial',rc==4 and q['status']=='PARTIAL')

# F. Certificate tampering including coordinated re-digests must fail.
def tamper(n,fn,root=GH[1]):
    t=copy.deepcopy(GH[7]);fn(t);rc,q=run_pcc(t,root,isolated=True);ck(n,rc==2 and q['status']=='FAIL',str(q.get('checks',[])[-2:]))
tamper('reject-source-contract-snapshot-tamper',lambda t:t['source_contract_snapshot']['coordinates']['request_head'].append('H9'))
tamper('reject-adapter-snapshot-tamper',lambda t:t['adapter_snapshot']['target']['coverage']['in_scope'].append('FAKE'))
tamper('reject-source-domain-proof-tamper',lambda t:t['source_domain_proof'].__setitem__('admitted_cardinality',99))
tamper('reject-normalized-bundle-digest-tamper',lambda t:t.__setitem__('normalized_bundle_digest','0'*64))
tamper('reject-inner-certificate-tamper',lambda t:t['inner_certificate']['results']['structural'].__setitem__('D','D0'))
def coordinated_source(t):
    t['source_contract_snapshot']['coordinates']['request_head'].append('H9');t['source_contract_snapshot_digest']=digest_obj(t['source_contract_snapshot'])
tamper('reject-source-tamper-even-redigested',coordinated_source)
def coordinated_adapter(t):
    t['adapter_snapshot']['target']['structural_template']['discharge']['gates_effect']=True;t['adapter_digest']=digest_obj(t['adapter_snapshot'])
tamper('reject-adapter-tamper-even-redigested',coordinated_adapter)
tamper('reject-verifier-boundary-favorable-claim',lambda t:t['verifier_boundary'].__setitem__('source_contract_adequacy','ESTABLISHED'))
tamper('reject-embedded-source-bytes-tamper',lambda t:t.__setitem__('source_contract_file_b64',base64.b64encode(b'{}\n').decode('ascii')))
# A certificate checked against a supplied root must rehash the source contract itself, not only inner evidence.
with tempfile.TemporaryDirectory() as td:
    rr=Path(td)/'github';shutil.copytree(GH[1],rr);sp=rr/GH[0]['source_contract']['path'];mut=json.loads(sp.read_text());mut['metadata']={'tampered_after_issuance':True};sp.write_text(json.dumps(mut))
    pv=verify_projection_certificate(GH[7],rr);rc,q=run_pcc(GH[7],rr,isolated=True);ck('reject-producer-source-contract-byte-tamper',pv['status']=='FAIL',str(pv.get('checks',[])[-3:]));ck('reject-layered-checker-source-contract-byte-tamper',rc==2 and q['status']=='FAIL',str(q.get('checks',[])[-3:]))

# G. Checker TCB stays separate from producer code.
for f in ['checker/risu_contract_pcc_check.py','checker/risu_pcc_check.py']:
    src=(ROOT/f).read_text();tree=ast.parse(src);bad=[]
    for n in ast.walk(tree):
        if isinstance(n,ast.ImportFrom) and (n.module or '').split('.')[0] in {'verifier','compiler','kernel','exact','source_compiler'}:bad.append(n.module)
        if isinstance(n,ast.Import):
            for q in n.names:
                if q.name.split('.')[0] in {'verifier','compiler','kernel','exact','source_compiler'}:bad.append(q.name)
    ck('checker-no-producer-imports:'+Path(f).name,not bad,','.join(bad))
ck('contract-checker-carrier-neutral',not any(x in (ROOT/'checker/risu_contract_pcc_check.py').read_text().lower() for x in ['github','azure','paypal']))

report={'gate':'PROJECTION_ASSURANCE_V0.7.0_SOURCE_CONSEQUENCE_CONTRACT_GATE','status':'PASS' if all(x['status']=='PASS' for x in checks) else 'FAIL','passed':sum(x['status']=='PASS' for x in checks),'total':len(checks),'checks':checks,'nonclaim':'v0.7 eliminates authored per-world source tables for its Source Consequence Contract path and pins target adapters to immutable source contracts. It remains conditional on the declared finite coordinate domains, admissibility predicate, source consequence function, Boundary, and evidence interpretations; it does not establish live-runtime conformance or independent authorship/reproduction.'}
(ROOT/'results/V0.7.0_SOURCE_CONSEQUENCE_CONTRACT_GATE.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');print(json.dumps({'status':report['status'],'passed':report['passed'],'total':report['total']}));raise SystemExit(0 if report['status']=='PASS' else 2)

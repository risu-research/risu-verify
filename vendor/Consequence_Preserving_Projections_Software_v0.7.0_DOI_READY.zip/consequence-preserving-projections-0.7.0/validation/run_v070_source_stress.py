#!/usr/bin/env python3
from pathlib import Path
import copy, importlib.util, json, random, subprocess, sys
ROOT=Path(__file__).resolve().parents[1]
PY_COMP=ROOT/'source_compiler/implementations/reference_source_compiler.py'
JS_COMP=ROOT/'source_compiler/implementations/node_source_compiler.js'
CHECKER=ROOT/'checker/risu_contract_pcc_check.py'
SEED=7072026;VALID_N=200;INVALID_N=200;META_N=50

def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
PY=load(PY_COMP,'risu_source_py_stress');CHECK=load(CHECKER,'risu_source_checker_stress')

def lit(v):return {'op':'literal','value':v}
def getc(k):return {'op':'get','source':'coord','path':[k]}
def getconst(k):return {'op':'get','source':'const','path':[k]}
def eq(a,b):return {'op':'eq','left':a,'right':b}
def neq(a,b):return {'op':'neq','left':a,'right':b}
def iff(c,a,b):return {'op':'if','cond':c,'then':a,'else':b}
ATOM_POOL=['A','B','C','D',-2,-1,0,1,2,False,True,None]
def unique_values(rng,n):
    pool=copy.deepcopy(ATOM_POOL);rng.shuffle(pool);out=[]
    for v in pool:
        sig=(type(v).__name__,repr(v))
        if all((type(x).__name__,repr(x))!=sig for x in out):out.append(v)
        if len(out)==n:return out
    raise AssertionError

def make_valid(rng,i):
    nc=rng.randint(1,3);coords={f'c{j}':unique_values(rng,rng.randint(2,3)) for j in range(nc)};keys=list(coords);anchor=copy.deepcopy(coords[keys[0]][0]);constants={'anchor':anchor,'tag':f'T{i%7}'} if i%3 else {}
    mode=i%5
    if mode==0:adm=lit(True)
    elif mode==1:adm=neq(getc(keys[0]),lit(coords[keys[0]][-1]))
    elif mode==2:adm=eq(getc(keys[0]),lit(coords[keys[0]][0]))
    elif mode==3 and len(keys)>1:adm={'op':'or','args':[eq(getc(keys[0]),lit(coords[keys[0]][0])),eq(getc(keys[1]),lit(coords[keys[1]][0]))]}
    else:adm={'op':'not','expr':neq(getc(keys[0]),lit(coords[keys[0]][0]))}
    cond=eq(getc(keys[0]),lit(coords[keys[0]][0]));cond=eq(getc(keys[0]),getconst('anchor')) if constants and i%4==0 else cond
    if i%4==1:kexpr,cod=iff(cond,lit('C0'),lit('C1')),['C0','C1']
    elif i%4==2 and len(keys)>1:
        c2=eq(getc(keys[1]),lit(coords[keys[1]][0]));kexpr,cod=iff(cond,lit('C0'),iff(c2,lit('C1'),lit('C2'))),['C0','C1','C2']
    elif i%4==3:kexpr,cod=iff({'op':'is_null','expr':getc(keys[0])},lit('C0'),lit('C1')),['C0','C1']
    else:kexpr,cod=lit('C0'),['C0']
    for v in coords.values():rng.shuffle(v)
    return {'source_contract_version':'0.7','contract_id':f'STRESS-{i:04d}','metadata':{'seed':SEED,'case':i},'constants':constants,'coordinates':coords,'admissibility':{'expr':adm},'consequence':{'lens':'L','codomain':cod,'expr':kexpr},'boundary':{'declaration':'stress finite boundary','post_check_material_transition_possible':bool(i%2)},'source_family':['OP_B','OP_A'] if i%2 else ['OP_A'],'claim_boundary':{'model_relative':True}}

def mutate_invalid(base,i):
    x=copy.deepcopy(base);m=i%12
    if m==0:x['worlds']=[]
    elif m==1:x['consequence']['expr']={'op':'get','source':'target','path':['x']}
    elif m==2:x['coordinates'][next(iter(x['coordinates']))]=[1,1.0]
    elif m==3:x['coordinates'][next(iter(x['coordinates']))]=[0,9007199254740992]
    elif m==4:x['admissibility']['expr']=lit(False)
    elif m==5:x['consequence']['expr']=lit('NOT_IN_CODOMAIN')
    elif m==6:x['consequence']['expr']={'op':'mystery'}
    elif m==7:x['coordinates']['id']=['X']
    elif m==8:x['coordinates'][next(iter(x['coordinates']))]=[]
    elif m==9:x['source_family']=['OP','OP']
    elif m==10:x['admissibility']['expr']=lit('not-a-bool')
    else:x['consequence']['codomain']=['C0','C0']
    return x

def permuted(c,rng):
    x=copy.deepcopy(c);x['coordinates']={k:list(reversed(v)) for k,v in reversed(list(x['coordinates'].items()))};x['metadata']={'different_nonsemantic_metadata':rng.randint(0,1_000_000)};return x

def local_run(fn,obj):
    try:return True,fn(copy.deepcopy(obj))
    except Exception as e:return False,{'error':str(e)}

def node_batch(objs):
    js="const m=require(process.argv[1]);let s='';process.stdin.setEncoding('utf8');process.stdin.on('data',d=>s+=d);process.stdin.on('end',()=>{const xs=JSON.parse(s),out=xs.map(x=>{try{return {ok:true,result:m.compile(x)}}catch(e){return {ok:false,error:e.message}}});process.stdout.write(JSON.stringify(out))});"
    cp=subprocess.run(['node','-e',js,str(JS_COMP)],input=json.dumps(objs,separators=(',',':'),ensure_ascii=False).encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=120)
    if cp.returncode!=0:raise RuntimeError(cp.stderr.decode('utf-8','replace')[-1000:])
    return json.loads(cp.stdout)

def main():
    rng=random.Random(SEED);valid=[make_valid(rng,i) for i in range(VALID_N)];meta=[permuted(valid[i],rng) for i in range(META_N)];invalid=[mutate_invalid(make_valid(rng,10000+i),i) for i in range(INVALID_N)];allcases=valid+meta+invalid;node=node_batch(allcases);fail=[];vp=mp=ip=0
    for i,c in enumerate(valid):
        po,pr=local_run(PY.compile_contract,c);co,cr=local_run(CHECK.compile_source,c);jr=node[i];ok=po and co and jr['ok'] and pr==cr==jr['result'];vp+=int(ok)
        if not ok:fail.append({'kind':'valid','i':i,'python_ok':po,'checker_ok':co,'node_ok':jr['ok']})
    off=VALID_N
    for i,c in enumerate(meta):
        po,pr=local_run(PY.compile_contract,c);co,cr=local_run(CHECK.compile_source,c);jr=node[off+i];base=PY.compile_contract(valid[i]);ok=po and co and jr['ok'] and pr==cr==jr['result']==base;mp+=int(ok)
        if not ok:fail.append({'kind':'metamorphic','i':i})
    off+=META_N
    for i,c in enumerate(invalid):
        po,pr=local_run(PY.compile_contract,c);co,cr=local_run(CHECK.compile_source,c);jr=node[off+i];ok=(not po) and (not co) and (not jr['ok']);ip+=int(ok)
        if not ok:fail.append({'kind':'invalid','i':i,'python_ok':po,'checker_ok':co,'node_ok':jr['ok']})
    out={'gate':'PROJECTION_ASSURANCE_V0.7.0_SOURCE_COMPILER_STRESS_GATE','seed':SEED,'status':'PASS' if vp==VALID_N and mp==META_N and ip==INVALID_N and not fail else 'FAIL','valid_triple_differential':{'passed':vp,'total':VALID_N},'invalid_triple_rejection':{'passed':ip,'total':INVALID_N},'metamorphic_domain_order_and_metadata_invariance':{'passed':mp,'total':META_N},'implementations':['source_compiler/implementations/reference_source_compiler.py','source_compiler/implementations/node_source_compiler.js','checker/risu_contract_pcc_check.py'],'failures':fail[:10],'nonclaim':'Deterministic randomized differential testing increases confidence in agreement among the two producer source compilers and the standalone consumer source semantics. It is not exhaustive verification or a proof of real-system model adequacy.'}
    (ROOT/'results/V0.7.0_SOURCE_COMPILER_STRESS_GATE.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(json.dumps(out,indent=2,sort_keys=True));return 0 if out['status']=='PASS' else 2
if __name__=='__main__':raise SystemExit(main())

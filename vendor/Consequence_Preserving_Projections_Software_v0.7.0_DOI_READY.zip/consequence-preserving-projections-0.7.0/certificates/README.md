# Certificates

v0.7 issues layered proof-carrying certificates from a Source Consequence Contract and a Projection Adapter.

```sh
./risu-projection verify <adapter-or-projection-dir> \
  --certificate certificate.json

./risu-projection certificate verify certificate.json \
  --root <projection-root>

./risu-pcc-check certificate.json \
  --root <projection-root>
```

The producer verification path recomputes the v0.7 source-contract layer and the target assurance result. The compact consumer path is separate: it verifies the embedded source-contract pin, regenerates the declared source domain and consequence map, reconstructs the normalized target bundle, and checks the inner finite proof without importing the producer compiler, kernels, verifier, or certificate builder.

For evidence-linked certificates, omitting `--root` yields `PARTIAL`. A full `PASS` requires the claim-linked bytes to be rehashed against the supplied root.

Older release and evidence archives are referenced by digest under `provenance/`; they are not nested into the current public package.

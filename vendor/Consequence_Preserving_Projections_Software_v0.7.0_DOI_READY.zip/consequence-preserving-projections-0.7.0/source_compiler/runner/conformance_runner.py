#!/usr/bin/env python3
from pathlib import Path
import json,subprocess,sys
ROOT=Path(__file__).resolve().parents[2];V=ROOT/'source_compiler/vectors';PY=ROOT/'source_compiler/implementations/reference_source_compiler.py';JS=ROOT/'source_compiler/implementations/node_source_compiler.js'
rows=[]
for p in sorted(V.glob('S*.json')):
 v=json.loads(p.read_text());raw=json.dumps(v['input'],sort_keys=True,separators=(',',':')).encode()
 def run(cmd):
  cp=subprocess.run(cmd,input=raw,stdout=subprocess.PIPE,stderr=subprocess.PIPE);o=json.loads(cp.stdout or b'{}');return cp.returncode,o
 pr,po=run([sys.executable,str(PY)]);jr,jo=run(['node',str(JS)]);same=po==jo;accepted_same=bool(po.get('ok'))==bool(jo.get('ok'));ok=bool(po.get('ok'))==v['expect_ok'] and bool(jo.get('ok'))==v['expect_ok'] and accepted_same and (same if v['expect_ok'] else True)
 if ok and v['expect_ok']:
  dp=po['result']['domain_proof'];ok=all(dp.get(k)==val for k,val in v.get('checks',{}).items())
 rows.append({'vector':p.stem,'status':'PASS' if ok else 'FAIL','python_ok':po.get('ok'),'node_ok':jo.get('ok'),'full_result_differential':('PASS' if same else ('NOT_REQUIRED_REJECTION' if not v['expect_ok'] and accepted_same else 'FAIL'))})
out={'status':'PASS' if all(r['status']=='PASS' for r in rows) else 'FAIL','passed':sum(r['status']=='PASS' for r in rows),'total':len(rows),'rows':rows};print(json.dumps(out,indent=2,sort_keys=True));raise SystemExit(0 if out['status']=='PASS' else 2)

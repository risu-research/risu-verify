#!/usr/bin/env python3
import hashlib,itertools,json,math,sys
PROTOCOL='risu-source-consequence-contract/0.7'
SAFE_INT=9007199254740991
OPS={'literal','get','object','array','if','eq','neq','and','or','not','is_null'}
ALLOWED={'coord','const'}

def fail(m): raise ValueError(m)
def req(c,m):
    if not c: fail(m)
def nj(v):
    if isinstance(v,float) and math.isfinite(v) and v.is_integer(): return int(v)
    if isinstance(v,list): return [nj(x) for x in v]
    if isinstance(v,dict): return {k:nj(x) for k,x in v.items()}
    return v
def cbytes(x): return json.dumps(nj(x),sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def digest(x): return hashlib.sha256(cbytes(x)).hexdigest()
def valid(v,p='value'):
    if v is None or isinstance(v,(bool,str)): return
    if isinstance(v,(int,float)) and not isinstance(v,bool):
        req(not isinstance(v,float) or math.isfinite(v),f'{p}: non-finite number')
        if float(v).is_integer(): req(abs(int(v))<=SAFE_INT,f'{p}: unsafe integer')
        return
    if isinstance(v,list):
        for i,x in enumerate(v):valid(x,f'{p}[{i}]')
        return
    if isinstance(v,dict):
        for k,x in v.items():req(isinstance(k,str),f'{p}: non-string key');valid(x,f'{p}.{k}')
        return
    fail(f'{p}: unsupported JSON value')
def jeq(a,b):
    valid(a);valid(b)
    if a is None or b is None:return a is b
    if isinstance(a,bool) or isinstance(b,bool):return isinstance(a,bool) and isinstance(b,bool) and a==b
    if isinstance(a,(int,float)) and isinstance(b,(int,float)) and not isinstance(a,bool) and not isinstance(b,bool):return float(a)==float(b)
    if isinstance(a,str) or isinstance(b,str):return isinstance(a,str) and isinstance(b,str) and a==b
    if isinstance(a,list) or isinstance(b,list):return isinstance(a,list) and isinstance(b,list) and len(a)==len(b) and all(jeq(x,y) for x,y in zip(a,b))
    if isinstance(a,dict) or isinstance(b,dict):return isinstance(a,dict) and isinstance(b,dict) and set(a)==set(b) and all(jeq(a[k],b[k]) for k in a)
    return False
def keys(o,allowed,required,p):
    req(isinstance(o,dict),f'{p}: object required');extra=set(o)-set(allowed);missing=set(required)-set(o);req(not extra,f'{p}: unknown keys {sorted(extra)}');req(not missing,f'{p}: missing keys {sorted(missing)}')
def get(src,path,p):
    req(isinstance(path,list) and all(isinstance(x,str) and x for x in path),f'{p}: invalid path');cur=src
    for x in path:req(isinstance(cur,dict) and x in cur,f'{p}: missing {x}');cur=cur[x]
    return cur
def vexpr(e,p='expr',d=0):
    req(d<=64,f'{p}: nesting');req(isinstance(e,dict),f'{p}: object required');op=e.get('op');req(op in OPS,f'{p}: unsupported op {op!r}')
    shapes={'literal':({'op','value'},{'op','value'}),'get':({'op','source','path'},{'op','source','path'}),'object':({'op','fields'},{'op','fields'}),'array':({'op','items'},{'op','items'}),'if':({'op','cond','then','else'},{'op','cond','then','else'}),'eq':({'op','left','right'},{'op','left','right'}),'neq':({'op','left','right'},{'op','left','right'}),'and':({'op','args'},{'op','args'}),'or':({'op','args'},{'op','args'}),'not':({'op','expr'},{'op','expr'}),'is_null':({'op','expr'},{'op','expr'})}
    keys(e,*shapes[op],p)
    if op=='literal':valid(e['value'],p+'.value')
    elif op=='get':req(e['source'] in ALLOWED,f'{p}: source {e["source"]!r} forbidden');req(isinstance(e['path'],list) and all(isinstance(x,str) and x for x in e['path']),f'{p}: bad path')
    elif op=='object':req(isinstance(e['fields'],dict),f'{p}: fields');[vexpr(x,p+'.'+k,d+1) for k,x in e['fields'].items()]
    elif op=='array':req(isinstance(e['items'],list),f'{p}: items');[vexpr(x,p,d+1) for x in e['items']]
    elif op=='if':[vexpr(e[k],p+'.'+k,d+1) for k in ('cond','then','else')]
    elif op in {'eq','neq'}:[vexpr(e[k],p+'.'+k,d+1) for k in ('left','right')]
    elif op in {'and','or'}:req(isinstance(e['args'],list) and e['args'],f'{p}: args');[vexpr(x,p,d+1) for x in e['args']]
    else:vexpr(e['expr'],p+'.expr',d+1)
def ev(e,env,d=0):
    req(d<=64,'expression nesting');op=e['op']
    if op=='literal':return e['value']
    if op=='get':return get(env[e['source']],e['path'],'get')
    if op=='object':return {k:ev(v,env,d+1) for k,v in e['fields'].items()}
    if op=='array':return [ev(v,env,d+1) for v in e['items']]
    if op in {'eq','neq'}:
        q=jeq(ev(e['left'],env,d+1),ev(e['right'],env,d+1));return q if op=='eq' else not q
    if op in {'not','is_null'}:
        q=ev(e['expr'],env,d+1)
        if op=='is_null':return q is None
        req(type(q) is bool,'not operand');return not q
    if op in {'and','or'}:
        q=[ev(v,env,d+1) for v in e['args']];req(all(type(x) is bool for x in q),f'{op} operands');return all(q) if op=='and' else any(q)
    q=ev(e['cond'],env,d+1);req(type(q) is bool,'if condition');return ev(e['then'] if q else e['else'],env,d+1)
def footprint(e):
    r=set()
    def w(x):
        op=x['op']
        if op=='get':r.add((x['source'],tuple(x['path'])))
        elif op=='object':[w(v) for v in x['fields'].values()]
        elif op=='array':[w(v) for v in x['items']]
        elif op=='if':[w(x[k]) for k in ('cond','then','else')]
        elif op in {'eq','neq'}:[w(x[k]) for k in ('left','right')]
        elif op in {'and','or'}:[w(v) for v in x['args']]
        elif op in {'not','is_null'}:w(x['expr'])
    w(e);return [{'source':s,'path':list(p)} for s,p in sorted(r,key=lambda q:(q[0],json.dumps(q[1])))]
def normalize_domain(vals,p):
    req(isinstance(vals,list) and vals,f'{p}: nonempty array required');[valid(v,p) for v in vals]
    out=[]
    for v in vals:
        req(not any(jeq(v,x) for x in out),f'{p}: duplicate semantic value')
        out.append(v)
    return sorted([nj(x) for x in out],key=lambda x:cbytes(x))
def validate_contract(c):
    keys(c,{'source_contract_version','contract_id','metadata','constants','coordinates','admissibility','consequence','boundary','source_family','claim_boundary'},{'source_contract_version','contract_id','coordinates','admissibility','consequence','boundary','source_family'},'contract')
    req(c['source_contract_version']=='0.7','source_contract_version must be 0.7');req(isinstance(c['contract_id'],str) and c['contract_id'],'contract_id required')
    coords=c['coordinates'];req(isinstance(coords,dict) and coords,'coordinates object required');req('id' not in coords,'coordinate name id is reserved')
    for k,v in coords.items():req(isinstance(k,str) and k,f'invalid coordinate name');normalize_domain(v,f'coordinates.{k}')
    const=c.get('constants',{});req(isinstance(const,dict),'constants object required');valid(const,'constants')
    adm=c['admissibility'];keys(adm,{'expr'},{'expr'},'admissibility');vexpr(adm['expr'],'admissibility.expr')
    con=c['consequence'];keys(con,{'lens','codomain','expr'},{'lens','codomain','expr'},'consequence');req(isinstance(con['lens'],str) and con['lens'],'consequence.lens required');req(isinstance(con['codomain'],list) and con['codomain'] and all(isinstance(x,str) and x for x in con['codomain']) and len(set(con['codomain']))==len(con['codomain']),'consequence.codomain unique strings required');vexpr(con['expr'],'consequence.expr')
    b=c['boundary'];keys(b,{'declaration','post_check_material_transition_possible'},{'declaration','post_check_material_transition_possible'},'boundary');req(isinstance(b['declaration'],str) and b['declaration'],'boundary declaration required');req(type(b['post_check_material_transition_possible']) is bool,'boundary transition flag must be boolean')
    fam=c['source_family'];req(isinstance(fam,list) and fam and all(isinstance(x,str) and x for x in fam) and len(set(fam))==len(fam),'source_family unique string array required')
    return True
def normalized_semantics(c):
    return {'coordinates':{k:normalize_domain(c['coordinates'][k],f'coordinates.{k}') for k in sorted(c['coordinates'])},'constants':nj(c.get('constants',{})),'admissibility':nj(c['admissibility']),'consequence':nj(c['consequence']),'boundary':nj(c['boundary']),'source_family':sorted(c['source_family'])}
def compile_contract(c):
    validate_contract(c);n=normalized_semantics(c);names=sorted(n['coordinates']);domains=[n['coordinates'][k] for k in names];total=1
    for d in domains:total*=len(d)
    req(total<=100000,'declared Cartesian domain exceeds 100000 valuations')
    worlds=[];excluded=[];ids=set();K={}
    for vals in itertools.product(*domains):
        coord={k:v for k,v in zip(names,vals)};env={'coord':coord,'const':n['constants']};ok=ev(n['admissibility']['expr'],env);req(type(ok) is bool,'admissibility must evaluate to boolean')
        rawid='W-'+digest(coord)[:20]
        req(rawid not in ids,'generated world identifier collision');ids.add(rawid)
        if not ok:excluded.append({'id':rawid,'coordinates':coord});continue
        kv=ev(n['consequence']['expr'],env);req(isinstance(kv,str) and kv in n['consequence']['codomain'],f'consequence outside declared codomain at {coord}: {kv!r}')
        worlds.append({'id':rawid,'coordinates':coord});K[rawid]=kv
    req(worlds,'admissibility excludes every valuation')
    return {'protocol':PROTOCOL,'contract_id':c['contract_id'],'source_semantic_digest':digest(n),'world_records':worlds,'consequence_by_world':K,'domain_proof':{'coordinate_order':names,'domain_cardinalities':{k:len(n['coordinates'][k]) for k in names},'cartesian_cardinality':total,'admitted_cardinality':len(worlds),'excluded_cardinality':len(excluded),'admitted_world_digest':digest(worlds),'excluded_world_digest':digest(excluded),'consequence_map_digest':digest(K),'k_totality':'PASS','codomain':list(n['consequence']['codomain'])},'stage_input_footprint':{'admissibility':footprint(n['admissibility']['expr']),'consequence':footprint(n['consequence']['expr'])},'normalized_source_semantics':n}
def one(raw):
    try:return {'ok':True,'result':compile_contract(json.loads(raw))}
    except Exception as e:return {'ok':False,'error':str(e)}
if __name__=='__main__':
    raw=sys.stdin.read();o=one(raw);sys.stdout.write(json.dumps(o,sort_keys=True,separators=(',',':'),ensure_ascii=False)+'\n');sys.exit(0 if o['ok'] else 2)

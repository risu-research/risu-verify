#!/bin/sh
set -eu
export PYTHONDONTWRITEBYTECODE=1
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
OUT="$ROOT/reproduction-output"
rm -rf "$OUT"; mkdir -p "$OUT"

# Retained finite semantic kernels / target compiler.
python3 "$ROOT/kernel/runner/conformance_runner.py" --testee-cmd "python3 $ROOT/kernel/implementations/reference_analyzer.py" --expected "$ROOT/kernel/VECTOR_EXPECTATIONS_v0.4.json" --json-out "$OUT/structural-python.json" --junit-out "$OUT/structural-python.xml" >/dev/null
python3 "$ROOT/kernel/runner/conformance_runner.py" --testee-cmd "node $ROOT/kernel/implementations/node_analyzer.js" --expected "$ROOT/kernel/VECTOR_EXPECTATIONS_v0.4.json" --json-out "$OUT/structural-node.json" --junit-out "$OUT/structural-node.xml" >/dev/null
python3 "$ROOT/exact/runner/conformance_runner.py" --testee-cmd "python3 $ROOT/exact/implementations/reference_exact.py" --json-out "$OUT/exact-python.json" --junit-out "$OUT/exact-python.xml" >/dev/null
python3 "$ROOT/exact/runner/conformance_runner.py" --testee-cmd "node $ROOT/exact/implementations/node_exact.js" --json-out "$OUT/exact-node.json" --junit-out "$OUT/exact-node.xml" >/dev/null
python3 "$ROOT/compiler/runner/conformance_runner.py" --testee-cmd "python3 $ROOT/compiler/implementations/reference_compiler.py" --json-out "$OUT/target-compiler-python.json" >/dev/null
python3 "$ROOT/compiler/runner/conformance_runner.py" --testee-cmd "node $ROOT/compiler/implementations/node_compiler.js" --json-out "$OUT/target-compiler-node.json" >/dev/null

# New v0.7 source layer: fixed vectors, triple-implementation stress differential, and adversarial gate.
python3 "$ROOT/source_compiler/runner/conformance_runner.py" > "$OUT/source-compiler-conformance.json"
python3 "$ROOT/validation/run_v070_source_stress.py" > "$OUT/source-compiler-stress.json"
python3 "$ROOT/validation/run_v070_gates.py" > "$OUT/v0.7-source-contract-gate.json"

# Canonical GitHub path.
"$ROOT/risu-projection" source compile "$ROOT/projections/canonical/github/source-contract.json" -o "$OUT/github-source.json"
"$ROOT/risu-projection" verify "$ROOT/projections/canonical/github" --certificate "$OUT/github-certificate-v0.7.json" --require-source-contract --require-blind --require-evidence > "$OUT/github-explanation.txt"
"$ROOT/risu-projection" certificate verify "$OUT/github-certificate-v0.7.json" --root "$ROOT/projections/canonical/github" --json > "$OUT/github-producer-verification.json"
"$ROOT/risu-pcc-check" "$OUT/github-certificate-v0.7.json" --root "$ROOT/projections/canonical/github" --json > "$OUT/github-pcc-verification.json"
set +e
"$ROOT/risu-pcc-check" "$OUT/github-certificate-v0.7.json" --json > "$OUT/github-pcc-no-root.json"
RC=$?
set -e
[ "$RC" -eq 4 ] || { echo "expected GitHub evidence-linked no-root check to exit 4, got $RC" >&2; exit 2; }

# Canonical Azure path.
"$ROOT/risu-projection" source compile "$ROOT/projections/canonical/azure/source-contract.json" -o "$OUT/azure-source.json"
"$ROOT/risu-projection" verify "$ROOT/projections/canonical/azure" --certificate "$OUT/azure-certificate-v0.7.json" --require both --require-source-contract --require-blind --require-evidence > "$OUT/azure-explanation.txt"
"$ROOT/risu-projection" certificate verify "$OUT/azure-certificate-v0.7.json" --root "$ROOT/projections/canonical/azure" --json > "$OUT/azure-producer-verification.json"
"$ROOT/risu-pcc-check" "$OUT/azure-certificate-v0.7.json" --root "$ROOT/projections/canonical/azure" --json > "$OUT/azure-pcc-verification.json"

# One source contract reused by two declared-only projections with opposite exact outcomes.
"$ROOT/risu-projection" verify "$ROOT/projections/examples/shared-contract/adapter-preserved.json" --certificate "$OUT/shared-preserved-certificate-v0.7.json" --require-source-contract --require-blind > "$OUT/shared-preserved-explanation.txt"
"$ROOT/risu-projection" verify "$ROOT/projections/examples/shared-contract/adapter-misaligned.json" --certificate "$OUT/shared-misaligned-certificate-v0.7.json" --require-source-contract --require-blind > "$OUT/shared-misaligned-explanation.txt"
"$ROOT/risu-pcc-check" "$OUT/shared-preserved-certificate-v0.7.json" --json > "$OUT/shared-preserved-pcc.json"
"$ROOT/risu-pcc-check" "$OUT/shared-misaligned-certificate-v0.7.json" --json > "$OUT/shared-misaligned-pcc.json"
python3 - "$OUT" <<'PY'
import json,sys
from pathlib import Path
p=Path(sys.argv[1]);a=json.loads((p/'shared-preserved-certificate-v0.7.json').read_text());b=json.loads((p/'shared-misaligned-certificate-v0.7.json').read_text())
assert a['source_compilation']['source_semantic_digest']==b['source_compilation']['source_semantic_digest']
assert a['results']['exact_realization']['status']=='REALIZATION_ESTABLISHED'
assert b['results']['exact_realization']['failure_mode']=='MECHANISM_MISALIGNMENT'
assert a['source_contract_file_sha256']==b['source_contract_file_sha256']
print(json.dumps({'status':'PASS','same_source_semantic_digest':True,'same_source_file_pin':True,'preserved_exact':'REALIZATION_ESTABLISHED','misaligned_failure':'MECHANISM_MISALIGNMENT'},indent=2))
PY

# The current immutable surface must still verify after every replay above.
python3 "$ROOT/tools/release_verify.py" > "$OUT/release-verification.json"
printf '%s\n' '{"status":"PASS","release":"0.7.0","source_architecture":"SOURCE_CONTRACT_SEPARATED","source_domain":"GENERATED_COMPLETE_DECLARED_FINITE_DOMAIN","target_compilation":"CONSEQUENCE_BLIND_DUAL_RUNTIME","certificate":"LAYERED_PROOF_CARRYING","consumer_checker":"PRODUCER_CODE_INDEPENDENT_LAYERED_REFERENCE","independent_reproduction":"NOT_CLAIMED"}' > "$OUT/REPRODUCTION_REPORT.json"
echo "v0.7.0 reproduction: PASS"

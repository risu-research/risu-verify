#!/usr/bin/env python3
"""Standalone Projection Assurance proof-carrying certificate checker v0.6.

Trusted-base design: Python standard library only; no imports from the main RISU verifier,
semantic compilers, structural kernel, Exact kernel, or certificate builder.
"""
import argparse, hashlib, json, math, os, sys
from pathlib import Path

CERT_VERSION='0.6'
PROOF_VERSION='0.6'
PROOF_SEMANTICS='FINITE_CONSEQUENCE_ASSURANCE_PROOF_WITH_BLIND_COMPILATION_AND_LOCAL_WITNESSES'
CERT_SEMANTICS='PROOF_CARRYING_CONSEQUENCE_BLIND_MODEL_RELATIVE_WITH_EXPLICIT_EVIDENCE_STATE'
COMPILER_PROTOCOL='risu-semantic-compiler/0.5'
SAFE_INT=9007199254740991
STAGES={'discriminator':{'world','const'},'operative_signature':{'world','const'},'mechanism':{'z','const'},'interpreter':{'native','const'}}
OPS={'literal','get','object','array','if','eq','neq','and','or','not','is_null'}
EPI={'EVIDENCE','QUALIFICATION','SOURCE'}
EDGE_RULES={'SUPPORTS':({'EVIDENCE','DERIVATION'},{'DERIVATION','CLAIM'}),'GROUNDS':({'EVIDENCE'},{'DERIVATION','CLAIM'}),'DERIVES':({'DECLARATION','DERIVATION'},{'DERIVATION','CLAIM'}),'BOUNDS':({'DECLARATION'},{'DERIVATION','CLAIM'}),'ESTABLISHES':({'EVIDENCE'},{'FACT'}),'USES':({'FACT','DECLARATION'},{'DERIVATION'})}
CLAIMS={'C','D','O','EXACT','COVERAGE'}
BOUNDARY={'model_relative':True,'evidence_integrity_does_not_establish_semantic_adequacy':True,'blind_compilation_is_input_independence_not_authorship_independence':True,'proof_checker_reduces_tcb_but_does_not_establish_model_adequacy':True,'world_model_adequacy':'NOT_ESTABLISHED_BY_CHECKER','evidence_fact_semantic_truth':'NOT_ESTABLISHED_BY_CHECKER','general_source_equivalence':'NOT_ESTABLISHED_BY_CHECKER','live_runtime_conformance':'NOT_ESTABLISHED_BY_CHECKER','independent_reproduction':'NOT_ESTABLISHED_BY_CHECKER'}
MAIN_BOUNDARY={'model_relative':True,'evidence_integrity_does_not_establish_semantic_adequacy':True,'blind_compilation_is_input_independence_not_authorship_independence':True,'world_model_adequacy':'NOT_ESTABLISHED_BY_VERIFIER','evidence_fact_semantic_truth':'NOT_ESTABLISHED_BY_VERIFIER','general_source_equivalence':'NOT_ESTABLISHED_BY_VERIFIER','live_runtime_conformance':'NOT_ESTABLISHED_BY_VERIFIER','independent_reproduction':'NOT_ESTABLISHED_BY_VERIFIER'}

def fail(m): raise ValueError(m)
def req(c,m):
    if not c: fail(m)
def cbytes(x): return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def digest(x): return hashlib.sha256(cbytes(x)).hexdigest()
def fhash(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b)
    return h.hexdigest()
def valid_json(v,p='value'):
    if v is None or isinstance(v,(bool,str)): return
    if isinstance(v,(int,float)) and not isinstance(v,bool):
        req(not isinstance(v,float) or math.isfinite(v),f'{p}: non-finite number')
        if float(v).is_integer(): req(abs(int(v))<=SAFE_INT,f'{p}: unsafe integer')
        return
    if isinstance(v,list):
        for i,x in enumerate(v):valid_json(x,f'{p}[{i}]')
        return
    if isinstance(v,dict):
        for k,x in v.items():req(isinstance(k,str),f'{p}: non-string key');valid_json(x,f'{p}.{k}')
        return
    fail(f'{p}: unsupported JSON value')
def jeq(a,b):
    valid_json(a);valid_json(b)
    if a is None or b is None:return a is b
    if isinstance(a,bool) or isinstance(b,bool):return isinstance(a,bool) and isinstance(b,bool) and a==b
    if isinstance(a,(int,float)) and isinstance(b,(int,float)) and not isinstance(a,bool) and not isinstance(b,bool):return float(a)==float(b)
    if isinstance(a,str) or isinstance(b,str):return isinstance(a,str) and isinstance(b,str) and a==b
    if isinstance(a,list) or isinstance(b,list):return isinstance(a,list) and isinstance(b,list) and len(a)==len(b) and all(jeq(x,y) for x,y in zip(a,b))
    if isinstance(a,dict) or isinstance(b,dict):return isinstance(a,dict) and isinstance(b,dict) and set(a)==set(b) and all(jeq(a[k],b[k]) for k in a)
    return False
def get(src,path,where):
    req(isinstance(path,list) and all(isinstance(x,str) and x for x in path),f'{where}: bad path');cur=src
    for x in path:req(isinstance(cur,dict) and x in cur,f'{where}: missing {x}');cur=cur[x]
    return cur
def vexpr(e,allowed,p='expr',d=0):
    req(d<=64,f'{p}: nesting');req(isinstance(e,dict),f'{p}: object required');op=e.get('op');req(op in OPS,f'{p}: unsupported op')
    shapes={'literal':{'op','value'},'get':{'op','source','path'},'object':{'op','fields'},'array':{'op','items'},'if':{'op','cond','then','else'},'eq':{'op','left','right'},'neq':{'op','left','right'},'and':{'op','args'},'or':{'op','args'},'not':{'op','expr'},'is_null':{'op','expr'}}
    req(set(e)==shapes[op],f'{p}: wrong keys')
    if op=='literal':valid_json(e['value'],p+'.value')
    elif op=='get':req(e['source'] in allowed,f'{p}: forbidden source');req(isinstance(e['path'],list) and all(isinstance(x,str) and x for x in e['path']),f'{p}: bad path')
    elif op=='object':req(isinstance(e['fields'],dict),f'{p}: fields');[vexpr(x,allowed,p+'.'+k,d+1) for k,x in e['fields'].items()]
    elif op=='array':req(isinstance(e['items'],list),f'{p}: items');[vexpr(x,allowed,p,d+1) for x in e['items']]
    elif op=='if':[vexpr(e[k],allowed,p+'.'+k,d+1) for k in ('cond','then','else')]
    elif op in {'eq','neq'}:[vexpr(e[k],allowed,p+'.'+k,d+1) for k in ('left','right')]
    elif op in {'and','or'}:req(isinstance(e['args'],list) and e['args'],f'{p}: args');[vexpr(x,allowed,p,d+1) for x in e['args']]
    else:vexpr(e['expr'],allowed,p+'.expr',d+1)
def footprint(e):
    r=set()
    def w(x):
        op=x['op']
        if op=='get':r.add((x['source'],tuple(x['path'])))
        elif op=='object':[w(v) for v in x['fields'].values()]
        elif op=='array':[w(v) for v in x['items']]
        elif op=='if':[w(x[k]) for k in ('cond','then','else')]
        elif op in {'eq','neq'}:[w(x[k]) for k in ('left','right')]
        elif op in {'and','or'}:[w(v) for v in x['args']]
        elif op in {'not','is_null'}:w(x['expr'])
    w(e);return [{'source':s,'path':list(p)} for s,p in sorted(r,key=lambda q:(q[0],json.dumps(q[1])))]
def ev(e,env,d=0):
    req(d<=64,'expression nesting');op=e['op']
    if op=='literal':return e['value']
    if op=='get':return get(env[e['source']],e['path'],'get')
    if op=='object':return {k:ev(v,env,d+1) for k,v in e['fields'].items()}
    if op=='array':return [ev(v,env,d+1) for v in e['items']]
    if op in {'eq','neq'}:
        q=jeq(ev(e['left'],env,d+1),ev(e['right'],env,d+1));return q if op=='eq' else not q
    if op in {'not','is_null'}:
        q=ev(e['expr'],env,d+1)
        if op=='is_null':return q is None
        req(type(q) is bool,'not operand');return not q
    if op in {'and','or'}:
        q=[ev(v,env,d+1) for v in e['args']];req(all(type(x) is bool for x in q),f'{op} operands');return all(q) if op=='and' else any(q)
    q=ev(e['cond'],env,d+1);req(type(q) is bool,'if condition');return ev(e['then'] if q else e['else'],env,d+1)
def group(worlds,m):
    gs=[]
    for w in worlds:
        g=next((x for x in gs if jeq(x['value'],m[w])),None)
        if g is None:g={'value':m[w],'worlds':[]};gs.append(g)
        g['worlds'].append(w)
    return gs

def graph(b):
    p=b['provenance'];nodes={n['id']:n for n in p['nodes']};inc={k:[] for k in nodes}
    req(len(nodes)==len(p['nodes']),'duplicate provenance node');req(all(n.get('kind') in {'EVIDENCE','FACT','DECLARATION','DERIVATION','CLAIM'} for n in p['nodes']),'provenance node kind')
    edgekeys=set()
    for e in p['edges']:
        req(e['from'] in nodes and e['to'] in nodes,'edge unknown node');req(e['relation'] in EDGE_RULES,'bad relation');key=(e['from'],e['to'],e['relation']);req(key not in edgekeys,'duplicate provenance edge');edgekeys.add(key);a,z=EDGE_RULES[e['relation']];req(nodes[e['from']]['kind'] in a and nodes[e['to']]['kind'] in z,'bad edge typing');inc[e['to']].append(e)
    # cycle check
    mark={}
    def dfs(n):
        req(mark.get(n)!=1,'provenance cycle')
        if mark.get(n)==2:return
        mark[n]=1
        for e in inc[n]:dfs(e['from'])
        mark[n]=2
    for n in nodes:dfs(n)
    return p,nodes,inc
def upstream(root,nodes,inc):
    seen=set();st=[root]
    while st:
        n=st.pop()
        if n in seen:continue
        seen.add(n);st += [e['from'] for e in inc[n]]
    return seen
def claim_support(b):
    p,nodes,inc=graph(b);bindings={x['id']:x for x in b['bindings']};out={}
    for c,roots in sorted(p['claim_roots'].items()):
        rows=[];ae=[];ap=[];ar=[]
        for r in roots:
            req(r in nodes and nodes[r]['kind']=='CLAIM','claim root must be CLAIM');ids=upstream(r,nodes,inc);ens=sorted(x for x in ids if nodes[x]['kind']=='EVIDENCE');bs=[];ep=[];rr=[]
            for n in ens:
                for bid in nodes[n].get('binding_ids',[]):
                    req(bid in bindings,'unknown binding');
                    if bid not in bs:bs.append(bid)
                    q=bindings[bid]
                    if q['kind'] in EPI:
                        if bid not in ep:ep.append(bid)
                        if q.get('required',True) and bid not in rr:rr.append(bid)
            rows.append({'root':r,'evidence_node_ids':ens,'binding_ids':sorted(bs),'epistemic_binding_ids':sorted(ep),'required_epistemic_binding_ids':sorted(rr)});ae+=ens;ap+=ep;ar+=rr
        out[c]={'roots':list(roots),'root_support':rows,'evidence_node_ids':sorted(set(ae)),'epistemic_binding_ids':sorted(set(ap)),'required_epistemic_binding_ids':sorted(set(ar)),'provenance_mode':p['mode']}
    return out,nodes,inc
def claim_paths_full(b):
    p,nodes,inc=graph(b);out={}
    for c,roots in p['claim_roots'].items():
        seen=set();st=list(roots);items=[]
        while st:
            n=st.pop()
            if n in seen:continue
            seen.add(n);q=nodes[n];items.append({'id':n,'kind':q['kind'],'label':q.get('label',n),'binding_ids':q.get('binding_ids',[]) });st += [e['from'] for e in inc[n]]
        out[c]=sorted(items,key=lambda x:x['id'])
    return out

def strict_bundle_shape(b):
    req(isinstance(b,dict) and set(b)<={'bundle_version','bundle_id','metadata','semantic','bindings','provenance','claim_boundary','annotations'},'bundle top-level shape')
    req(b.get('bundle_version')=='0.5' and isinstance(b.get('bundle_id'),str) and b['bundle_id'],'bundle identity')
    sem=b.get('semantic');req(isinstance(sem,dict) and set(sem)=={'structural_template','exact_enabled','derivation'},'semantic shape');req(type(sem['exact_enabled']) is bool,'exact_enabled')
    der=sem['derivation'];req(isinstance(der,dict) and set(der)=={'mode','world_records','profile_constants','facts','program'},'derivation shape');req(der['mode']=='CONSEQUENCE_BLIND','derivation mode')
    req(isinstance(der['world_records'],list) and der['world_records'],'world records')
    for w in der['world_records']:req(isinstance(w,dict) and set(w)=={'id','coordinates'} and isinstance(w['id'],str) and w['id'] and isinstance(w['coordinates'],dict) and 'id' not in w['coordinates'],'world record shape')
    req(isinstance(der['facts'],list),'facts')
    fids=set()
    for f in der['facts']:
        req(isinstance(f,dict) and set(f)<={'id','status','provenance_node'} and {'id','status'}<=set(f),'fact shape');req(isinstance(f['id'],str) and f['id'] and f['id'] not in fids,'fact id');fids.add(f['id']);req(f['status'] in {'ESTABLISHED','UNRESOLVED','CONTRADICTED'},'fact status')
    prog=der['program'];req(isinstance(prog,dict) and set(prog)<={'program_version','discriminator','operative_signature','mechanism','interpreter'} and {'program_version','discriminator'}<=set(prog),'program shape')
    p=b.get('provenance');req(isinstance(p,dict) and set(p)=={'mode','nodes','edges','claim_roots'},'provenance shape');req(isinstance(p['nodes'],list) and isinstance(p['edges'],list) and isinstance(p['claim_roots'],dict),'provenance containers')
    for n in p['nodes']:req(isinstance(n,dict) and set(n)<={'id','kind','label','binding_ids'} and {'id','kind'}<=set(n),'provenance node shape')
    for e in p['edges']:req(isinstance(e,dict) and set(e)=={'from','to','relation'},'provenance edge shape')
    return True

def check_provenance(b):
    req(isinstance(b.get('bindings'),list),'bindings');ids=set();bindings={}
    for x in b['bindings']:
        req(isinstance(x,dict) and set(x)<={'id','kind','path','sha256','required','role'},'binding shape');req(isinstance(x.get('id'),str) and x['id'] and x['id'] not in ids,'binding id');ids.add(x['id']);bindings[x['id']]=x;req(x.get('kind') in EPI|{'AUXILIARY'},'binding kind');req(isinstance(x.get('path'),str) and x['path'],'binding path');req(type(x.get('required',True)) is bool,'binding required');req(isinstance(x.get('sha256'),str) and len(x['sha256'])==64 and all(c in '0123456789abcdef' for c in x['sha256']),'binding hash')
    p,nodes,inc=graph(b);req(p['mode'] in {'DECLARED_ONLY','EVIDENCE_LINKED'},'provenance mode');roots=p['claim_roots'];req(set(roots)<=CLAIMS,'claim type');root_owner={};rooted=set();refb=set()
    for n in p['nodes']:
        bids=n.get('binding_ids',[]);req(isinstance(bids,list) and len(bids)==len(set(bids)) and all(x in bindings for x in bids),'node binding_ids')
        if n['kind']=='EVIDENCE':req(bids and any(bindings[x]['kind'] in EPI for x in bids),'EVIDENCE node requires epistemic binding')
        else:req(not bids,'only EVIDENCE nodes may carry bindings')
        refb.update(bids)
    for c,rs in roots.items():
        req(isinstance(rs,list) and rs and len(rs)==len(set(rs)),'claim roots');
        for r in rs:req(r in nodes and nodes[r]['kind']=='CLAIM','claim root must be CLAIM');req(r not in root_owner,'claim root reused');root_owner[r]=c;rooted.add(r)
    req(rooted=={n for n,q in nodes.items() if q['kind']=='CLAIM'},'all CLAIM nodes must be rooted')
    support,_,_=claim_support(b)
    exact=b['semantic']['exact_enabled']
    if p['mode']=='DECLARED_ONLY':req(not any(q['kind']=='EVIDENCE' for q in nodes.values()),'DECLARED_ONLY evidence node');req(not any(x['kind'] in EPI for x in b['bindings']),'DECLARED_ONLY epistemic binding')
    else:
        for c in ('C','D','O','COVERAGE'):req(c in roots,f'missing {c} root')
        if exact:req('EXACT' in roots,'missing EXACT root')
        used_nodes=set();used_req=set()
        for c,sp in support.items():
            for rr in sp['root_support']:req(rr['required_epistemic_binding_ids'],f'{c} root lacks required evidence');used_nodes.update(rr['evidence_node_ids']);used_req.update(rr['required_epistemic_binding_ids'])
        req({n for n,q in nodes.items() if q['kind']=='EVIDENCE'}<=used_nodes,'dangling EVIDENCE node');req({x['id'] for x in b['bindings'] if x['kind'] in EPI}<=refb,'unreferenced epistemic binding');req({x['id'] for x in b['bindings'] if x['kind'] in EPI and x.get('required',True)}<=used_req,'required epistemic binding not on claim path')
        facts={x['id']:x for x in b['semantic']['derivation']['facts']};used={}
        for st,q in b['semantic']['derivation']['program'].items():
            if st=='program_version' or q is None:continue
            for fid in q['required_fact_ids']:used.setdefault(fid,set()).add('D' if st=='discriminator' else 'EXACT')
        for fid,targets in used.items():
            req(fid in facts and facts[fid]['status']=='ESTABLISHED','required fact not established');pn=facts[fid].get('provenance_node');req(pn in nodes and nodes[pn]['kind']=='FACT','fact provenance');u=upstream(pn,nodes,inc);ens=[n for n in u if nodes[n]['kind']=='EVIDENCE'];req(any(any(bindings[bid]['kind'] in EPI and bindings[bid].get('required',True) for bid in nodes[n].get('binding_ids',[])) for n in ens),'fact no required evidence')
            for t in targets:req(any(pn in upstream(r,nodes,inc) for r in roots.get(t,[])),f'fact not on {t} path')
    return support

def compile_blind(b):
    req(b.get('bundle_version')=='0.5','proof checker requires bundle 0.5');sem=b['semantic'];st=sem['structural_template'];der=sem['derivation'];worlds=st['boundary']['worlds'];req([x['id'] for x in der['world_records']]==worlds,'world record order')
    req('signature_by_world' not in st.get('discriminator',{}),'predeclared discriminator forbidden');req(der['mode']=='CONSEQUENCE_BLIND','derivation mode');prog=der['program'];req(prog['program_version']=='0.5','program version');facts={x['id']:x['status'] for x in der['facts']};const=der['profile_constants'];valid_json(const,'constants')
    specs={}
    for name in ('discriminator','operative_signature','mechanism','interpreter'):
        s=prog.get(name)
        if s is None:
            req(not sem['exact_enabled'] and name!='discriminator',f'missing stage {name}');continue
        req(set(s)=={'required_fact_ids','expr'},f'{name}: stage keys');req(len(s['required_fact_ids'])==len(set(s['required_fact_ids'])),'duplicate facts');req(all(facts.get(x)=='ESTABLISHED' for x in s['required_fact_ids']),f'{name}: unestablished fact');vexpr(s['expr'],STAGES[name],name);specs[name]=s
    if not sem['exact_enabled']:req(all(prog.get(x) is None for x in ('operative_signature','mechanism','interpreter')),'exact-disabled extra stages')
    d={};z={};native={};alpha={}
    for wrec in der['world_records']:
        wid=wrec['id'];coords=wrec['coordinates'];req(isinstance(coords,dict) and 'id' not in coords,'coordinates');valid_json(coords,'world')
        d[wid]=ev(specs['discriminator']['expr'],{'world':coords,'const':const});valid_json(d[wid])
        if sem['exact_enabled']:z[wid]=ev(specs['operative_signature']['expr'],{'world':coords,'const':const});valid_json(z[wid])
    fibers=[]
    if sem['exact_enabled']:
        for wid in worlds:
            g=next((x for x in fibers if jeq(x['operative_signature'],z[wid])),None)
            if g is None:
                n=ev(specs['mechanism']['expr'],{'z':z[wid],'const':const});valid_json(n);a=ev(specs['interpreter']['expr'],{'native':n,'const':const});req(isinstance(a,dict) and set(a) in ({'space','label'},{'space','native'}),'interpreter shape')
                if a.get('space')=='C':req('label' in a,'C label')
                elif a.get('space')=='OUTSIDE_C':req('native' in a and jeq(a['native'],n),'OUTSIDE_C native')
                else:fail('interpreter space')
                g={'operative_signature':z[wid],'native_outcome':n,'mechanism_consequence':a,'worlds':[]};fibers.append(g)
            g['worlds'].append(wid);native[wid]=g['native_outcome'];alpha[wid]=g['mechanism_consequence']
    derived={'discriminator_signature_by_world':d}
    if sem['exact_enabled']:derived.update({'operative_signature_by_world':z,'native_outcome_by_world':native,'mechanism_consequence_by_world':alpha})
    fp={n:footprint(s['expr']) for n,s in specs.items()};fr={n:list(s['required_fact_ids']) for n,s in specs.items()}
    payload={'protocol':COMPILER_PROTOCOL,'worlds':[{'id':x['id'],'coordinates':x['coordinates']} for x in der['world_records']],'profile_constants':const,'established_facts':sorted(k for k,v in facts.items() if v=='ESTABLISHED'),'exact_enabled':sem['exact_enabled'],'program':prog}
    forbidden={'source_by_world','consequence_by_world','declared_target_model_by_world','target_model_by_world','compatibility_consequence_by_world','compatibility_target_model_by_world','compatibility_contract_signature_by_world','signature_by_world','operative_signature_by_world','mechanism_consequence_by_world','expected_verdict','expected_result'}
    def keys(x):
        if isinstance(x,dict):return set(x)|set().union(*(keys(v) for v in x.values()),set())
        if isinstance(x,list):return set().union(*(keys(v) for v in x),set())
        return set()
    req(not(keys(payload)&forbidden),'compiler firewall forbidden key')
    return {'protocol':COMPILER_PROTOCOL,'sanitized_input_digest':digest(payload),'program_digest':digest(prog),'firewall':{'policy':'PER_WORLD_CONSEQUENCE_TABLE_EXCLUDED','transport':'CANONICAL_JSON_STDIN_ONLY','bundle_path_exposed_to_compiler':False,'source_consequence_table_exposed_to_compiler':False,'target_model_exposed_to_compiler':False,'predeclared_discriminator_table_exposed_to_compiler':False,'predeclared_exact_tables_exposed_to_compiler':False,'world_identifier_available_for_output_keying_but_not_expression_lookup':True,'os_level_sandbox':False,'forbidden_key_audit':'PASS'},'stage_input_footprint':fp,'derived':derived,'mechanism_fibers':fibers},payload

def structural(b,comp):
    p=b['semantic']['structural_template'];fam=p.get('coverage',{}).get('source_family',[]);ins=p.get('coverage',{}).get('in_scope',[]);req(all(isinstance(x,str) for x in fam+ins),'coverage strings');gap={'source_only':sorted(set(fam)-set(ins)),'in_scope_only':sorted(set(ins)-set(fam))};cov=set(fam)==set(ins)
    if p['scope']['status']=='OUTSIDE_DECLARED_SCOPE':return {'C':'NA','D':'NA','O':'NA','structural_classification':'OUTSIDE_DECLARED_SCOPE','declared_model_crosscheck':'NA','precision':'NA','coverage_complete':cov,'coverage_gap':gap,'D_witness':None,'overdiscrimination_witness':None,'O_basis':None}
    cs=p['correspondence']['status']
    if cs!='ESTABLISHED':
        req(cs in {'NOT_ESTABLISHED','UNRESOLVED'},'correspondence status');C='C0' if cs=='NOT_ESTABLISHED' else 'CU';cl='CORRESPONDENCE_NOT_ESTABLISHED' if C=='C0' else 'UNRESOLVED';return {'C':C,'D':'NA','O':'NA','structural_classification':cl,'declared_model_crosscheck':'NA','precision':'NA','coverage_complete':cov,'coverage_gap':gap,'D_witness':None,'overdiscrimination_witness':None,'O_basis':None}
    ws=p['boundary']['worlds'];K=p['consequence']['source_by_world'];Dmap=comp['derived']['discriminator_signature_by_world'];dw=None
    for i,a in enumerate(ws):
        for z in ws[i+1:]:
            if jeq(Dmap[a],Dmap[z]) and not jeq(K[a],K[z]):dw={'worlds':[a,z],'signature':Dmap[a],'consequences':[K[a],K[z]]};break
        if dw:break
    D='D0' if dw else 'D1';over=None;precision='NA'
    if D=='D1':
        for i,a in enumerate(ws):
            for z in ws[i+1:]:
                if jeq(K[a],K[z]) and not jeq(Dmap[a],Dmap[z]):over={'worlds':[a,z],'consequence':K[a],'signatures':[Dmap[a],Dmap[z]]};break
            if over:break
        precision='OVERDISCRIMINATING_ON_DECLARED_WORLDS' if over else 'CONSEQUENCE_EXACT_PARTITION'
    g=p['discharge']['gates_effect'];cut=p['discharge']['evaluation_cut'];post=p['boundary']['post_check_material_transition_possible'];basis={'gates_effect':g,'evaluation_cut':cut,'post_check_material_transition_possible':post}
    if g=='UNKNOWN' or cut=='UNKNOWN':O='OU'
    elif g is False or cut=='NONE':O='O0'
    elif g is True and cut=='ENVIRONMENT':O='O1_REPLACED'
    elif g is True and cut=='EFFECT':O='O1'
    elif g is True and cut=='PRE_EFFECT':O='O0' if post else 'O1'
    else:O='OU'
    cl='DISCRIMINATION_INADEQUATE' if D=='D0' else 'OPERATIVE_DISCHARGE_MISSING' if O=='O0' else 'UNRESOLVED' if O=='OU' else 'STRUCTURAL_ASSURANCE_ESTABLISHED';model=p.get('declared_target_model_by_world');cross='DECLARED_MODEL_NOT_PROVIDED' if not model else ('DECLARED_MODEL_MATCH' if all(w in model and jeq(model[w],K[w]) for w in ws) else 'DECLARED_MODEL_MISMATCH')
    return {'C':'C1','D':D,'O':O,'structural_classification':cl,'declared_model_crosscheck':cross,'precision':precision,'coverage_complete':cov,'coverage_gap':gap,'D_witness':dw,'overdiscrimination_witness':over,'O_basis':basis,'claim_level':'STRUCTURAL_ONLY' if cross=='DECLARED_MODEL_NOT_PROVIDED' else 'STRUCTURAL_PLUS_DECLARED_MODEL_CROSSCHECK'}
def exact(b,comp):
    if not b['semantic']['exact_enabled']:return None
    ws=b['semantic']['structural_template']['boundary']['worlds'];K=b['semantic']['structural_template']['consequence']['source_by_world'];Z=comp['derived']['operative_signature_by_world'];A=comp['derived']['mechanism_consequence_by_world'];gs=group(ws,Z);suf=True;zw=None;dec=[]
    for g in gs:
        vals=[]
        for w in g['worlds']:
            if not any(jeq(K[w],x) for x in vals):vals.append(K[w])
        if len(vals)>1 and zw is None:
            suf=False;pair=next([a,z] for i,a in enumerate(g['worlds']) for z in g['worlds'][i+1:] if not jeq(K[a],K[z]));zw={'worlds':pair,'signature':g['value'],'consequences':[K[pair[0]],K[pair[1]]]}
        if len(vals)==1:dec.append({'signature':g['value'],'consequence':vals[0],'worlds':g['worlds']})
    mism=[];outside=[]
    for w in ws:
        got=A[w];want={'space':'C','label':K[w]}
        if got.get('space')=='OUTSIDE_C':outside.append({'world':w,'value':got})
        if not jeq(got,want):mism.append({'world':w,'required':want,'actual':got})
    if not suf:aligned=None;ast='NOT_APPLICABLE_Z_INSUFFICIENT';aw=None
    else:
        aligned=True;ast='ALIGNED';aw=None
        for d in dec:
            vals=[]
            for w in d['worlds']:
                if not any(jeq(A[w],x) for x in vals):vals.append(A[w])
            if len(vals)>1:aligned=False;ast='MISALIGNED';aw={'signature':d['signature'],'worlds':d['worlds'],'reason':'ALPHA_NOT_FUNCTION_OF_Z','actual_values':vals};break
            want={'space':'C','label':d['consequence']}
            if not jeq(vals[0],want):aligned=False;ast='MISALIGNED';aw={'signature':d['signature'],'worlds':d['worlds'],'reason':'WRONG_DECODER','required':want,'actual':vals[0]};break
    ex=bool(suf and aligned is True and not mism)
    if ex:fm='NONE';mini=None;rep=[]
    elif not suf:fm='OPERATIVE_INSUFFICIENCY';mini={'kind':'CONSEQUENCE_DIVERGENT_PAIR_COLLAPSED_BY_Z',**zw};rep=[{'class':'ADD_CONSEQUENCE_RELEVANT_INPUT','necessary_condition':'The operative signature must distinguish every admissible pair with different declared consequences.'},{'class':'NO_POSTPROCESSING_ONLY_REPAIR','necessary_condition':'Deterministic post-processing of the unchanged insufficient operative signature cannot restore the lost distinction.'}]
    else:fm='MECHANISM_MISALIGNMENT';m=mism[0] if mism else aw;mini={'kind':'EFFECT_MAPPING_MISMATCH','detail':m};rep=[{'class':'ALIGN_EFFECT_MECHANISM','necessary_condition':'On each operative-signature fiber, the grounded mechanism consequence must equal the unique decoder required by the declared source consequence.'}]
    return {'z_sufficient':suf,'z_witness':zw,'required_decoder':dec if suf else None,'alpha_aligned':aligned,'alpha_alignment_status':ast,'alignment_witness':aw,'outside_c':outside,'world_mismatches':mism,'exact':ex,'status':'REALIZATION_ESTABLISHED' if ex else 'REALIZATION_CONTRADICTED','failure_mode':fm,'minimal_counterexample':mini,'repair_obligations':rep}
def proof_expected(b,comp,s,e,cross,support):
    ws=b['semantic']['structural_template']['boundary']['worlds'];K=b['semantic']['structural_template']['consequence']['source_by_world'];dmap=comp['derived']['discriminator_signature_by_world']
    if s['D']=='D0':dp={'status':'D0','kind':'DIVERGENT_PAIR','witness':s['D_witness']}
    elif s['D']=='D1':dp={'status':'D1','kind':'FIBER_DECODER','fibers':[{'signature':g['value'],'worlds':g['worlds'],'consequence':K[g['worlds'][0]]} for g in group(ws,dmap)],'precision':s['precision'],'overdiscrimination_witness':s['overdiscrimination_witness']}
    else:dp={'status':s['D'],'kind':'NOT_APPLICABLE'}
    basis=s['O_basis'];rule='NOT_APPLICABLE'
    if basis:
        g,cut,post=basis['gates_effect'],basis['evaluation_cut'],basis['post_check_material_transition_possible'];rule='UNKNOWN_INPUT' if g=='UNKNOWN' or cut=='UNKNOWN' else 'NO_EFFECT_GATE' if g is False or cut=='NONE' else 'ENVIRONMENT_REPLACEMENT' if cut=='ENVIRONMENT' else 'EFFECT_GATE' if cut=='EFFECT' else 'PRE_EFFECT_MATERIAL_TRANSITION' if cut=='PRE_EFFECT' and post else 'PRE_EFFECT_STABLE' if cut=='PRE_EFFECT' else 'UNSUPPORTED_PATTERN'
    ex={'enabled':e is not None}
    if e:ex.update({'z_sufficiency':{'sufficient':e['z_sufficient'],'fibers':e['required_decoder'] if e['z_sufficient'] else None,'witness':e['z_witness']},'alpha_alignment':{'status':e['alpha_alignment_status'],'aligned':e['alpha_aligned'],'witness':e['alignment_witness']},'world_mismatches':e['world_mismatches'],'outside_c':e['outside_c'],'exact':e['exact'],'status':e['status'],'failure_mode':e['failure_mode'],'minimal_counterexample':e['minimal_counterexample']})
    return {'proof_version':PROOF_VERSION,'proof_semantics':PROOF_SEMANTICS,'bundle_digest':digest(b),'blind_compilation':comp,'structural':{'C':{'status':s['C'],'correspondence_status':b['semantic']['structural_template']['correspondence']['status']},'D':dp,'O':{'status':s['O'],'rule':rule,'premises':basis},'coverage':{'complete':s['coverage_complete'],'source_only':s['coverage_gap']['source_only'],'in_scope_only':s['coverage_gap']['in_scope_only']},'classification':s['structural_classification'],'declared_model_crosscheck':s['declared_model_crosscheck']},'exact':ex,'cross_layer':cross,'claim_support':support,'verdict_commitment':{'structural':s,'exact_realization':e,'cross_layer':cross}}
def safe(root,rel):
    req(isinstance(rel,str) and rel and not Path(rel).is_absolute(),'binding path');r=Path(root).resolve();p=(r/rel).resolve();req(os.path.commonpath([str(r),str(p)])==str(r),'binding escapes root');return p

def check(cert,root=None):
    checks=[]
    def ck(n,c,d=''):checks.append({'check':n,'status':'PASS' if c else 'FAIL','detail':d});req(c,n+(': '+d if d else ''))
    partial=False
    try:
        allowed={'certificate_version','bundle_protocol','bundle_id','bundle_snapshot','bundle_digest','semantic_input_digests','proof','proof_digest','results','model_verification_at_issuance','evidence_verification_at_issuance','assurance_class_at_issuance','claim_provenance','claim_assurance_at_issuance','provenance_paths','verifier_boundary','proof_checker_boundary','certificate_semantics'}
        ck('certificate-shape',isinstance(cert,dict) and set(cert)<=allowed and cert.get('certificate_version')==CERT_VERSION);ck('certificate-semantics',cert.get('certificate_semantics')==CERT_SEMANTICS);ck('checker-boundary',cert.get('proof_checker_boundary')==BOUNDARY)
        b=cert['bundle_snapshot'];strict_bundle_shape(b);ck('bundle-version',b.get('bundle_version')=='0.5');ck('bundle-id',cert.get('bundle_id')==b.get('bundle_id'));ck('bundle-digest',cert.get('bundle_digest')==digest(b));valid_json(b);sid=cert.get('semantic_input_digests',{});ck('semantic-input-digest',sid.get('semantic')==digest(b['semantic']));ck('structural-input-digest',sid.get('structural_input')==digest(b['semantic']['structural_template']));ck('derivation-input-digest',sid.get('derivation')==digest(b['semantic']['derivation']));ck('verifier-boundary',cert.get('verifier_boundary')==MAIN_BOUNDARY)
        support=check_provenance(b);ck('provenance-proof-shape',True)
        comp,payload=compile_blind(b);ck('blind-compilation',True);stored=cert['proof']['blind_compilation'];ck('compiled-proof-match',stored==comp);ck('sanitized-input-digest',comp['sanitized_input_digest']==digest(payload))
        s=structural(b,comp);e=exact(b,comp);cross={'status':'PASS','mode':'SAME_DECLARED_PROFILE','worlds':len(b['semantic']['structural_template']['boundary']['worlds'])} if e is not None else {'status':'NOT_APPLICABLE','mode':'STRUCTURAL_ONLY'}
        exp=proof_expected(b,comp,s,e,cross,support);p=cert['proof'];pd=p.get('proof_digest');p0={k:v for k,v in p.items() if k!='proof_digest'};ck('proof-digest',pd==digest(p0));ck('certificate-proof-digest',cert.get('proof_digest')==pd);exp['proof_digest']=digest(exp);ck('local-proof-complete',p==exp)
        ck('result-structural',cert['results']['structural']==s);ck('result-exact',cert['results'].get('exact_realization')==e);ck('result-cross-layer',cert['results']['cross_layer']==cross);ck('verdict-commitment',p['verdict_commitment']==cert['results']);ck('claim-support',p['claim_support']==support and cert.get('claim_provenance')==support);ck('provenance-paths',cert.get('provenance_paths')==claim_paths_full(b));issuance=cert.get('claim_assurance_at_issuance',{});ck('claim-assurance-shape',set(issuance)==set(support));
        for c,sp in support.items():
            row=issuance.get(c,{});static={k:row.get(k) for k in ['roots','root_support','evidence_node_ids','epistemic_binding_ids','required_epistemic_binding_ids','provenance_mode']};ck('claim-assurance-static:'+c,static==sp);ck('claim-assurance-issuance:'+c,row.get('evidence_integrity')==('PASS' if b['provenance']['mode']=='EVIDENCE_LINKED' else 'NOT_APPLICABLE_DECLARED_ONLY'))
        mode=b['provenance']['mode']
        if mode=='EVIDENCE_LINKED':
            if root is None:partial=True;checks.append({'check':'evidence-byte-recheck','status':'NOT_RECHECKED','detail':'evidence root not supplied'})
            else:
                rows={}
                for x in b['bindings']:
                    q=safe(root,x['path']);ok=q.is_file() and fhash(q)==x['sha256'];rows[x['id']]=ok
                    if x.get('required',True):ck('binding:'+x['id'],ok)
                for c,sp in support.items():ck('claim-evidence:'+c,bool(sp['required_epistemic_binding_ids']) and all(rows.get(x,False) for x in sp['required_epistemic_binding_ids']))
        else:checks.append({'check':'evidence-byte-recheck','status':'NOT_APPLICABLE','detail':'DECLARED_ONLY'})
        expected_class='PROOF_CARRYING_BLIND_COMPILED_EVIDENCE_VERIFIED' if mode=='EVIDENCE_LINKED' else 'PROOF_CARRYING_BLIND_COMPILED_DECLARED_ONLY';ck('issuance-assurance-class',cert.get('assurance_class_at_issuance')==expected_class);ck('issuance-model-status',cert.get('model_verification_at_issuance')=='PASS');ck('issuance-evidence-status',cert.get('evidence_verification_at_issuance')==('PASS' if mode=='EVIDENCE_LINKED' else 'NOT_APPLICABLE_DECLARED_ONLY'))
        status='PARTIAL' if partial else 'PASS'
    except Exception as x:
        if not any(c['status']=='FAIL' for c in checks):checks.append({'check':'exception','status':'FAIL','detail':str(x)})
        status='FAIL'
    return {'checker':'risu-pcc-check/0.6','status':status,'model_proof_status':'PASS' if status!='FAIL' else 'FAIL','evidence_status':'NOT_RECHECKED' if status=='PARTIAL' else ('PASS' if status=='PASS' and cert.get('bundle_snapshot',{}).get('provenance',{}).get('mode')=='EVIDENCE_LINKED' else 'NOT_APPLICABLE' if status=='PASS' else 'FAIL'),'passed':sum(x['status']=='PASS' for x in checks),'failed':sum(x['status']=='FAIL' for x in checks),'not_rechecked':sum(x['status']=='NOT_RECHECKED' for x in checks),'total':len(checks),'checks':checks}
def main():
    ap=argparse.ArgumentParser(prog='risu-pcc-check',description='Standalone trusted-base checker for Projection Assurance proof-carrying certificates.');ap.add_argument('certificate');ap.add_argument('--root');ap.add_argument('--json',action='store_true');ap.add_argument('--model-only',action='store_true');a=ap.parse_args();cert=json.loads(Path(a.certificate).read_text());r=check(cert,a.root);print(json.dumps(r,indent=2,sort_keys=True) if a.json or r['status']!='PASS' else f"Proof-carrying certificate: {r['status']} ({r['passed']}/{r['total']})");return 2 if r['status']=='FAIL' else (0 if r['status']=='PASS' or a.model_only else 4)
if __name__=='__main__':
    try:raise SystemExit(main())
    except SystemExit:raise
    except Exception as e:print(f'risu-pcc-check: {e}',file=sys.stderr);raise SystemExit(2)

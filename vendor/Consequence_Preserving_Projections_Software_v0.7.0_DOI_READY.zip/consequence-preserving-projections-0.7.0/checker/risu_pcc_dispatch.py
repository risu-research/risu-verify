#!/usr/bin/env python3
import json,subprocess,sys
from pathlib import Path
if len(sys.argv)<2:raise SystemExit('usage: risu-pcc-check CERTIFICATE [options]')
cert=json.loads(Path(sys.argv[1]).read_text());here=Path(__file__).resolve().parent
checker=here/('risu_contract_pcc_check.py' if cert.get('certificate_version')=='0.7' else 'risu_pcc_check.py')
raise SystemExit(subprocess.run([sys.executable,str(checker),*sys.argv[1:]]).returncode)

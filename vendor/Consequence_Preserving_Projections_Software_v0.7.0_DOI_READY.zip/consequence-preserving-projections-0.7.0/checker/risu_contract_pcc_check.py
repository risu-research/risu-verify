#!/usr/bin/env python3
"""Standalone layered checker for v0.7 Source-Contract-separated Projection Assurance certificates.

TCB: this file + checker/risu_pcc_check.py + Python standard library. No producer verifier,
source compiler, target semantic compiler, structural kernel, Exact kernel, or certificate builder imports.
"""
import argparse,base64,hashlib,importlib.util,itertools,json,math,os,sys
from pathlib import Path
CERT_VERSION='0.7';CERT_SEMANTICS='SOURCE_CONSEQUENCE_CONTRACT_SEPARATED_PROJECTION_WITH_PROOF_CARRYING_INNER_CERTIFICATE';SAFE=9007199254740991
OPS={'literal','get','object','array','if','eq','neq','and','or','not','is_null'};ALLOWED={'coord','const'}
BOUNDARY={'model_relative':True,'source_contract_separated_from_projection_adapter':True,'worlds_generated_from_declared_finite_domain':True,'source_consequence_generated_from_total_declared_function':True,'target_compilation_consequence_blind':True,'source_contract_file_pin_self_contained':True,'source_contract_adequacy':'NOT_ESTABLISHED_BY_VERIFIER','evidence_fact_semantic_truth':'NOT_ESTABLISHED_BY_VERIFIER','live_runtime_conformance':'NOT_ESTABLISHED_BY_VERIFIER','independent_reproduction':'NOT_ESTABLISHED_BY_VERIFIER'}
FORBIDDEN={'world_records','worlds','source_by_world','consequence_by_world','signature_by_world','operative_signature_by_world','mechanism_consequence_by_world','declared_target_model_by_world','target_model_by_world'}
def fail(m):raise ValueError(m)
def req(c,m):
    if not c:fail(m)
def canon(v):
    if isinstance(v,list):return [canon(x) for x in v]
    if isinstance(v,dict):return {k:canon(v[k]) for k in sorted(v)}
    return v
def nj(v):
    if isinstance(v,float) and math.isfinite(v) and v.is_integer():return int(v)
    if isinstance(v,list):return [nj(x) for x in v]
    if isinstance(v,dict):return {k:nj(x) for k,x in v.items()}
    return v
def cbytes(v):return json.dumps(canon(nj(v)),separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def dig(v):return hashlib.sha256(cbytes(v)).hexdigest()
def fhash(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b)
    return h.hexdigest()
def valid(v,p='v'):
    if v is None or isinstance(v,(bool,str)):return
    if isinstance(v,(int,float)) and not isinstance(v,bool):
        req(not isinstance(v,float) or math.isfinite(v),p+': nonfinite');
        if float(v).is_integer():req(abs(int(v))<=SAFE,p+': unsafe int')
        return
    if isinstance(v,list):
        for i,x in enumerate(v):valid(x,f'{p}[{i}]')
        return
    if isinstance(v,dict):
        for k,x in v.items():req(isinstance(k,str),p+': key');valid(x,p+'.'+k)
        return
    fail(p+': invalid json')
def jeq(a,b):
    valid(a);valid(b)
    if a is None or b is None:return a is b
    if isinstance(a,bool) or isinstance(b,bool):return isinstance(a,bool) and isinstance(b,bool) and a==b
    if isinstance(a,(int,float)) and isinstance(b,(int,float)) and not isinstance(a,bool) and not isinstance(b,bool):return float(a)==float(b)
    if isinstance(a,str) or isinstance(b,str):return isinstance(a,str) and isinstance(b,str) and a==b
    if isinstance(a,list) or isinstance(b,list):return isinstance(a,list) and isinstance(b,list) and len(a)==len(b) and all(jeq(x,y) for x,y in zip(a,b))
    if isinstance(a,dict) or isinstance(b,dict):return isinstance(a,dict) and isinstance(b,dict) and set(a)==set(b) and all(jeq(a[k],b[k]) for k in a)
    return False
def keys(o,a,r,p):req(isinstance(o,dict),p+': object');req(not(set(o)-set(a)),p+': extra');req(not(set(r)-set(o)),p+': missing')
def get(src,path):
    req(isinstance(path,list) and all(isinstance(x,str) and x for x in path),'path');cur=src
    for x in path:req(isinstance(cur,dict) and x in cur,'missing '+x);cur=cur[x]
    return cur
def ve(e,d=0):
    req(d<=64,'nesting');req(isinstance(e,dict),'expr object');op=e.get('op');req(op in OPS,'bad op')
    sh={'literal':({'op','value'},{'op','value'}),'get':({'op','source','path'},{'op','source','path'}),'object':({'op','fields'},{'op','fields'}),'array':({'op','items'},{'op','items'}),'if':({'op','cond','then','else'},{'op','cond','then','else'}),'eq':({'op','left','right'},{'op','left','right'}),'neq':({'op','left','right'},{'op','left','right'}),'and':({'op','args'},{'op','args'}),'or':({'op','args'},{'op','args'}),'not':({'op','expr'},{'op','expr'}),'is_null':({'op','expr'},{'op','expr'})};keys(e,*sh[op],'expr')
    if op=='literal':valid(e['value'])
    elif op=='get':req(e['source'] in ALLOWED,'source');req(isinstance(e['path'],list) and all(isinstance(x,str) and x for x in e['path']),'path')
    elif op=='object':[ve(x,d+1) for x in e['fields'].values()]
    elif op=='array':[ve(x,d+1) for x in e['items']]
    elif op=='if':[ve(e[k],d+1) for k in ('cond','then','else')]
    elif op in {'eq','neq'}:[ve(e[k],d+1) for k in ('left','right')]
    elif op in {'and','or'}:req(isinstance(e['args'],list) and e['args'],'args');[ve(x,d+1) for x in e['args']]
    else:ve(e['expr'],d+1)
def ev(e,env,d=0):
    req(d<=64,'nesting');op=e['op']
    if op=='literal':return e['value']
    if op=='get':return get(env[e['source']],e['path'])
    if op=='object':return {k:ev(v,env,d+1) for k,v in e['fields'].items()}
    if op=='array':return [ev(v,env,d+1) for v in e['items']]
    if op in {'eq','neq'}:
        q=jeq(ev(e['left'],env,d+1),ev(e['right'],env,d+1));return q if op=='eq' else not q
    if op in {'not','is_null'}:
        q=ev(e['expr'],env,d+1)
        if op=='is_null':return q is None
        req(type(q) is bool,'not bool');return not q
    if op in {'and','or'}:
        q=[ev(v,env,d+1) for v in e['args']];req(all(type(x) is bool for x in q),'bool args');return all(q) if op=='and' else any(q)
    q=ev(e['cond'],env,d+1);req(type(q) is bool,'if bool');return ev(e['then'] if q else e['else'],env,d+1)
def fp(e):
    s=set()
    def w(x):
        op=x['op']
        if op=='get':s.add((x['source'],tuple(x['path'])))
        elif op=='object':[w(v) for v in x['fields'].values()]
        elif op=='array':[w(v) for v in x['items']]
        elif op=='if':[w(x[k]) for k in ('cond','then','else')]
        elif op in {'eq','neq'}:[w(x[k]) for k in ('left','right')]
        elif op in {'and','or'}:[w(v) for v in x['args']]
        elif op in {'not','is_null'}:w(x['expr'])
    w(e);return [{'source':a,'path':list(b)} for a,b in sorted(s,key=lambda q:(q[0],json.dumps(q[1])))]
def nd(vals):
    req(isinstance(vals,list) and vals,'domain');out=[]
    for v in vals:valid(v);req(not any(jeq(v,x) for x in out),'duplicate semantic domain value');out.append(v)
    return sorted([nj(x) for x in out],key=cbytes)
def compile_source(c):
    allowed={'source_contract_version','contract_id','metadata','constants','coordinates','admissibility','consequence','boundary','source_family','claim_boundary'};req(isinstance(c,dict) and set(c)<=allowed,'source contract shape');req(c.get('source_contract_version')=='0.7','source version');req(isinstance(c.get('contract_id'),str) and c['contract_id'],'contract id');co=c.get('coordinates');req(isinstance(co,dict) and co and 'id' not in co,'coordinates');nco={k:nd(co[k]) for k in sorted(co)};const=c.get('constants',{});req(isinstance(const,dict),'constants');valid(const);adm=c['admissibility'];req(set(adm)=={'expr'},'admissibility');ve(adm['expr']);con=c['consequence'];req(set(con)=={'lens','codomain','expr'},'consequence');req(isinstance(con['lens'],str) and con['lens'],'lens');req(isinstance(con['codomain'],list) and con['codomain'] and all(isinstance(x,str) and x for x in con['codomain']) and len(set(con['codomain']))==len(con['codomain']),'codomain');ve(con['expr']);bd=c['boundary'];req(set(bd)=={'declaration','post_check_material_transition_possible'} and isinstance(bd['declaration'],str) and bd['declaration'] and type(bd['post_check_material_transition_possible']) is bool,'boundary');fam=c['source_family'];req(isinstance(fam,list) and fam and all(isinstance(x,str) and x for x in fam) and len(set(fam))==len(fam),'family');names=sorted(nco);domains=[nco[k] for k in names];total=math.prod(len(x) for x in domains);req(total<=100000,'domain too large');worlds=[];ex=[];K={};ids=set()
    for vals in itertools.product(*domains):
        coord={k:v for k,v in zip(names,vals)};ok=ev(adm['expr'],{'coord':coord,'const':const});req(type(ok) is bool,'admissibility bool');wid='W-'+dig(coord)[:20];req(wid not in ids,'world id collision');ids.add(wid)
        if not ok:ex.append({'id':wid,'coordinates':coord});continue
        kv=ev(con['expr'],{'coord':coord,'const':const});req(isinstance(kv,str) and kv in con['codomain'],'K codomain');worlds.append({'id':wid,'coordinates':coord});K[wid]=kv
    req(worlds,'empty admitted domain');norm={'coordinates':nco,'constants':nj(const),'admissibility':nj(adm),'consequence':nj(con),'boundary':nj(bd),'source_family':sorted(fam)};dp={'coordinate_order':names,'domain_cardinalities':{k:len(nco[k]) for k in names},'cartesian_cardinality':total,'admitted_cardinality':len(worlds),'excluded_cardinality':len(ex),'admitted_world_digest':dig(worlds),'excluded_world_digest':dig(ex),'consequence_map_digest':dig(K),'k_totality':'PASS','codomain':list(con['codomain'])};return {'protocol':'risu-source-consequence-contract/0.7','contract_id':c['contract_id'],'source_semantic_digest':dig(norm),'world_records':worlds,'consequence_by_world':K,'domain_proof':dp,'stage_input_footprint':{'admissibility':fp(adm['expr']),'consequence':fp(con['expr'])},'normalized_source_semantics':norm}
def rkeys(v):
    o=[]
    if isinstance(v,dict):
        for k,x in v.items():o.append(k);o+=rkeys(x)
    elif isinstance(v,list):
        for x in v:o+=rkeys(x)
    return o
def normalize(a,c,src):
    req(a.get('adapter_version')=='0.7' and isinstance(a.get('adapter_id'),str) and a['adapter_id'],'adapter');ref=a['source_contract'];req(set(ref)=={'path','sha256'} and isinstance(ref['path'],str) and ref['path'],'source ref');t=a['target'];req(set(t)=={'structural_template','coverage','exact_enabled','derivation'},'target shape');st=json.loads(json.dumps(t['structural_template']));req(not(set(rkeys(st))&FORBIDDEN),'forbidden target answer table');st['boundary']={'declaration':c['boundary']['declaration'],'post_check_material_transition_possible':c['boundary']['post_check_material_transition_possible'],'worlds':[w['id'] for w in src['world_records']]};st['consequence']={'lens':c['consequence']['lens'],'source_by_world':src['consequence_by_world']};st['coverage']={'source_family':sorted(c['source_family']),'in_scope':sorted(t['coverage']['in_scope'])};st.pop('declared_target_model_by_world',None);d=t['derivation'];req(set(d)=={'mode','profile_constants','facts','program'} and d['mode']=='CONSEQUENCE_BLIND','derivation');der={'mode':'CONSEQUENCE_BLIND','world_records':src['world_records'],'profile_constants':d['profile_constants'],'facts':d['facts'],'program':d['program']};return {'bundle_version':'0.5','bundle_id':a['adapter_id'],'metadata':a.get('metadata',{}),'annotations':a.get('annotations',{}),'claim_boundary':a['claim_boundary'],'bindings':a['bindings'],'provenance':a['provenance'],'semantic':{'structural_template':st,'exact_enabled':t['exact_enabled'],'derivation':der}}
def base_checker():
    p=Path(__file__).with_name('risu_pcc_check.py');spec=importlib.util.spec_from_file_location('risu_base_pcc_checker',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def safe(root,rel):
    req(isinstance(rel,str) and rel and not Path(rel).is_absolute(),'unsafe path');r=Path(root).resolve();p=(r/rel).resolve();req(os.path.commonpath([str(r),str(p)])==str(r),'path escapes root');return p
def check(cert,root=None):
    cs=[]
    def ck(n,c,d=''):cs.append({'check':n,'status':'PASS' if c else 'FAIL','detail':d});req(c,n+(': '+d if d else ''))
    try:
        allowed={'certificate_version','certificate_semantics','adapter_id','source_contract_snapshot','source_contract_snapshot_digest','source_contract_file_sha256','source_contract_file_b64','adapter_snapshot','adapter_digest','source_compilation','source_domain_proof','normalized_bundle_digest','inner_certificate','inner_certificate_digest','results','verifier_boundary'};ck('certificate-shape',isinstance(cert,dict) and set(cert)<=allowed and cert.get('certificate_version')==CERT_VERSION);ck('certificate-semantics',cert.get('certificate_semantics')==CERT_SEMANTICS);ck('verifier-boundary',cert.get('verifier_boundary')==BOUNDARY);c=cert['source_contract_snapshot'];a=cert['adapter_snapshot'];ck('source-snapshot-digest',dig(c)==cert['source_contract_snapshot_digest']);ck('adapter-digest',dig(a)==cert['adapter_digest']);ck('adapter-id',a['adapter_id']==cert['adapter_id']);ck('source-pin-record',a['source_contract']['sha256']==cert['source_contract_file_sha256']);raw=base64.b64decode(cert.get('source_contract_file_b64',''),validate=True);ck('source-embedded-byte-pin',hashlib.sha256(raw).hexdigest()==cert['source_contract_file_sha256']);ck('source-embedded-snapshot',json.loads(raw.decode('utf-8'))==c);src=compile_source(c);ck('source-domain-proof',src['domain_proof']==cert['source_domain_proof']);sc=cert['source_compilation'];ck('source-semantic-digest',sc['source_semantic_digest']==src['source_semantic_digest']);ck('source-output-digest',sc['source_output_digest']==dig(src));ck('source-protocol',sc['protocol']=='risu-source-consequence-contract/0.7');b=normalize(a,c,src);ck('normalized-bundle-digest',dig(b)==cert['normalized_bundle_digest']);inner=cert['inner_certificate'];ck('inner-certificate-digest',dig(inner)==cert['inner_certificate_digest']);ck('inner-bundle-equals-normalized',inner['bundle_snapshot']==b);ck('result-commitment',cert['results']==inner['results'])
        if root is not None:
            sp=safe(root,a['source_contract']['path']);ck('source-contract-byte-pin',sp.is_file() and fhash(sp)==a['source_contract']['sha256']);ck('source-contract-root-bytes-equal-embedded',sp.is_file() and sp.read_bytes()==raw);ck('source-contract-root-snapshot',json.loads(sp.read_text())==c)
        br=base_checker().check(inner,root);ck('base-proof-check',br['status']!='FAIL',br['status']);status='PARTIAL' if br['status']=='PARTIAL' else 'PASS'
    except Exception as e:
        if not any(x['status']=='FAIL' for x in cs):cs.append({'check':'exception','status':'FAIL','detail':str(e)})
        status='FAIL'
    return {'checker':'risu-contract-pcc-check/0.7','status':status,'passed':sum(x['status']=='PASS' for x in cs),'failed':sum(x['status']=='FAIL' for x in cs),'total':len(cs),'checks':cs}
def main():
    ap=argparse.ArgumentParser();ap.add_argument('certificate');ap.add_argument('--root');ap.add_argument('--json',action='store_true');ap.add_argument('--model-only',action='store_true');a=ap.parse_args();r=check(json.loads(Path(a.certificate).read_text()),a.root);print(json.dumps(r,indent=2,sort_keys=True) if a.json or r['status']!='PASS' else f"Source-contract proof-carrying certificate: {r['status']} ({r['passed']}/{r['total']})");return 2 if r['status']=='FAIL' else 0 if r['status']=='PASS' or a.model_only else 4
if __name__=='__main__':raise SystemExit(main())

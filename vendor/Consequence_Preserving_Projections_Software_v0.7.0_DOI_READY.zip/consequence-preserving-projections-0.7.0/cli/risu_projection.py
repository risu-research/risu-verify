#!/usr/bin/env python3
from pathlib import Path
import argparse,json,sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from verifier.bundle import load_bundle,validate_bundle_shape
from verifier.engine import evaluate_bundle
from verifier.certificate import build_certificate,verify_certificate
from verifier.certificate_v07 import build_projection_certificate,verify_projection_certificate
from verifier.projection_adapter import load_adapter,normalize_adapter
from verifier.source_contract import load_source_contract,compile_source_contract
from verifier.explain import render
from verifier.semantic_compiler import compile_bundle
from verifier.common import canonical_bytes,sha256_file

def load_cert(p):return json.loads(Path(p).read_text())
def _kind(path):
    p=Path(path)
    if p.is_dir():
        if (p/'adapter.json').is_file():return 'adapter'
        if (p/'bundle.json').is_file():return 'bundle'
    if p.is_file():
        try:o=json.loads(p.read_text())
        except Exception:return 'unknown'
        if o.get('adapter_version')=='0.7':return 'adapter'
        if o.get('bundle_version') in {'0.4','0.5'}:return 'bundle'
        if o.get('source_contract_version')=='0.7':return 'source'
    return 'unknown'
def _load_for_verify(path):
    k=_kind(path)
    if k=='adapter':
        a,p,root=load_adapter(path);b,c,src,arec=normalize_adapter(a,root);return k,b,root,{'adapter':a,'source_contract':c,'source_output':src,'adapter_compilation':arec}
    if k=='bundle':
        b,p,root=load_bundle(path);return k,b,root,{}
    raise ValueError(f'unsupported verification input: {path}')
def main():
    ap=argparse.ArgumentParser(prog='risu-projection',description='Carrier-neutral source-consequence contract compiler, projection verifier, and proof-carrying certificate issuer.')
    sub=ap.add_subparsers(dest='cmd',required=True)
    s=sub.add_parser('source',help='compile a v0.7 Source Consequence Contract');ss=s.add_subparsers(dest='scmd',required=True);sc=ss.add_parser('compile');sc.add_argument('contract');sc.add_argument('-o','--output');sc.add_argument('--json',action='store_true')
    co=sub.add_parser('compile',help='consequence-blind compile a v0.5 Assurance Bundle into verifier semantic profiles');co.add_argument('bundle');co.add_argument('-o','--output');co.add_argument('--json',action='store_true')
    v=sub.add_parser('verify',help='verify a v0.7 Projection Adapter or legacy portable Assurance Bundle');v.add_argument('input');v.add_argument('--certificate');v.add_argument('--json',action='store_true');v.add_argument('--no-bindings',action='store_true',help='recompute without rechecking bound evidence bytes; EVIDENCE_LINKED inputs return PARTIAL');v.add_argument('--require',choices=['structural','exact','both'],help='return exit code 3 if requested semantic assurance is not established');v.add_argument('--require-evidence',action='store_true');v.add_argument('--require-blind',action='store_true');v.add_argument('--require-source-contract',action='store_true',help='require the v0.7 separated Source Consequence Contract architecture')
    c=sub.add_parser('certificate',help='build or verify a proof-carrying certificate');cs=c.add_subparsers(dest='ccmd',required=True)
    cb=cs.add_parser('build');cb.add_argument('input');cb.add_argument('-o','--output',required=True)
    cv=cs.add_parser('verify');cv.add_argument('certificate');cv.add_argument('--root');cv.add_argument('--json',action='store_true');cv.add_argument('--model-only',action='store_true')
    e=sub.add_parser('explain',help='render a deterministic human explanation from an input or certificate');e.add_argument('input')
    a=ap.parse_args()
    if a.cmd=='source':
        c,p=load_source_contract(a.contract);out,rec=compile_source_contract(c);r={'status':'PASS','contract_id':c['contract_id'],'source_compilation':rec,'generated':out}
        if a.output:Path(a.output).write_bytes(canonical_bytes(r)+b'\n')
        if a.json or not a.output:print(json.dumps(r,indent=2,sort_keys=True,ensure_ascii=False))
        else:print(f"Source consequence compilation: PASS\nContract: {c['contract_id']}\nAdmitted worlds: {out['domain_proof']['admitted_cardinality']}\nOutput: {a.output}")
        return 0
    if a.cmd=='compile':
        b,p,root=load_bundle(a.bundle);validate_bundle_shape(b)
        if b.get('bundle_version')!='0.5':raise ValueError('compile requires a v0.5 consequence-blind Assurance Bundle')
        compiled,record=compile_bundle(b);out={'status':'PASS','bundle_id':b['bundle_id'],'compilation':record,'compiled_semantic':compiled['semantic']}
        if a.output:Path(a.output).write_bytes(canonical_bytes(out)+b'\n')
        if a.json or not a.output:print(json.dumps(out,indent=2,sort_keys=True,ensure_ascii=False))
        else:print(f"Consequence-blind compilation: PASS\nOutput: {a.output}\nDerived digest: {record['derived_output_digest']}")
        return 0
    if a.cmd=='verify':
        kind,b,root,extra=_load_for_verify(a.input);r=evaluate_bundle(b,None if a.no_bindings else root,check_bindings=not a.no_bindings)
        if kind=='adapter':r={**r,'software_release':'0.7.0','projection_architecture':'SOURCE_CONTRACT_SEPARATED','source_contract':extra['adapter_compilation']}
        if a.certificate:
            cert=build_projection_certificate(extra['adapter'],root) if kind=='adapter' else build_certificate(b,None if a.no_bindings else root);Path(a.certificate).write_bytes(canonical_bytes(cert)+b'\n')
        print(json.dumps(r,indent=2,sort_keys=True,ensure_ascii=False) if a.json else render(r))
        if r['verification_status']=='FAIL':return 2
        if a.require_source_contract and kind!='adapter':return 3
        if a.require_evidence and r['evidence_verification_status']!='PASS':return 3
        if a.require_blind and not (b.get('bundle_version')=='0.5' and r.get('compilation',{}).get('status')=='PASS'):return 3
        if a.require:
            structural_ok=r['structural'].get('structural_classification')=='STRUCTURAL_ASSURANCE_ESTABLISHED';exact_ok=r.get('exact_realization') is not None and r['exact_realization'].get('status')=='REALIZATION_ESTABLISHED';req_ok=structural_ok if a.require=='structural' else exact_ok if a.require=='exact' else structural_ok and exact_ok
            if not req_ok:return 3
        return 4 if r['verification_status']=='PARTIAL' else 0
    if a.cmd=='certificate' and a.ccmd=='build':
        kind=_kind(a.input)
        if kind=='adapter':
            aa,p,root=load_adapter(a.input);cert=build_projection_certificate(aa,root)
        elif kind=='bundle':
            b,p,root=load_bundle(a.input);cert=build_certificate(b,root)
        else:raise ValueError('certificate build requires v0.7 adapter or v0.5 bundle')
        Path(a.output).write_bytes(canonical_bytes(cert)+b'\n');print(json.dumps({'status':'PASS','certificate':a.output,'sha256':sha256_file(a.output),'certificate_version':cert['certificate_version']},indent=2));return 0
    if a.cmd=='certificate' and a.ccmd=='verify':
        cert=load_cert(a.certificate);r=verify_projection_certificate(cert,a.root) if cert.get('certificate_version')=='0.7' else verify_certificate(cert,a.root);print(json.dumps(r,indent=2,sort_keys=True) if a.json or r['status']!='PASS' else f"Certificate verification: {r['status']} ({r['passed']}/{r['total']})")
        if r['status']=='FAIL':return 2
        if r['status']=='PARTIAL':return 0 if a.model_only else 4
        return 0
    if a.cmd=='explain':
        obj=json.loads(Path(a.input).read_text()) if Path(a.input).is_file() else None
        if obj and obj.get('certificate_version')=='0.7':obj=obj['inner_certificate']
        if obj and obj.get('certificate_version') in {'0.5','0.6'}:
            b=obj['bundle_snapshot'];mode=b.get('provenance',{}).get('mode','DECLARED_ONLY');r={'verification_status':'PARTIAL' if mode=='EVIDENCE_LINKED' else 'PASS','model_verification_status':'PASS','evidence_verification_status':'NOT_RECHECKED' if mode=='EVIDENCE_LINKED' else 'NOT_APPLICABLE_DECLARED_ONLY','semantic_assurance_class':obj.get('assurance_class_at_issuance','UNKNOWN'),'compilation':obj.get('proof',{}).get('blind_compilation',{}),'structural':obj['results']['structural'],'exact_realization':obj['results'].get('exact_realization'),'claim_assurance':{k:{**v,'evidence_integrity':('NOT_RECHECKED' if mode=='EVIDENCE_LINKED' else 'NOT_APPLICABLE_DECLARED_ONLY')} for k,v in obj.get('claim_provenance',{}).items()},'verifier_boundary':obj.get('verifier_boundary',{})}
        else:
            kind,b,root,extra=_load_for_verify(a.input);r=evaluate_bundle(b,root)
        print(render(r));return 0
if __name__=='__main__':
    try:raise SystemExit(main())
    except SystemExit:raise
    except Exception as e:print(f'risu-projection: {e}',file=sys.stderr);raise SystemExit(2)
